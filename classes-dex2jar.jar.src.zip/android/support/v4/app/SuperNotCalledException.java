package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class SuperNotCalledException
  extends AndroidRuntimeException
{
  public SuperNotCalledException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\SuperNotCalledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */