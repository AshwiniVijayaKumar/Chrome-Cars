package com.google.ads.mediation;

@Deprecated
public final class EmptyNetworkExtras
  implements NetworkExtras
{}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\google\ads\mediation\EmptyNetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */