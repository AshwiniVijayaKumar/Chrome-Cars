package com.google.ads.mediation;

@Deprecated
public abstract interface NetworkExtras
  extends com.google.android.gms.ads.mediation.NetworkExtras
{}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\google\ads\mediation\NetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */