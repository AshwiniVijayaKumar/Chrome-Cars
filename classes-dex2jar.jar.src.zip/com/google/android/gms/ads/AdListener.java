package com.google.android.gms.ads;

public abstract class AdListener
{
  public void onAdClosed() {}
  
  public void onAdFailedToLoad(int paramInt) {}
  
  public void onAdLeftApplication() {}
  
  public void onAdLoaded() {}
  
  public void onAdOpened() {}
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\AdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */