package com.google.android.gms.ads.mediation;

public abstract interface NetworkExtras {}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\mediation\NetworkExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */