package com.adsdk.sdk;

import java.io.Serializable;

public abstract interface Ad
  extends Serializable
{
  public abstract int getType();
  
  public abstract void setType(int paramInt);
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\adsdk\sdk\Ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */