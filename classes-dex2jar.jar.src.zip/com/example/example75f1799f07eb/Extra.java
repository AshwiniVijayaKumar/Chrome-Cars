package com.example.example75f1799f07eb;

public class Extra
{
  public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
  public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\example\example75f1799f07eb\Extra.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */