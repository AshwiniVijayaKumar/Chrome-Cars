package com.example.example75f1799f07eb;

public class DeveloperKey
{
  public static final String DEVELOPER_KEY = "AIzaSyCA4uFxSabaAXUf59yTVZtX_JTJ3PJsPlk";
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\example\example75f1799f07eb\DeveloperKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */