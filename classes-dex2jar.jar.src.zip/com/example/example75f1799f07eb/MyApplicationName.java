package com.example.example75f1799f07eb;

public class MyApplicationName
{
  public static String APP_ID;
  public static String APP_NAME;
  public static String GCM_ID;
  public static int Notification_Count;
  public static String PushInternalUrl = "";
  public static String PushWebUrl;
  public static String SOAP_ACTION = "http://schemas.xmlsoap.org/wsdl/";
  public static String SOAP_NAMESPACE;
  public static String SOAP_URL;
  public static String pushmessage;
  
  static
  {
    Notification_Count = 0;
    pushmessage = "";
    PushWebUrl = "";
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\example\example75f1799f07eb\MyApplicationName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */