package com.example.example75f1799f07eb;

public final class Manifest
{
  public static final class permission
  {
    public static final String C2D_MESSAGE = "com.app.app2694da75cd4e.permission.C2D_MESSAGE";
    public static final String MAPS_RECEIVE = "com.app.app2694da75cd4e.permission.MAPS_RECEIVE";
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\example\example75f1799f07eb\Manifest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */