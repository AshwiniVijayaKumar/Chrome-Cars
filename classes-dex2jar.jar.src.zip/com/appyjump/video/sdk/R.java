package com.appyjump.video.sdk;

public final class R
{
  public static final class dimen
  {
    public static final int activity_horizontal_margin = 2131165184;
    public static final int activity_vertical_margin = 2131165185;
  }
  
  public static final class drawable
  {
    public static final int cancel = 2130837531;
  }
  
  public static final class id
  {
    public static final int adLayout = 2131558460;
    public static final int appyjumpAdView = 2131558461;
    public static final int closeAds = 2131558462;
    public static final int progressBar1 = 2131558555;
    public static final int videoView = 2131558554;
  }
  
  public static final class layout
  {
    public static final int banner = 2130903051;
    public static final int interstitial = 2130903087;
  }
  
  public static final class string
  {
    public static final int app_name = 2131230720;
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\appyjump\video\sdk\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */