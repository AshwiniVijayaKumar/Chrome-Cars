package com.appyjump.video.sdk;

public enum Mode
{
  LIVE,  TEST;
  
  private Mode() {}
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\appyjump\video\sdk\Mode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */