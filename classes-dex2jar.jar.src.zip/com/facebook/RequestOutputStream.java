package com.facebook;

abstract interface RequestOutputStream
{
  public abstract void setCurrentRequest(GraphRequest paramGraphRequest);
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\facebook\RequestOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */