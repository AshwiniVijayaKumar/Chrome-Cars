package com.facebook.internal;

public abstract interface DialogFeature
{
  public abstract String getAction();
  
  public abstract int getMinVersion();
  
  public abstract String name();
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\facebook\internal\DialogFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */