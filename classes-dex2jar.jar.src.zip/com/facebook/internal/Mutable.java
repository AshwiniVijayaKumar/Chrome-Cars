package com.facebook.internal;

public class Mutable<T>
{
  public T value;
  
  public Mutable(T paramT)
  {
    this.value = paramT;
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\facebook\internal\Mutable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */