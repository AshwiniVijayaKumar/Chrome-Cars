package com.facebook.internal;

interface package-info {}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\facebook\internal\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */