package com.facebook;

public final class R
{
  public static final class attr
  {
    public static final int com_facebook_auxiliary_view_position = 2130771978;
    public static final int com_facebook_confirm_logout = 2130771968;
    public static final int com_facebook_foreground_color = 2130771974;
    public static final int com_facebook_horizontal_alignment = 2130771979;
    public static final int com_facebook_is_cropped = 2130771973;
    public static final int com_facebook_login_text = 2130771969;
    public static final int com_facebook_logout_text = 2130771970;
    public static final int com_facebook_object_id = 2130771975;
    public static final int com_facebook_object_type = 2130771976;
    public static final int com_facebook_preset_size = 2130771972;
    public static final int com_facebook_style = 2130771977;
    public static final int com_facebook_tooltip_mode = 2130771971;
  }
  
  public static final class color
  {
    public static final int com_facebook_blue = 2131361792;
    public static final int com_facebook_button_background_color = 2131361797;
    public static final int com_facebook_button_background_color_disabled = 2131361798;
    public static final int com_facebook_button_background_color_pressed = 2131361799;
    public static final int com_facebook_button_like_background_color_selected = 2131361800;
    public static final int com_facebook_button_login_silver_background_color = 2131361801;
    public static final int com_facebook_button_login_silver_background_color_pressed = 2131361802;
    public static final int com_facebook_button_send_background_color = 2131361803;
    public static final int com_facebook_button_send_background_color_pressed = 2131361804;
    public static final int com_facebook_likeboxcountview_border_color = 2131361794;
    public static final int com_facebook_likeboxcountview_text_color = 2131361795;
    public static final int com_facebook_likeview_text_color = 2131361793;
    public static final int com_facebook_share_button_text_color = 2131361796;
  }
  
  public static final class dimen
  {
    public static final int com_facebook_likeboxcountview_border_radius = 2131165191;
    public static final int com_facebook_likeboxcountview_border_width = 2131165192;
    public static final int com_facebook_likeboxcountview_caret_height = 2131165190;
    public static final int com_facebook_likeboxcountview_caret_width = 2131165189;
    public static final int com_facebook_likeboxcountview_text_padding = 2131165194;
    public static final int com_facebook_likeboxcountview_text_size = 2131165193;
    public static final int com_facebook_likeview_edge_padding = 2131165187;
    public static final int com_facebook_likeview_internal_padding = 2131165188;
    public static final int com_facebook_likeview_text_size = 2131165186;
    public static final int com_facebook_profilepictureview_preset_size_large = 2131165197;
    public static final int com_facebook_profilepictureview_preset_size_normal = 2131165196;
    public static final int com_facebook_profilepictureview_preset_size_small = 2131165195;
    public static final int com_facebook_share_button_compound_drawable_padding = 2131165198;
    public static final int com_facebook_share_button_padding_bottom = 2131165199;
    public static final int com_facebook_share_button_padding_left = 2131165200;
    public static final int com_facebook_share_button_padding_right = 2131165201;
    public static final int com_facebook_share_button_padding_top = 2131165202;
    public static final int com_facebook_share_button_text_size = 2131165203;
    public static final int com_facebook_tooltip_horizontal_padding = 2131165204;
  }
  
  public static final class drawable
  {
    public static final int com_facebook_button_background = 2130837535;
    public static final int com_facebook_button_icon = 2130837536;
    public static final int com_facebook_button_like_background = 2130837537;
    public static final int com_facebook_button_like_icon_selected = 2130837538;
    public static final int com_facebook_button_login_silver_background = 2130837539;
    public static final int com_facebook_button_send_background = 2130837540;
    public static final int com_facebook_button_send_icon = 2130837541;
    public static final int com_facebook_close = 2130837542;
    public static final int com_facebook_profile_picture_blank_portrait = 2130837543;
    public static final int com_facebook_profile_picture_blank_square = 2130837544;
    public static final int com_facebook_tooltip_black_background = 2130837545;
    public static final int com_facebook_tooltip_black_bottomnub = 2130837546;
    public static final int com_facebook_tooltip_black_topnub = 2130837547;
    public static final int com_facebook_tooltip_black_xout = 2130837548;
    public static final int com_facebook_tooltip_blue_background = 2130837549;
    public static final int com_facebook_tooltip_blue_bottomnub = 2130837550;
    public static final int com_facebook_tooltip_blue_topnub = 2130837551;
    public static final int com_facebook_tooltip_blue_xout = 2130837552;
    public static final int messenger_bubble_large_blue = 2130837648;
    public static final int messenger_bubble_large_white = 2130837649;
    public static final int messenger_bubble_small_blue = 2130837650;
    public static final int messenger_bubble_small_white = 2130837651;
    public static final int messenger_button_blue_bg_round = 2130837652;
    public static final int messenger_button_blue_bg_selector = 2130837653;
    public static final int messenger_button_send_round_shadow = 2130837654;
    public static final int messenger_button_white_bg_round = 2130837655;
    public static final int messenger_button_white_bg_selector = 2130837656;
  }
  
  public static final class id
  {
    public static final int automatic = 2131558407;
    public static final int bottom = 2131558419;
    public static final int box_count = 2131558416;
    public static final int button = 2131558417;
    public static final int center = 2131558422;
    public static final int com_facebook_body_frame = 2131558493;
    public static final int com_facebook_button_xout = 2131558495;
    public static final int com_facebook_fragment_container = 2131558491;
    public static final int com_facebook_login_activity_progress_bar = 2131558492;
    public static final int com_facebook_tooltip_bubble_view_bottom_pointer = 2131558497;
    public static final int com_facebook_tooltip_bubble_view_text_body = 2131558496;
    public static final int com_facebook_tooltip_bubble_view_top_pointer = 2131558494;
    public static final int display_always = 2131558408;
    public static final int inline = 2131558420;
    public static final int large = 2131558410;
    public static final int left = 2131558423;
    public static final int messenger_send_button = 2131558613;
    public static final int never_display = 2131558409;
    public static final int normal = 2131558411;
    public static final int open_graph = 2131558413;
    public static final int page = 2131558414;
    public static final int right = 2131558424;
    public static final int small = 2131558412;
    public static final int standard = 2131558418;
    public static final int top = 2131558421;
    public static final int unknown = 2131558415;
  }
  
  public static final class layout
  {
    public static final int com_facebook_activity_layout = 2130903059;
    public static final int com_facebook_login_fragment = 2130903060;
    public static final int com_facebook_tooltip_bubble = 2130903061;
    public static final int messenger_button_send_blue_large = 2130903104;
    public static final int messenger_button_send_blue_round = 2130903105;
    public static final int messenger_button_send_blue_small = 2130903106;
    public static final int messenger_button_send_white_large = 2130903107;
    public static final int messenger_button_send_white_round = 2130903108;
    public static final int messenger_button_send_white_small = 2130903109;
  }
  
  public static final class string
  {
    public static final int com_facebook_image_download_unknown_error = 2131230735;
    public static final int com_facebook_internet_permission_error_message = 2131230733;
    public static final int com_facebook_internet_permission_error_title = 2131230732;
    public static final int com_facebook_like_button_liked = 2131230723;
    public static final int com_facebook_like_button_not_liked = 2131230722;
    public static final int com_facebook_loading = 2131230731;
    public static final int com_facebook_loginview_cancel_action = 2131230730;
    public static final int com_facebook_loginview_log_in_button = 2131230725;
    public static final int com_facebook_loginview_log_in_button_long = 2131230726;
    public static final int com_facebook_loginview_log_out_action = 2131230729;
    public static final int com_facebook_loginview_log_out_button = 2131230724;
    public static final int com_facebook_loginview_logged_in_as = 2131230727;
    public static final int com_facebook_loginview_logged_in_using_facebook = 2131230728;
    public static final int com_facebook_send_button_text = 2131230737;
    public static final int com_facebook_share_button_text = 2131230736;
    public static final int com_facebook_tooltip_default = 2131230734;
    public static final int messenger_send_button_text = 2131230721;
  }
  
  public static final class style
  {
    public static final int MessengerButton = 2131296256;
    public static final int MessengerButtonText = 2131296263;
    public static final int MessengerButtonText_Blue = 2131296264;
    public static final int MessengerButtonText_Blue_Large = 2131296265;
    public static final int MessengerButtonText_Blue_Small = 2131296266;
    public static final int MessengerButtonText_White = 2131296267;
    public static final int MessengerButtonText_White_Large = 2131296268;
    public static final int MessengerButtonText_White_Small = 2131296269;
    public static final int MessengerButton_Blue = 2131296257;
    public static final int MessengerButton_Blue_Large = 2131296258;
    public static final int MessengerButton_Blue_Small = 2131296259;
    public static final int MessengerButton_White = 2131296260;
    public static final int MessengerButton_White_Large = 2131296261;
    public static final int MessengerButton_White_Small = 2131296262;
    public static final int com_facebook_button = 2131296271;
    public static final int com_facebook_button_like = 2131296272;
    public static final int com_facebook_button_send = 2131296275;
    public static final int com_facebook_button_share = 2131296276;
    public static final int com_facebook_loginview_default_style = 2131296273;
    public static final int com_facebook_loginview_silver_style = 2131296274;
    public static final int tooltip_bubble_text = 2131296270;
  }
  
  public static final class styleable
  {
    public static final int[] com_facebook_like_view = { 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979 };
    public static final int com_facebook_like_view_com_facebook_auxiliary_view_position = 4;
    public static final int com_facebook_like_view_com_facebook_foreground_color = 0;
    public static final int com_facebook_like_view_com_facebook_horizontal_alignment = 5;
    public static final int com_facebook_like_view_com_facebook_object_id = 1;
    public static final int com_facebook_like_view_com_facebook_object_type = 2;
    public static final int com_facebook_like_view_com_facebook_style = 3;
    public static final int[] com_facebook_login_view = { 2130771968, 2130771969, 2130771970, 2130771971 };
    public static final int com_facebook_login_view_com_facebook_confirm_logout = 0;
    public static final int com_facebook_login_view_com_facebook_login_text = 1;
    public static final int com_facebook_login_view_com_facebook_logout_text = 2;
    public static final int com_facebook_login_view_com_facebook_tooltip_mode = 3;
    public static final int[] com_facebook_profile_picture_view = { 2130771972, 2130771973 };
    public static final int com_facebook_profile_picture_view_com_facebook_is_cropped = 1;
    public static final int com_facebook_profile_picture_view_com_facebook_preset_size = 0;
  }
}


/* Location:              C:\Users\ADMIN\Desktop\foss\dex2jar-2.0\classes-dex2jar.jar!\com\facebook\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */