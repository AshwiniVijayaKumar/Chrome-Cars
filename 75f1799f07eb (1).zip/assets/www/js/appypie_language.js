var home_mcom = "Home";
var my_shop_mcom = "My Shop";
var login_signup_mcom = "Login/Sign Up";
var cart_mcom = "Cart";
var my_account_mcom = "My Account";
var My_Orders_mcom = "My Orders";
var featured_product_mcom = "Featured Product";
var categories_mcom = "Categories";
var submit_mcom = "Submit";
var forgot_password_mcom = "Forgot Password";
var email_id_mcom = "Email Id";
var password_mcom = "Password";
var do_not_have_an_account_mcom = "Do not have an account?";
var search_mcom = "Search";
var sign_up_now_mcom = "Sign Up Now";
var name_mcom = "Name";
var phone_mcom = "Phone";
var confirm_password_mcom = "Confirm Password";
var sign_up_mcom = "Sign Up";
var already_have_an_account_mcom = "Already have an account?";
var sign_in_mcom = "Sign In";
var contact_information_mcom = "Contact Information";
var my_address_mcom = "My Address";
var default_billing_address_mcom = "Default Billing Address";
var default_shipping_address_mcom = "Default Shipping Address";
var order_history_mcom = "Order History";
var order_id_mcom = "Order Id";
var billing_address_mcom = "Billing Address";
var shipping_address_mcom = "Shipping Address";
var order_detail_mcom = "Order Detail";
var product_name_mcom = "Product Name";
var price_mcom = "Price";
var qty_mcom = "Qty";
var order_date_mcom = "Order Date";
var subtotal_mcom = "Subtotal";
var tax_mcom = "Tax";
var coupon_mcom = "Coupon";
var discount_mcom = "Discount";
var shipping_mcom = "Shipping";
var grand_total_mcom = "Grand Total";
var payment_method_mcom = "Payment Method";
var order_status_mcom = "Order Status";
var personal_information_mcom = "Personal Information";
var change_password_mcom = "Change Password";
var current_password_mcom = "Current Password";
var confirm_new_password_mcom = "Confirm New Password";
var no_product_exists_mcom = "No Product Exists";
var add_to_cart_mcom = "Add To Cart";
var cart_list_mcom = "Cart List";
var edit_mcom = "Edit";
var done_mcom = "Done";
var payment_details_mcom = "Payment Details";
var apply_coupon_code_mcom = "Apply Coupon Code";
var enter_your_coupon_code_if_you_have_one_mcom = "Enter coupon code";
var apply_mcom = "Apply";
var continue_shopping_mcom = "Continue Shopping";
var checkout_mcom = "Checkout";
var first_name_mcom = "First Name";
var last_name_mcom = "Last Name";
var address_mcom = "Address";
var zip_postal_code_mcom = "Zip/Postal Code";
var city_mcom = "City";
var country_mcom = "Country";
var state_province_mcom = "State/Province";
var telephone_mcom = "Telephone";
var fax_mcom = "Fax";
var same_as_billing_address_mcom = "Same as Billing Address";
var pay_now_mcom = "PROCEED TO PAY";
var cash_on_delivery_mcom = "Cash On Delivery";
var please_click_on_place_order_button_to_place_the_order_mcom = "Please Click On Place Order Button To Place The Order";
var credit_card_mcom = "Credit Card";
var paypal_mcom = "Paypal";
var you_will_be_redirected_to_paypal_site_mcom = "You will be redirected to paypal site";
var order_by_phone_mcom = "Order by Phone";
var you_can_order_by_calling_mcom = "You can order by calling";
var place_order_mcom = "Place Order";
var instock_mcom = "Instock";
var out_of_stock_mcom = "Out Of Stock";
var test_mcom = "Test mcom";
var instructions_mcom = "Instructions";
var search_product_mcom = "Serach Product";
var login_mcom = "Login";
// *********start new var**********//
var logout_mcom = "Logout";
var notifications_mcom = "Notifications";
var offers_mcom = "Offers";
var wishlist_mcom = "Wish List";
var settings_mcom = "Settings";
var tc_mcom = "Terms and conditions";
var privacy_policy_mcom = "Privacy policy";
var alert_mcom = 'Alert!';
var please_mcom = 'Please enter a keyword to search';
var empty_mcom = "Empty search";
var result_mcom = "result!";
var tryanother_mcom = "try another keyword";
var searchresult_mcom = "Search Result for";
var sortby_mcom = "Sort By";
var popularityg_mcom = "Popularity";
var pricehighlow_mcom = "Price High-Low";
var pricelowhigh_mcom = "Price Low-High";
var msgg_mcom = "There is no product added";
var selectg_mcom = "Select";
var sorryg_mcom = "Sorry";
var quantityoutofstock_mcom = "Quantity Out of Stock";
var pleaseselectg_mcom = "Please select ";
var errorg_mcom = "Error";
var okg_mcom = "Ok";
var productsuccessfullyaddedinyourcartg_mcom = "Product successfully Added In Your Cart.";
var quantityshouldbegreaterthanzerog_mcom = "Quantity should be greater than zero";
var pproductsuccessfullyaddedinyourcartg_mcom = 'Product successfully Added In Your Cart';
var qquantity_mcom = "Quantity";
var pprice_mcom = "Price";
var ttotalpayableamount_mcom = "Total Payable Amount:";
var coupong_mcom = "Coupon";
var subtotalg_mcom = "Sub Total";
var discountg_mcom = "Discount ";
var deliverychargeg_mcom = "Delivery Charge ";
var cartemptyg_mcom = "Your Cart is ";
var eemptyg_mcom = "Empty!";
var additemnowg_mcom = "Add items to it now";
var gotohomeg_mcom = "Go to Home";
var ccouponpageg_mcom = "Coupon Page";
var notavalidcoupong_mcom = "Not a valid coupon ";
var entercouponcodeg_mcom = "Enter Coupon Code";
var applygg_mcom = "Apply";
var ddeliverychargegg_mcom = "Delivery Charge ";
var homeeg_mcom = "Home";
var myAccountg_mcom = "My Account";
var termsconditionsgg_mcom = "Terms & Conditions";
var privacypolicygg_mcom = "Privacy Policy";
var shippingaddressdifferentfrombillingdddressgg_mcom = " Shipping Address Different From Billing Address";
var dddeliverychargegg_mcom = "Delivery Charge ";
var ccompletepurchasegg_mcom = "COMPLETE PURCHASE";
var iinvalidloginidorpasswordgg_mcom = "Invalid login id or password.";
var nnamegg_mcom = "Name ";
var pphonenumbergg_mcom = "Phone Number";
var wwehavesentaemailtoyouremailidgg_mcom = "We have sent an email to your email id";
var eenteryyouremailgg_mcom = "Enter your email";
var ppleaseenterusernamegg_mcom = "Please Enter Username.";
var ppleaseemailidgg = "Please Email Id.";
var ppleaseentervalidemailidgg_mcom = "Please Enter Valid Email Id.";
var ppleaseenterphonenumbergg_mcom = "Please Enter Phone Number.";
var ppleaseentervalidphonenumbergg_mcom = "Please Enter Valid Phone Number.";
var ppleaseenterpasswordgg_mcom = "Please Enter Password.";
var cconfirmpassworddonotmatchgg_mcom = "Confirm Password do not match.";
var eemailidalreadyregisteredgg_mcom = "Email Id Already Registered";
var eerrorgg_mcom = "Error";
var OoKgg_mcom = "OK";
var uuhohgg_mcom = "Uh-oh";
var iinvalidemailiidggg_mcom = "Invalid email ID.";
var yyouhavenotbeenregisteredwithusyetgg_mcom = "You have not been registered with us yet.";
var ppasswordresetwassuccessfullpleasecheckyouremailfornewpasswordgg_mcom = "Password Reset was successfull,Please check your email for new password.";
var eeerrorgg_mcom = "Error";
var ppleaseenteremailidggg_mcom = "Please enter email id";
var iiinvalidemailaddressggg_mcom = "Invalid email address";
var ppppleaseenterpasswordgggg_mcom = "Please enter password";
var uuusernotexistggg_mcom = "User not exist";
var yyyouhaveenteredwrongpasswordggg_mcom = "You have entered wrong password";
var ooordersnotfoundgggg_mcom = "Orders not found.";
var wwriterreviewggg_mcom = "Write Review";
var cccancelggg_mcom = "Cancel";
var rrreorderggg_mcom = "Reorder";
var ppproductnnamegg_mcom = "Product Name";
var qqquantitygggg_mcom = "Quantity";
var ppppricegggg_mcom = "Price";
var dddddeliverychargeggg_mcom = "delivery Charge";
var tttipggg_mcom = "Tip";
var ccccouponddiscountgggg_mcom = "Coupon Discount";
var tttotalpayableaamountggg_mcom = "Total Payable Amount";

var cccommentgggg_mcom = "Comment";
var rrrrreordergggg_mcom = "Reorder";
var pppaymentofproductorderforgggg_mcom = "Payment of Product order for";
var ttthankggg_mcom = "Thank";
var yyyouggg_mcom = "You";
var ooorderidddggg_mcom = "Order ID";
var cccontinuemypoordersggg_mcom = "Continue My Orders";
var gggtohhomegggg_mcom = "Go to Home";
var wwevereceivedouordergg_mcom = "We\'ve received your order";
var yyourorderwassuccessfulgg_mocom = "Your Order was successful";
var wwearesorrygg_com = "We are sorry";
var wwwriteeviewgg_mcom = "Write a Review";
var postreviewguidelinesggg_mcom = "Guidelines for writing a product review. All fields are mandatory. Please do not include: HTML, references to other retailers, pricing, personal information, any profane, inflammatory or copyrighted comments, or any copied content.";
var pppposteviewggg_mocom = "Post Review";
var eviewitleggg_mcom = "Review Title";
var ooommentgg_mcom = "Comment";
var ppppostreviewgg_mcom = "Post Review";
var eeeerrorggg_mcom = "Error";
var ppleaseenterthereviewtitleggg_mcom = "Please enter the review title";
var pppleaseenterthereviewtextggg_mcom = "Please enter the review text";
var rrrequiredfieldsaremissingggg_mcom = "Required fields are missing";
var nnetworkerrorggg_mcom = "Network error";
var ppleasecheckyourinternetconnectionggg_mcom = "Please check your internet connection";
var ooorderhasbeennottakenorcompletedgggg_mcom = "Order has been not taken or completed";
var nnnotificationggg_mcom = "Notification";
var eeeeemptygggg_mcom = "Empty";
var ttthereisnonotificationlistgggggg_mocom = "There is no notification list.";
var ggotohhomeggg_mcpm = "Go to Home";
var iiiiteminyourordergggg_mcom = "item in your order";
var hhhhasbeenshippedbysellerggggg_mcom = "has been shipped by seller.";

var iinformationupdatedssuccessfullygg_mcom = "Information Updated Successfully.";
var nnnameggg_mcom = "Name";
var eeemailaaddressggg_mcom = "Email Address";
var eeenteryouremailiddggg_mcom = "Enter your Email ID";
var tttelephonenoggg_mcom = "Telephone No";
var uupdateccontactinformationgg_mcom = "Update Contact Information";
var bbbillinginformationupdatedsuccessfullyggg_mcom = "Billing Information Updated Successfully.";
var sstreetaaddressgg_mcom = "Street Address";
var eenteryyourccitygg_mcom = "Enter Your City";
var eeentersstatepprovincegg_mcom = "Enter State/Province";
var eeenterzzippostalcodegg_mcom = "Enter Zip/Postal Code";
var zzipppostalcodegg_mcom = "Zip/Postal Code";
var sstreetaaddressggg_mcom = "Street Address";
var aaaddressdifferentfrombillingaaddressgg_mcom = "Address Different From Billing Address";
var uupdatebillingiinformationgg_mcom = "Update Billing Information";
var sshippinginformationupdatedsuccessfullyggg_mcom = "Shipping Information Updated Successfully";
var uupdatesshippingiinformationgg_mcom = "Update Shipping Information";

var sselectfromwhereyouwanttouuuploadgg_mcom = "Select from where you want to upload!";
var mmessagegg_mcom = "Message";
var cameragg_mcomn = "Camera";
var ggallerygg_mcom = "Gallery";

var sssuccessfullyuuploadedgg_mcom = 'successfully Uploaded!';
var uuploadeerrorgg_mcom = 'Upload error';
var eerrorggg_mcom = 'Error';
var ppleastryagaingg_mcom = "Please try again";
var nnetworkrrorgg_mcom = 'Network error';
var nnoreviewavalaiblegg_mcom = "No reviews avalaible";
var cccreatecountgg_mcom = "Create Account";
var missingrequiredfieldspleasereloginntragaingg_mcom = "Missing required fields please re-login and try again";

var pproductsgg_mcom = "Products ";
var tthereisnishlisproductgg_mcom = "There is no Wishlist product.";

var tthereisnofferedproductgg_mcom = "There is no offered product.";
var tthereisnofeatureproductgg_mcom = "There is no featured product.";

/* ----------------Ecom complete--------------------------------- */

var iinvalidddategg_ment = 'Invalid Date';
var Appointmentdateisnotalidgg_ment = 'Appointment date is not valid.';
var eerrorgg_ment = 'Error';
var pleaseselectadatebeforetimegg_ment = 'Please select a date before time.';
var appointmentcanttimeslot_ment = 'Appointment can\'t set between this time, Please choose another time slot.';
var appointmentcurrenttime_memt = 'Appointment can\'t set in current time, Please choose another time slot.';
var appointmentpasttime_ment = 'Appointment can\'t set in past time, Please choose future time slot.';
var dateblank_ment = '*Date field cannot be left blank';
var alert_ment = 'Alert';
var remark_ment = '*Remark field cannot be left blank';
var pleaseprovideavalidphonenumber_ment = 'Please provide a valid phone number';
var enteravalidmailaaaddress_ment = 'Enter a valid E-mail address';
var nameblank_ment = '*Name field cannot be left blank';
var timeblank_ment = '*Time field cannot be left blank';

/* ----------------Appointment complete--------------------------------- */

var couldnotreadfilegg_audio = "could not read file: ";

/* ----------------Audio complete--------------------------------- */

var alert_blog = 'Alert';
var datanotfound_blog = 'Data not found.';
var datafound_blog = 'Data not found. \n Please try after some time';

/* ----------------Blog complete--------------------------------- */

var namefiled_chat = ' Name field cannot be left blank';
var alert_chat = 'Alert';
var ok_chat = 'OK';
var send_chat = "send";
var uploadpic_chat = "Upload Pic";
var screen_chat = "Screen Name";
var next_chat = "Next";
var update_chat = "Update";
var selectfromwhereyouwanttoupload_chat = 'Select from where you want to upload';
var message_chat = 'Message';
var unableto_chat = 'Unable to select image';
var alert_chat = 'Alert';
var ok_chat = 'OK';
/* ----------------Chat complete--------------------------------- */

var error_contact = "error in network connection";
/* ----------------Contact complete--------------------------------- */

var couponcode_coupon = 'Coupon Code';
var termcondition_coupon = 'Terms & Conditions ';
/* ----------------Coupon complete--------------------------------- */

var warning_deeplink = 'Warning';
var deeplinkingurlnoadded = 'Deeplinking url not added';
/* ----------------Deeplink complete--------------------------------- */

var error_website = 'Error';
var pleaseentercorrectweburl_website = 'Please enter correct web url.';
/* ----------------Website complete--------------------------------- */

var youhavebeenblocked_wallpost = 'You have been blocked';
var message_wallpost = 'Message';
var ok_wallpost = 'OK';
var namefieldcannotbeleftblank_wallpost = 'Name field cannot be left blank';
var uploadpic_wallpost = "Upload Pic";
var screenname_wallpost = "Screen Name";
var next_wallpost = "Next";
var enduserlicenseagreement_wallpost = "End User License Agreement";
var thisenduserlicenseagreement_wallpost = "This End User License Agreement ( Agreement ) is between you and "; 
var andgovernsuseof_wallpost = " and governs use of this app made available through the Apple App Store. By installing the ";
var apyouagree_wallpost = " App, you agree to be bound by this Agreement and understand that there is no tolerance for objectionable content. If you do not agree with the terms and conditions of this Agreement, you are not entitled to use the  ";  
var  appnordertoensure_wallpost = " App. <br><br> In order to ensure  "; 
var  providesthebestexperiencepossible_wallpost = " provides the best experience possible for everyone, we strongly enforce a no tolerance policy for objectionable content. If you see inappropriate content, please use the  Report as offensive  feature found under each post. <br><br> 1. Parties <br>This Agreement is between you and  ";  
var  onlandnopplenc_wallpost = " only, and not Apple, Inc. ( Apple ). Notwithstanding the foregoing, you acknowledge that Apple and its subsidiaries are third party beneficiaries of this Agreement and Apple has the right to enforce this Agreement against you.  "; 
var notappleis_wallpost = ", not Apple, is solely responsible for the  ";  
var  aappandits = " App and its content.<br><br> 2. Privacy <br> "; 
var  maycollectanduse_wallpost = " may collect and use information about your usage of the  "; 
var  appincludingcertaintypesof_wallpost = " App, including certain types of information from and about your device.  ";  
var  mayusethisinformationaslongas_wallpost = " may use this information, as long as it is in a form that does not personally identify you, to measure the use and performance of the  ";  
var  applimited = " App. <br><br> 3. Limited License <br> ";
var  grantsyoualimitednon = " grants you a limited, non-exclusive, non-transferable, revocable license to use the "; 
var  appyourpersonal_wallpost = " App for your personal, non-commercial purposes. You may only use the "; 
var  apponappledevices_wallpost = " App on Apple devices that you own or control and as permitted by the App Store Terms of Service. <br><br> 4. Age Restrictions <br>By using the  ";  
var  apprepresenwarrant_wallpost = " App, you represent and warrant that (a) you are 17 years of age or older and you agree to be bound by this Agreement; (b) if you are under 17 years of age, you have obtained verifiable consent from a parent or legal guardian; and (c) your use of the  ";  
var  apviolateapplicable_wallpost = " App does not violate any applicable law or regulation. Your access to the  ";  
var  appmaterminated_wallpost = " App may be terminated without warning if  ";  
var  believessole_wallpost = " believes, in its sole discretion, that you are under the age of 17 years and have not obtained verifiable consent from a parent or legal guardian. If you are a parent or legal guardian and you provide your consent to your child s use of the  ";  
var  youagreebound_wallpost = " App, you agree to be bound by this Agreement in respect to your child s use of the  ";  
var  objectionablecontentpolicy_wallpost = " App. <br><br> 5. Objectionable Content Policy <br> Content may not be submitted to  ";  
var whowillmoderateall_wallpost = ", who will moderate all content and ultimately decide whether or not to post a submission to the extent such content includes, is in conjunction with, or alongside any, Objectionable Content. Objectionable Content includes, but is not limited to: (i) sexually explicit materials; (ii) obscene, defamatory, libelous, slanderous, violent and/or unlawful content or profanity; (iii) content that infringes upon the rights of any third party, including copyright, trademark, privacy, publicity or other personal or proprietary right, or that is deceptive or fraudulent; (iv) content that promotes the use or sale of illegal or regulated substances, tobacco products, ammunition and/or firearms; and (v) gambling, including without limitation, any online casino, sports books, bingo or poker. <br><br> 6. Warranty <br> "; 
var  disclaimsallwarranties_walpost = " disclaims all warranties about the  ";  
var  fullestextentpermitted_wallpost = " App to the fullest extent permitted by law. To the extent any warranty exists under law that cannot be disclaimed,  ";  
var notappleshall_wallpost = ", not Apple, shall be solely responsible for such warranty. <br><br> 7. Maintenance and Support <br> "; 
var  doesprovideminimalmaintenance_wallpost = " does provide minimal maintenance or support for it but not to the extent that any maintenance or support is required by applicable law,  ";  
var appleshallobligatedfurnish_wallpost = ", not Apple, shall be obligated to furnish any such maintenance or support. <br><br> 8. Product Claims <br> "; 
var responsibladdressing_walpost = ", not Apple, is responsible for addressing any claims by you relating to the  " ; 
var includinglimited_wallpost = " App or use of it, including, but not limited to: (i) any product liability claim; (ii) any claim that the  ";  
var  failsapplicable_wallpost = " App fails to conform to any applicable legal or regulatory requirement; and (iii) any claim arising under consumer protection or similar legislation. Nothing in this Agreement shall be deemed an admission that you may have such claims. <br><br> 9. Third Party Intellectual Property Claims <br> "; 
var  shallobligatedindemnifydefend_wallpost = " shall not be obligated to indemnify or defend you with respect to any third party claim arising out or relating to the  ";  
var  theextent_wallpost = " App. To the extent  ";  
var  isprovideindemnification_wallpost = " is required to provide indemnification by applicable law,  ";  
var solelyinvestigation_wallpost = ", not Apple, shall be solely responsible for the investigation, defense, settlement and discharge of any claim that the  ";  
var useinfringe_wallpost = " App or your use of it infringes any third party intellectual property right.";
var aaccept_walpost = "Accept";
var ddecline_wallpost = "Decline";
var namefieldcannot_wallpost = ' Name field cannot be left blank';
var alert_wallpost = 'Alert';
var selectimagetoupload_wallpost = ' Select image to upload';
var selecupload_wallpost = 'Select from where you want to upload';
var loadmore_wallpost = 'Load More Post'; 
var updatestatus_walpost = 'Update Status';
var addphotovideo_wallpost = 'Add Photo/Video';
var saysomething_wallpost = 'Say something about this video';
var saysomethingimage_wallpost = 'Say something about this photo';
var post_wallpost = 'Post';
var uploadimage_wallpoast = 'Upload Image';
var uploadvideo_wallpost = 'Upload Video';
var showmore_wallpost = 'Show more';
var postedvideo_walpost = 'posted a new video';
var llike_wallpost = ' Like';
var rreportabuse_wallpost = ' Report Abuse';
var comment_walpost = ' Comment';
var viewall_wallpost = 'View All';
var postedphoto_wallpost = ' posted a new photo';
var postedstatus_wallpost = ' posted a new status';
var loadmorepost_wallpost = 'Load More Post';
var messagegg_walpost='Plese enter comment!';
var peoplelikegg_wallpost = 'People Who Like This';
var messagefff_wallpost = 'Please add text to upload!';
var messagesome_wallpost = 'Some Error try again!';
var warning_wallpost = 'Warning';
/* ----------------Wallpost complete--------------------------------- */


var error_video = 'Error';
var datanotfound_video = 'Data not found !';
var ops_video = 'Oops!';
var nodatafound_video = 'No data found';
var showmore_video = "Show More";
var serverresponse_video = 'Server Response';
var datanotserver_video = 'Data not found on server !';
var serverdata_video = 'Server does not return data';
var ok_video = 'OK';
var videos_video = "VIDEOS";
/* ----------------Video complete--------------------------------- */

var defaultbillingaddress_ecomFooddir = 'Default Billing Address';
var defaultshippingaddress_ecomFooddir = 'Default Shipping Address';
var pleaseenterfirstname_ecomFooddir = 'Please enter first name';
var pleaseentertelephoneno_ecomFooddir = 'Please enter telephone no.';
var pleaseentervalidtelephoneo_ecomFooddir = 'Please enter valid telephone no.';
var pleaseenteremailaddress_ecomFooddir = 'Please enter Email Address';
var pleaseentername_ecomFooddir = 'Please Enter Name';
var error_ecomFooddir = 'Error';
var ok_ecomFooddir = 'OK';
var pleaseentervalidphonenumber_ecomFooddir = 'Please Enter Valid Phone number';
var peaseenterreetaddress_ecomFooddir = 'Please Enter Street Address';
var pleaseenteryourcity_ecomFooddir = 'Please Enter Your City';
var pleaserovince_ecomFooddir = 'Please Enter State/Province';
var pleaseostalcode_ecomFooddir = 'Please Enter Zip/Postal Code';
var pleaseentercountry_ecomFooddir = 'Please Enter Country';
/* ----------------EcomFoodDir complete--------------------------------- */

var enterthekeywordtosearch_education = "Enter the keyword to search";
var search_education = "Search";
var suggestions_educatiuon = " Suggestions: ";
var pleaseconnecttointernet_education = "Please Connect To Internet";
var pleasarch_education = "Please select option to search.";
var nomatch_education = "No Match Found!";
var pleasegain_education = "Please Try Again";
var selecategory_education = "Select a category";
var or_education = "OR";
/* ----------------Education complete--------------------------------- */

var pleasecheckinternetconnection_ereader = 'Please check Internet connection.';
var message_ereader = 'Message';
var ok_erader = 'OK';
var downloadingerror_ereader = "downloading error";
var delete_ereader = "Delete";
var selecookselete_ereader = 'Select Books to delete';
var done_ereader = 'Done';
var booklist_ereader = "Book List!";
/* ----------------Ereader complete--------------------------------- */


var oops_event = "oops ! Unable to open";
var weburlnotavailable_event = "Weburl not available.";
var serverresponse_event = 'Server Response';
var nodatafound_event = 'No Data Found,\nPlease try after some time';
var eventee_event = 'Event';
var noupcomingeventfound_event = 'No Upcoming Event Found';
var nopasteventfound_event = 'No Past Event Found';
var showmore_event = "Show More"; 
var upcomingevents_event = "Upcoming Events";
var pastevents_event = "Past Events";
var map_event = "Map";
var share_event = "Share";
/* ----------------Event complete--------------------------------- */


var ErrorEmailField="Please enter valid email.";
var ErrorPhoneField="Please enter valid phone number.";

var pleaseentervalidemail_builder = "Please enter valid email.";
var pleaseentervalidphonenumber_builder = "Please enter valid phone number.";
var checkschedule_builder = "check schedule";
var test_builder = "Test"; 
var schedule_builder = 'schedule';
var sun_builder = 'Sun';
var mon_builderr = 'Mon';
var tue_builder = 'Tue';
var wed_builder = 'Wed';
var thu_builder = 'Thu';
var fri_builder = 'Fri';
var sat_builder = 'Sat';
var closed_builder = ' Closed ';
var selectgender_builder = 'Select Gender';
var male_builder = 'Male';
var female_buildrer = 'Female';
var attachfile_builder = 'Attach File';
var usd_builder = 'USD';
var gbp_builder = 'GBP';
var eur_builder = 'EUR';
var aud_builder = 'AUD';
var cad_builder = 'CAD';
var chf_builder = 'CHF';
var czk_builder = 'CZK';
var dkk_builder = 'DKK';
var hkd_builder = 'HKD';
var huf_builder = 'HUF';
var jpy_builder = 'JPY';
var nok_builder = 'NOK';
var nzd_builder = 'NZD';
var pln_builder = 'PLN';
var sek_builder = 'SEK';
var sgd_builder = 'SGD';
var country_builder ='Country ';
var selectcountry_builder ='Select Country';
var paymenor_builder = "Payment for ";
var notvalid_builder = 'not valid !';
var notvalidemail_builder = 'not valid email !';
var alert_builder = 'Alert';
var ok_builder = 'OK';
var attachmensizeexceed_builder = 'The attachment size exceeds from 8MB';
/* ----------------Formbuilder complete--------------------------------- */

var photos_gallery = "Photos";
var serverresponse_gallery = 'Server Response';
var unableloadphotos_gallery = 'Unable to load Photos !';
var error_gallery = 'Error!';
var albumempty_gallery = 'Album is empty';
var followedby_gallery = "Followed By";
var follows_gallery = 'Follows';
var showmore_gallery = 'Show More';
var photostream_gallery = "Photostream";
var sets_gallery = "Sets";
var alert_gallery = 'Alert';
var nosetfound_gallery = 'No Sets Found!';
var photooo_gallery = "Photo";
var viewallets = "View All Sets";
/* ----------------Gallery complete--------------------------------- */

var follow_plus = "Follow";
/* ----------------gogleplus complete--------------------------------- */

var servernotdata_insta = 'Server does not return data';
var datanotserver_insta ='Data not found on server !';
var photo_insta = "Photo";
var follow_insta = "follow";
var following_insta = "Following";
var showmore_insta = "Show More";
var comments_insta = "comments";
var likes_insta = "likes";
var likethis_insta = "like this";
/* ----------------instagram complete--------------------------------- */




var oops_loyalty = 'Oops';
var serverresponding_loyalty = 'Server not responding\n Please try again later';
var alert_loyalty = 'Alert!!';
var cardalreadyredeemed_loyalty = 'The card is already redeemed';
var error_loyalty = 'Error';
var pleaseuseyourfreebiestamp_loyalty = 'Please use your freebie stamp';
var typingecuritycode_loyalty = "Validate by typing the Security code";
var validatescanningcode_loyalty = "Validate by scanning the QR Code";
var congrats_loyalty = "Congrats!";
var networkproblem_loyalty = 'Network Problem';
var internetnotavailable_loyalty = 'Internet not available';
var invalidcode_loyalty = 'Invalid Code';
var pleaseentervalidcode_loyalty = 'Please enter a valid code';
/* ----------------loyalty complete--------------------------------- */


var loyaltycardMobHeaderLabel = "Membership Request Form s";
var loyaltycardMobNameLabel = "Name";
var loyaltycardMobEmailLabel = "Email ";
var loyaltycardMobPhoneLabel = "Phone No";

var serverresponse_card = 'Server Response';
var yourcardtemporarydisapproved_card = 'Your Card is Temporary Disapproved';
var unableloaddata_card = 'Unable to load Data!';
var joinloyaltyprogram_card = "Join Our Loyalty Program"; 
var datanotfound_card = 'Data not found!';
var alert_card = 'Alert';
var pleasephonenumber_card = 'Please Enter a Valid Phone Number';
var issuedate_card = "Issue Date";
var id_card = "ID: ";
var validtill_card = "Valid Till";
var point_card = "Points";
var balance_card = "Balance";
var scancode_card = "Scan the QR Code";
var add_card = "Add";
var redeem_card = "Redeem";
var ok_card = 'OK';
var mandatoryfieldsblank_card = 'Mandatory fields should not be blank.';
var entervalid_card = 'Enter a valid Email Id';
var availablepoints_card = "Available points: ";
var pleasehandcashieraddpoints_card = "Please hand over your device to the cashier to add points.";
var validatetypingsecuritycode_card = "Validate by typing the Security code";
var validatescanningqrcode_card = "Validate by scanning the QR Code";
var cancel_card = "Cancel";
var enterpoints_card = "Enter points";
var entersecuritycode_card = "Enter security code";
var pleasehanddeviceredeempoints_card = "Please hand over your device to the cashier to Redeem points.";
var warning_card = 'Warning';
var pleaseentervalidunlockcode_card = 'Please enter valid unlock code';
var insufficientpoints_card = 'Insufficient points';
var pleaseenterredeemvaluegreater_card = 'Please enter redeem value greater then 0';
var pleaseenteraddvaluegreater_card = 'Please enter add value greater then 0';
var pleasetryagain_card = 'Please try again';
var pleaseenterpoints_card = 'Please enter points';
var nofunctionalityimplemented_card = 'no functionality implemented';
/* ----------------loyaltycard complete--------------------------------- */

var geolocationnotsupportedbrowser_map = "Geolocation is not supported by this browser.";
/* ----------------map complete--------------------------------- */


/******************** START GEETA CODE **************************************/

/*---------------- START TEXTPAGE JS ------------------------------- */

// in this js no changes.

/*---------------- END TEXTPAGE JS ------------------------------- */

/*---------------- START TESTIMONIAL JS ------------------------------- */

// in this js no changes.

/*---------------- END TESTIMONIAL JS ------------------------------- */
/*---------------- START SURVEY JS ------------------------------- */
    	       // in this js no changes.
    	/*---------------- END SURVEY JS ------------------------------- */

    	/*---------------- START SOCIAL JS ------------------------------- */
            	       // in this js no changes.
         /*---------------- END SOCIAL JS ------------------------------- */

         /*---------------- START RELIGIOUS JS ------------------------------- */
                     	       // in this js no changes.
         /*---------------- END RELIGIOUS JS ------------------------------- */

/*---------------- START REFERSHANDPUSH JS ------------------------------- */
                     	       // in this js no changes.
/*---------------- END REFERSHANDPUSH JS ------------------------------- */

/*---------------- START QRCODE JS ------------------------------- */
                     	       // in this js no changes.
/*---------------- END QRCODE JS ------------------------------- */

/*---------------- START OPENTABLE JS ------------------------------- */
                     	       // in this js no changes.
/*---------------- END OPENTABLE JS ------------------------------- */

/*---------------- START TOOLS JS ------------------------------- */
var mortage_cal_heading_tools = "Mortgage Calculator";
var mortage_cal_home_price_tools = "Home Price";
var mortage_cal_down_payment_tools = "Down Payment";
var mortage_cal_down_payment_less_home_price_tools = "Down Payment should be less than Home Price";
var mortage_cal_loan_amt_tools = "Loan Amount";
var mortage_cal_interest_rate_tools = "Interest Rate";
var mortage_cal_loan_term_tools = "Loan Term";
var mortage_cal_annual_prop_tax_tools = "Annual Property Taxes";
var mortage_cal_insurance_tools = "Insurance";
var mortage_cal_monthly_amt_tools = "Monthly Amount";
var mortage_cal_amt_tools = "Amount";
var mortage_cal_calculate_tools = "CALCULATE";
var mortage_cal_estimate_monthly_cal_tools = "This estimated payment does not include monthly mortgage insurance premiums. Your loan could be subject to monthly mortgage insurance. Please contact your lender to clarify if your loan will have monthly mortgage insurance.";
var alert_blank_field_tools = "Blank Field";
var alert_enter_price_amt_tools = "Please Enter the Price Amount";
var alert_enter_down_pay_amt_tools = "Please Enter the Down Payment Amount";
var weather_address_title_tools = "Click for to see a weather report";
var inner_html_msg_location_not_found_tools = "The location could not be found";
var inner_html_msg_error_occured_tools = "An error has occurred";
var alert_for_alert_title_tools = "Alert";
var alert_internet_conn_not_avail_tools = "Internet connection is not available";
var alert_unable_to_retrive_current_location_tools = "Unable to retrieve your current location. Please turn on Settings->Privacy->Location Services for App.";
var in_serach_click_weather_geocode_weatherloaction_tools = "weatherLocation";
var in_serach_click_weather_geocode_weatherlist_tools = "weatherList";

/*---------------- END TOOLS JS ------------------------------- */

/*---------------- START TWITTER JS ------------------------------- */
var alert_server_response_twitter = "Server Response";
var alert_data_not_found_on_server_twitter = "Data not found on server !"
var create_twit_screen_follow_twitter = "Follow";
var create_twit_screen_tweets_twitter = "Tweets";
var create_twit_screen_followers_twitter = "Followers";
/*---------------- END TWITTER JS ------------------------------- */
/*---------------- START SOCIALAPP JS ------------------------------- */
            	      var social_menu_slide_main_menu_soicalapp = "Main Menu";
                      var social_login_fb_twitter_msg_socialapp = "Not able to login try again!";
                      var social_login_fb_alert_socialapp = "Alert";
                      var social_login_fb_alert_ok_socialapp = "OK";
                      var get_social_login_dont_have_account_yet_socialapp = "Don't have an account yet";
                      var get_social_login_signup_now_socialapp = "Sign Up Now";
                      var get_social_login_email_id_socialapp = "Email-Id";
                      var get_social_login_password_socialapp = "Password";
                      var get_social_login_forgot_pass_socialapp = "Forgot your password ?";
                      var get_social_login_placeholder_emailid_socialapp = "Email-Id";
                      var get_social_login_placeholder_password_socialapp = "Password";
                      var email_already_exist_socialapp = "Email id already exist!";
                      var enter_valid_email_id_socialapp = "Please Enter a valid Email Id!";
                      var please_enter_pass_socialapp = "Please enter password!";
                      var please_enter_email_socialapp = "Please enter email!";
                      var blocked_user_contact_admin_socialapp = "This user has been blocked. Please contact to Administrator";
                      var alert_warning_socialapp = "Warning";
                      var invalid_nameandpass_socialapp = "Invalid User name or password";
                      var invalid_credential_socialapp = "Invalid Credential";
                      var user_blocked_socialapp = "You have been blocked!";
                      var alert_message_socialapp = "Message";
                      var div_forgotten_pass_socialapp = "Forgotten Password";
                      var div_email_id_socialapp = "E-mail:";
                      var div_image_code_socialapp = "Image Code";
                      var div_placeholdere_email_socialapp = "Please enter your email";
                      var div_placeholdere_image_code_socialapp = "Please enter below image code";
                      var enter_captcha_image_socialapp = "Please enter below image code!";
                      var incorrect_captcha_code_socialapp = "Incorrect Code Entered!";
                      var new_pass_sent_onyour_mail_socialapp = "New password has been sent to email address";
                      var alert_msg_for_success_socialapp = "Success";
                      var email_not_match_our_record_socialapp = "Email not matched with our record";
                      var msg_fail_socialapp ="fail";
                      var msg_email_not_match_our_record_enter_register_mail_socialapp = "Email not matched with our record! Please enter your registered email.";
                      var signuppagesocial_html_signup_forapp_socialapp = "Sign Up for App";
                      var signuppagesocial_html_username_socialapp = "Username*";
                      var signuppagesocial_html_placeholder_username_socialapp = "Username";
                      var signuppagesocial_html_emailid_socialapp = "E-mail ID*";
                      var signuppagesocial_html_placeholder_emaiid_socialapp = "Email-ID";
                      var signuppagesocial_html_pass_socialapp = "Password*";
                      var signuppagesocial_html_placeholder_pass_socialapp = "Password";
                      var signuppagesocial_html_conpass_socialapp = "Confirm Password*";
                      var signuppagesocial_html_placeholder_conpass_socialapp = "Confirm Password";
                      var signuppagesocial_html_usr_licence_agreement_socialapp = "End User License Agreement";
                      var signuppagesocial_html_justify_licence_one_socialapp = "This End User License Agreement ( Agreement ) is between you and";
                      var signuppagesocial_html_justify_licence_two_socialapp = "and governs use of this app made available through the Apple App Store. By installing the";
                      var signuppagesocial_html_justify_licence_third_socialapp = "App, you agree to be bound by this Agreement and understand that there is no tolerance for objectionable content. If you do not agree with the terms and conditions of this Agreement, you are not entitled to use the";
                      var signuppagesocial_html_justify_licence_fourth_socialapp = "In order to ensure";
                      var signuppagesocial_html_justify_licence_third_socialapp = "provides the best experience possible for everyone, we strongly enforce a no tolerance policy for objectionable content. If you see inappropriate content, please use the  Report as offensive  feature found under each post.";
                      var signuppagesocial_html_justify_licence_fourth_br_socialapp = "1.  Parties";
                      var signuppagesocial_html_justify_licence_fourth_br_one_socialapp = "This Agreement is between you and";
                      var signuppagesocial_html_justify_licence_fifth_socialapp = "only, and not Apple, Inc. ( Apple ). Notwithstanding the foregoing, you acknowledge that Apple and its subsidiaries are third party beneficiaries of this Agreement and Apple has the right to enforce this Agreement against you.";
                      var signuppagesocial_html_justify_licence_six_socialapp = ", not Apple, is solely responsible for the";
                      var signuppagesocial_html_justify_licence_seven_socialapp = "App and its content.";
                      var signuppagesocial_html_justify_licence_seven_br_socialapp = "2. Privacy";
                      var signuppagesocial_html_justify_licence_eight_socialapp = "may collect and use information about your usage of the";
                      var signuppagesocial_html_justify_licence_nine_socialapp = "App, including certain types of information from and about your device.";
                      var signuppagesocial_html_justify_licence_ten_socialapp = "may use this information, as long as it is in a form that does not personally identify you, to measure the use and performance of the";
                      var signuppagesocial_html_justify_licence_app_socialapp = "App.";
                      var signuppagesocial_html_justify_licence_ten_br_socialapp = "3. Limited License";
                      var signuppagesocial_html_justify_licence_eleven_socialapp = "grants you a limited, non-exclusive, non-transferable, revocable license to use the";
                      var signuppagesocial_html_justify_licence_tweleve_socialapp = "App for your personal, non-commercial purposes. You may only use the";
                      var signuppagesocial_html_justify_licence_thirteen_socialapp = "App on Apple devices that you own or control and as permitted by the App Store Terms of Service.";
                      var signuppagesocial_html_justify_licence_thirteen_br_socialapp = "4. Age Restrictions ";
                      var signuppagesocial_html_justify_licence_byusing_socialapp = "By using the";
                      var signuppagesocial_html_justify_licence_fourteen_socialapp = "App, you represent and warrant that (a) you are 17 years of age or older and you agree to be bound by this Agreement; (b) if you are under 17 years of age, you have obtained verifiable consent from a parent or legal guardian; and (c) your use of the";
                      var signuppagesocial_html_justify_licence_fifteen_socialapp = "App does not violate any applicable law or regulation. Your access to the";
                      var signuppagesocial_html_justify_licence_sixteen_socialapp = "App may be terminated without Alert if";
                      var signuppagesocial_html_justify_licence_seventeen_socialapp = "believes, in its sole discretion, that you are under the age of 17 years and have not obtained verifiable consent from a parent or legal guardian. If you are a parent or legal guardian and you provide your consent to your child s use of the";
                      var signuppagesocial_html_justify_licence_eighteen_socialapp = "App, you agree to be bound by this Agreement in respect to your child s use of the";
                      var signuppagesocial_html_justify_licence_eighteen_br_socialapp = "5. Objectionable Content Policy";
                      var signuppagesocial_html_justify_licence_nineteen_socialapp = "Content may not be submitted to";
                      var signuppagesocial_html_justify_licence_twentyone_socialapp = ", who will moderate all content and ultimately decide whether or not to post a submission to the extent such content includes, is in conjunction with, or alongside any, Objectionable Content. Objectionable Content includes, but is not limited to: (i) sexually explicit materials; (ii) obscene, defamatory, libelous, slanderous, violent and/or unlawful content or profanity; (iii) content that infringes upon the rights of any third party, including copyright, trademark, privacy, publicity or other personal or proprietary right, or that is deceptive or fraudulent; (iv) content that promotes the use or sale of illegal or regulated substances, tobacco products, ammunition and/or firearms; and (v) gambling, including without limitation, any online casino, sports books, bingo or poker.";
                      var signuppagesocial_html_justify_licence_twentyone_br_socialapp = "6. Warranty";
                      var signuppagesocial_html_justify_licence_twentytwo_socialapp = "disclaims all warranties about the";
                      var signuppagesocial_html_justify_licence_twentythird_socialapp = "App to the fullest extent permitted by law. To the extent any warranty exists under law that cannot be disclaimed,";
                      var signuppagesocial_html_justify_licence_twentyfour_socialapp = ", not Apple, shall be solely responsible for such warranty.";
                      var signuppagesocial_html_justify_licence_twentyfive_br_socialapp = "7. Maintenance and Support";
                      var signuppagesocial_html_justify_licence_twentysix_socialapp = "does provide minimal maintenance or support for it but not to the extent that any maintenance or support is required by applicable law,";
                      var signuppagesocial_html_justify_licence_twentyseven_socialapp = ", not Apple, shall be obligated to furnish any such maintenance or support.";
                      var signuppagesocial_html_justify_licence_twentyseven_br_socialapp = "8. Product Claims";
                      var signuppagesocial_html_justify_licence_twentyeight_socialapp = ", not Apple, is responsible for addressing any claims by you relating to the";
                      var signuppagesocial_html_justify_licence_twentyenine_socialapp = "App or use of it, including, but not limited to: (i) any product liability claim; (ii) any claim that the";
                      var signuppagesocial_html_justify_licence_thirty_socialapp = "App fails to conform to any applicable legal or regulatory requirement; and (iii) any claim arising under consumer protection or similar legislation. Nothing in this Agreement shall be deemed an admission that you may have such claims.";
                      var signuppagesocial_html_justify_licence_thirty_br_socialapp = "9. Third Party Intellectual Property Claims";
                      var signuppagesocial_html_justify_licence_thirtyone_socialapp = "shall not be obligated to indemnify or defend you with respect to any third party claim arising out or relating to the";
                      var signuppagesocial_html_justify_licence_thirtytwo_socialapp = "App. To the extent";
                      var signuppagesocial_html_justify_licence_thirtythree_socialapp = "is required to provide indemnification by applicable law,";
                      var signuppagesocial_html_justify_licence_thirtyfour_socialapp = ", not Apple, shall be solely responsible for the investigation, defense, settlement and discharge of any claim that the";
                      var signuppagesocial_html_justify_licence_thirtyfive_socialapp = "App or your use of it infringes any third party intellectual property right.";
                      var signuppagesocial_html_justify_licence_accept_socialapp = "Accept";
                      var signuppagesocial_html_justify_licence_decline_socialapp = "Decline";
                      var alert_invalid_emailid_socialapp = "Invalid Email Address!";
                      var alert_enter_username_socialapp = "Please enter User Name!";
                      var alert_conpass_not_match_socialapp = "Confirm password not matched!";
                      var alert_pass_toshort_socialapp = "Password too short!";
                      var signup2pagesocial_fill_urinfo_socialapp = "Fill Your Information";
                      var signup2pagesocial_aboutme_socialapp = "About Me";
                      var signup2pagesocial_geneder_socialapp = "GENDER";
                      var signup2pagesocial_geneder_male_socialapp = "MALE";
                      var signup2pagesocial_geneder_female_socialapp = "FEMALE";
                      var signup2pagesocial_birthday_socialapp = "BIRTHDATE";
                      var alert_about_me_socialapp = "Please enter About Me!";
                      var alert_select_geneder_socialapp = "Please select gender!";
                      var alert_select_birthdate_socialapp = "Please select birth date!";
                      var alert_select_location_socialapp = "Please enter location!";
                      var alert_enter_phone_socialapp = "Please enter phone!";
                      var alert_enter_address_socialapp = "Please enter address!";
                      var alert_enter_country_socialapp = "Please select country!";
                      var alert_enter_state_socialapp = "Please select state!";
                      var alert_enter_city_socialapp = "Please select city!";
                      var alert_enter_zip_socialapp = "Please select zip!";
                      var latestsocial_show_more_socialapp = "Show more";
                      var social_view_all_socialapp = "View All";
                      var captionnnWallPost_image_social_saysomething_socialapp = "Say something about this photo...";
                      var captionnnWallPost_image_social_saysomething_video_socialapp = "Say something about this video...";
                      var social_post_socialapp = "Pages:";
                      var placeholder_search_socialapp = "Search...";
                      var without_palceholder_search_socialapp = "Search";
                      var nolike_found_socialapp = "No likes found";
                      var followers_socialapp = "Followers:";
                      var subscriber_socialapp = "Subscribers:";
                      var member_since_socialapp = "Member Since :";
                      var following_socialapp = "Following";
                      var decription_socialapp = "Description:";
                      var post_socialapp = "Posts :";
                      var subscribe_without_colon_socialapp = "Subscribers";
                      var follower_without_colon_socialapp = "Followers";
                      var follow_witjout_s_socialapp = "Follow";
                      var subscribed_socialapp = "Subscribed";
                      var subscribe_without_s_socialapp = "Subscribe";
                      var edit_profile_socialapp = "Edit Profile";
                      var add_comment_socialapp = "Add a Comment";
                      var alert_not_allowed_comment_socialapp = "You are not allowed to comment on this post!";
                      var comment_socialapp = "Comment";
                      var unlike_socialapp = "Unlike";
                      var like_socialapp = "like";
                      var alert_enter_comment_socialapp = "Plese enter comment!";
                      var no_comments_there_socialapp = "No comments on this post";
                      var no_likes_there_socialapp = "No likes on this post";
                      var by_socialapp = "by";
                      var mystream_socialapp = "Mystream";
                      var all_socialapp = "All";
                      var post_without_colon = "Posts";
                      var comments_socialapp = "Comments";
                      var follows_socialapp = "Follows";
                      var likes_socialapp = "Likes";
                      var subscribe_socialapp = "Subscribes";
                      var none_socialapp = "None";
                      var top_hundred_user_socialapp = "Top 100 User";
                      var alert_msg_for_successfully_updated_socialapp = "successfully Updated!";
                      var alert_msg_usrname_cant_blank_socialapp = "Username cannot be blank !";
                      var alert_msg_email_cant_blank_socialapp = "Email cannot be blank !";
                      var inner_msg_emailid_already_exist_socialapp = "Email-id already exist!";
                      var inner_msg_not_valid_email_address_socialapp = "Not a valid e-mail address!";
                      var alert_msg_enter_current_password_socialapp = "Please enter current password!";
                      var alert_msg_enter_new_pass_socialapp = "Please enter new password!";
                      var alert_msg_enter_confirm_password_socialapp = "Please enter confirm password!";
                      var alert_msg_password_doesnt_match_socialapp = "Passwords do not match!";
                      var alert_msg_selectfrom_where_want_socialapp = "Select from where you want to upload!";
                      var alert_gallery_camera_socialapp = "Camera,Gallery";
                      var alert_gallery_camera_cancel_socialapp = "Camera,Gallery,Cancel";
                      var alert_msg_addtext_toupload_image_socialapp = "Please add text to upload Image!";
                      var alert_msg_addtext_toupload_video_socialapp = "Please add text to upload Video!";
                      var alert_msg_addtext_toupload_socialapp = "Please add text to upload !";
                      var alert_msg_successfully_uploaded_socialapp = "successfully Uploaded!";
                      var alert_msg_some_error_occured_socialapp = "Some Error try again!";
                      var vedio_upload_socialapp = "Video Upload";
                      var gender_male_socialapp = "male";
                      var gender_female_socialapp = "female";
                      var subscriber_without_s_socialapp = "Subscriber";
                      var follower_without_s_socialapp = "Followers";
                      var filter_by_location_socialapp = "Filter by location";
                      var follow_all_socialapp ="Follow All";
                      var login_socialapp = "Login";
                      var signuppagesocial_html_continue_socialapp = "Continue";
        /*---------------- END SOCIALAPP JS ------------------------------- */

  /*-------------------- START RSS JS ------------------------------------ */
  var server_response_rss = "Server Response";
  var data_not_found_onserver_rss = "Data not found on server !";
  /*-------------------- END RSS JS ------------------------------------ */

   /*-------------------- START FOR REVIEW JS --------------------------- */
      var alert_msg_for_alert_review = "Alert";
      var alert_thanks_for_review_admin_approve_review = "Thanks for submitting your review. It will be posted to the app after it has been approved by the app admin.";
      var alert_msg_oops_review = "Oops";
      var alert_server_not_responding_try_later_review = "Server not responding\n Please try again later";
      var alert_comments_fields_cant_blank_review = "*Comments field cannot be left blank";
      var enter_valid_email_address_review = "Enter a valid E-mail address";
      var name_filed_cant_blank_review = "*Name field cannot be left blank";
      var please_select_rating_review = "*Please select ratings";
      var rate_and_review = "Rate & Review"
      var name_reviews = "Reviews";
     /*-------------------- END FOR REVIEW JS --------------------------- */

      /*-------------------- START FOR REMINDER JS --------------------------- */
        var set_reminder = "Set Your Reminder";
        var adddataid_placeholder_title_reminder = "Title (ex. Name)";
        var adddataid_placeholder_phoneno_reminder = "Phone Number";
        var adddataid_placeholder_message_reminder = "Message...";
        var alert_reminder = "Alert!";
        var alert_required_field_cant_empty_reminder = "Required field cannot be empty";
        var reminder_deleted = "your reminder is deleted";

        var selecttypeid_select_id_reminder = "Select Type:";
        var selecttypeid_daily_reminder = "Daily";
        var selecttypeid_month_reminder = "Month";
        var monthly_reminder = "monthly";
        var selecttypeid_yearly_reminder = "Yearly";

        var dayid_monday_reminder = "Monday";
        var dayid_tuesday_reminder = "Tuesday";
        var dayid_wednesday_reminder = "Wednesday";
        var dayid_thursday_reminder = "Thursday";
        var dayid_friday_reminder = "Friday";
        var dayid_saturday_reminder = "Saturday";
        var dayid_sunday_reminder = "Sunday";
        var dayid_everyday_reminder = "Everyday";

        var yearid_months_january_reminder = "January";
        var yearid_months_feb_reminder = "Febuary";
        var yearid_months_march_reminder = "March";
        var yearid_months_april_reminder = "April";
        var yearid_months_may_reminder = "May";
        var yearid_months_june_reminder = "June";
        var yearid_months_july_reminder = "July";
        var yearid_months_august_reminder = "August";
        var yearid_months_sep_reminder = "September";
        var yearid_months_oct_reminder ="October";
        var yearid_months_nov_reminder = "November"
        var yearid_months_dec_reminder = "December";

        var after_datetime_reminder = "After Date/Time!";
        var date_placeholder_reminder = "Date";
        var reminder_time = "Reminder Time!";
        var time_placeholder_reminder = "time";
        var repate_reminder = "Repeate!";
        var reminder_id_reminder = "ReminderId:";
        /*-------------------- END FOR REMINDER JS --------------------------- */

  /*-------------------- END FOR QUOTE JS --------------------------- */
        var alert_request_quote = "Your Request";
        var alert_feedback_send_successfully_quote = "Feedback sent successfully";
        var alert_failed_send_try_later_quote = "Failed to send,Please try again later";
        var blank_filed_quote = "Blank Field";
        var enter_comment_quote = "Please enter comment.";
        var enter_valid_phoneno_quote = "Please enter a valid phone number.";
        var enter_phoneno_quote = "Please enter a phone number.";
        var invalid_emailid_quote = "Invalid Email id";
        var enter_valid_mailid_quote = "Enter a valid Email id";
        var enter_usrname_quote = "Please enter a name";
 /*-------------------- END FOR QUOTE JS --------------------------- */

 /*-------------------- END FOR QUIZ JS --------------------------- */
     var prefix_exam_quiz = "exam";
     var alert_quiz_data_not_found_quiz = "Quiz data not found!";
     var alert_quiz = "Alert";
     var alert_ok_quiz = "OK";
     var i_scored_quiz = "I scored";
     var take_this_quiz = "%. Take this quiz and test your intellectual prowess by installing this app.";
     var alert_try_again_later_quiz = "Please Try Again..";
     var network_conn_error_quiz = "Network Connection Error";
   /*-------------------- END FOR QUIZ JS --------------------------- */

  /*-------------------- END FOR NOTES JS --------------------------- */
   var add_new_notes = "Add New";
   var placeholder_enter_text_here_notes = "Enter text here";
   var done_notes = "Done";
   var alert_notes = "Alert";
   var alert_ok_notes = "OK";
   var alert_enter_msg_notes = "Please enter message.";
   var delete_notes = "delete";
   var share_notes = "share";
   var edit_notes = "edit";
   var notify_success_delete_notes = "successfully deleted";
   /*-------------------- END FOR NOTES JS --------------------------- */

    /*-------------------- start FOR newsstand JS --------------------------- */
   var restore__your_purchases_newsstand = "Restore your Purchases";
   var if_u_ve_reinstalled_newsstand = "If you have reinstalled";
   var on_ur_device_recover_purchase_newsstand = "on your device or restored a backup onto a new device you can recover your purchases.";
   var restore_newsstand = "Restore";
   var my_dashboard_newsstand = "My Dashboard";
   var home_newsstand = "Home";
   var login_signup_newsstand = "Log In/Sign up";
   var my_account_newsstand = "My Account";
   var restore_purchase_newsstand = "Restore Purchases";
   var main_menu_newsstand = "Main Menu";
   var logout_newsstand = "Logout";
   var view_all_newsstand = "View All";
   var my_collection_newsstand = "My Collection";
   var preview_newsstand = "Preview";
   var subscribe_now_newsstand = "Subscribe Now";
   var buy_this_for_newsstand = "Buy this for";
   var buy_now_newsstand = "Buy now";
   var add_to_collection = "Add To Collection";
   var view_newsstand = "View";
   var usd_newsstand = "USD";
   var slash_month_newsstand = "/Month";
   var slash_year_newsstand = "/Year";
   var buy_album_newsstand = "Buy Album";
   var buy_edition_newsstand = "Buy Edition";
   var news_newsstand = "news";
   var inner_html_choose_ur_subscription_newsstand ="Choose Your Subscription Type:";

   var notify_enter_validno_newsstand = "Please enter valid Number";
   var alert_error_newsstand = "Error";
   var alert_ok_newsstand = "OK";
   var alert_enter_valid_exp_month_newsstand = "Please enter valid Expairy Month";
   var alert_enter_valid_exp_year_newsstand = "Please enter valid Expairy year";
   var alert_enter_valid_card_holder_name_newsstand = "Please enter valid Card Holder Name";
   var alert_enter_valid_cvv_no_newsstand = "Please enter valid cvv Code";
   var alert_payment_unsuccessful_newsstand = "Payment was unsuccessfull,\nPlease check your card details \n or \n try after sometime";
  var alert_newsstand = "Alert";
   var alert_message_newsstand ="Message";
   var alert_ur_order_success_newsstand = "Your Order was successful!";
   var alert_we_are_sorry_newsstand = "We are sorry!";
   var alert_file_not_found_newsstand = "File not found.";
   var alert_check_internet_conn_newsstand = "Please check Internet connection.";
   var alert_there_no_preview_avail_newsstand = "There is no preview available.";
   var alert_check_net_conn_try_again_newsstand = "Please check your Internet connection and try again.";
   var alert_download_unsuccessfull = "Download unsuccessful!";
   var alert_no_purchase_yet_newsstand = "There are no purchases yet";
   var alert_server_error_try_some_time_newsstand = "Server Error,\nPlease try after sometime";
   var alert_emailid_pass_cant_blank_newsstand = "Email id and password must not be blank.";
   var alert_usrname_or_pass_invalid_newsstand = "User name or password is invalid";
   var alert_emailid_cant_blank_newsstand = "Email id must not be blank.";
   var alert_pass_sent_ur_emailid_newsstand = "Password has been sent on your E-mail Id.";
   var alert_unable_reset_pass_newsstand = "Unable to reset your Password.";
   var alert_enter_phone_no_newsstand = "Please enter phone number!";
   var alert_pass_conpass_doesnt_match_newsstand = "Your password and confirmation password do not match";
   var alert_pass_cant_blank_newsstand = "*Password field cannot be left blank";
   var alert_enter_valid_emailid_newsstand = "*Please Enter a valid Email";
   var alert_name_field_cant_blank_newsstand = "*Name field cannot be left blank";
   var alert_register_success_newsstand = "Registered Successfully";
   var alert_unable_register_newsstand = "Unable to Register !";
   var alert_usr_already_registered_newsstand = "User Already Registered !";

   var payment_type_newsstand = "type:";
   var payment_number_newsstand = "number:";
   var payment_expireMonth_newsstand = "expireMonth:";
   var payment_expireYear_newsstand = "expireYear:";
   var payment_cvv2_newsstand = "cvv2:";
   var payment_firstName_newsstand = "firstName:";
   var payment_lastName_newsstand = "lastName:";

   var html_log_in_newsstand = "Log In";
   var html_emailid_newsstand = "Email ID";
   var html_password_newsstand = "Password";
   var html_login_newsstand = "Login";
   var html_forgot_pass_newsstand = "Forgot your password?";
   var html_dont_ve_account_newsstand = "Do not have an account?";
   var html_signup_now = "Sign up Now";
 /*-------------------- END FOR newsstand JS --------------------------- */

  /*-------------------- START FOR SERVICES JS --------------------------- */
  var theusernamepasswordenteredincorrect_services = "The username or password you entered is incorrect.";

 var placeholder_city_state_country_services = "city,state,country";
 var placeholder_soundrssData_services = "soundrssData";
 var placeholder_rssradioData_services = "rssradioData";
 var placeholder_customlistData_services = "customlistData";
 var placeholder_customTrackNameData_services = "customTrackNameData";
 var placeholder_customTrackDescriptionData_services = "customTrackDescriptionData";

 var old_add_class_services = "old-view";
 var search_category_services = "search-category";
 var form_internal_search_services = "NO";
 var distance_unit_mi_services = "MI";
 var distance_unit_m_services = "M";
 var distance_unit_k_services = "K";
 var call_disp_none_services = "none";
 var rating_disp_block_services = "block";
 var address_name_not_avail_services = "Address name not available";

 var alert_internet_conn_not_avail_services = "Internet connection is not available.";
 var alert_services = "Alert";
 var add_more_services = "Add More";
 var alert_thanks_services = "Thanks!";
 var alert_success_submitted_services = "Successfully submitted";
 var successfully_updated_services = "successfully Uploaded!";
 var alert_oops_services = "Oops";
 var custom_track_cant_blank = "Custom track name can not be blank.";
 var custom_track_desc_cant_blank = "Custom track description can not be blank.";
 var alert_server_not_found_try_later_services = "Server not responding\n Please try again later";
 var alert_enter_valid_email_address_services = "Enter a valid E-mail address";
 var alert_name_field_cant_blank = "*Name field cannot be left blank";
 var alert_please_switchon_location_services = "Please switch On the location services for this app, To use this feature";
 var alert_select_from_where_want_services = "Select from where you want to upload!";
 var alert_message_services = "Message";
 var alert_gallery_camera_cancel_services = "Camera,Gallery,Cancel";
 var alert_listing_submit_success_review_services = "Listing is submitted successfully and is under review by the admin.";
 var alert_success_services = "Success!!";
 var alert_error_submitting_listing_services = "Error in submitting the listing.";
 var alert_error_services = "Error";
 var alert_want_logout_services = "You want to Logout ?";
 var logout_services = "LogOut";
 var cancel_yes_services = "Cancel, Yes";
 var alert_ok_services = "OK";
 var alert_sign_alert_services = "Alert !";
 var user_register_successfully_services = "User Registered Successfully";
 var user_already_register_services = "User already registered";
 var no_categories_avail_services = "No categories available";
 var isfrom_drictory_services = "isFromDirectory";

 var enter_name_services = "Please Enter Name.";
 var enter_emailid_services = "Please Enter Email Id.";
 var enter_valid_email_services = "Please enter a valid email";
 var enter_phone_no_services = "Please Enter Phone Number.";
 var enter_valid_phoneno_services = "Please Enter Valid Phone Number.";
 var enter_password_services = "Please Enter Password.";
 var password_mismatch_services = "Password mismatch";
 var invalid_email_address_services = "Invalid Email Address...";
 var password_reset_success_check_email_services = "Password Reset was successfull,\nPlease check your email for new password.";
 var you_not_register_with_yet_services = "You have not been registered with us yet.";
 var enter_valid_address_services = "Please Enter Valid Address";
 var enter_budget_services = "Please Enter Budget";
 var enter_requirement_services = "Please Enter Requirement";
 var request_not_submit_try_again_services = "Request  not submitted.  please try again later";
  var message='Please Select Rating';
  var ratting_missing_services = "Rating missing!";

 var filter_type_services = "Distance";
 var filter_type_ratting_services = "ratting";
 var Filter_search_distance_services = "distance";
 var internet_connective_error_services = "Internet connectivity error";
 var no_saved_bookmarks_services = "No Saved Bookmarks";
 var search_delhi_services = "delhi";
 var output_weatherlist_services = "weatherList";

 var inner_html_location_couldnot_found_services = "The location could not be found";
 var inner_html_error_has_occured_services = "An error has occurred";

 /*-------------------- END FOR SERVICES JS --------------------------- */

/******************** END GEETA CODE **************************************/
      
      
      var invalidloginidorpassword_news = "Invalid login id or password.";
      var email_news = "Email";
      var password_news = "Password";
      var login_news = "LOGIN";
      var forgotpassword_news = "Forgot password?";
      var signup_news = "Sign up";	
      var name_news = "Name *";
      var emaill_news = "Email *";
      var phonenumber_news = "Phone Number";
      var confirmpassword_news = "Confirm Password";
      var alreadyhaveanaccount_news  = "Already have an account? ";
      var signin_news = "Sign In";
      var Wehavesentemailemailid_news = "We have sent an email to your email id";
      var enteryouremail_news = "Enter your email";
      var resetpassword_news = "Reset Password";
      var signupnow_news = "Sign up Now";
      var donothaveanaccount_news  = "Do not have an account? ";
      var error_news = "Error";
      var pleaseenterfirstname_news = "Please Enter First Name.";
      var pleaseentervalidemailid_news = "Please Enter Valid Email Id.";
      var pleaseenterphonenumber_news = "Please Enter Phone Number.";
      var pleaseentervalidphonenumber_news = "Please Enter Valid Phone Number.";
      var pleaseenterpassword_news = "Please Enter Password."; 
      var confirmpasswordnotmatch_news = "Confirm Password do not match.";
      var congratulations_news = "Congratulations!"; 
      var youaresuccessfullyregistered_news = "You are successfully registered";
      var someonealreadyusername_news = "Someone already has that username.";
      var alert_news = 'Alert !';
      var passwordresetsuccessfullpassword_news = 'Password Reset was successfull,\nPlease check your email for new password.';
      var youhavenotbeenregistered_news = 'You have not been registered with us yet.';
      var invalidemailddress_news = 'Invalid Email Address...';
      var ok_news = "OK";
      var sorry_news = "Sorry!";
      var pleaseentercorrectpassword_news = "Please enter your correct password";
      var younotregistered_news = "you are not registered";
      var nohomepagenewsavailable_news = "No homepage news available";
      var nonewsavailable_news = "No news available";
      var searchnews_news = "Search News";
      var settings_news = "Settings";
      var choosewhichpushalertsreceive_news = "Choose which push alerts you would like to receive. These preferences can always be changed later.";
      var alertsneeded_news = "Alerts needed";
      var none_news = " None ";
      var all_news = " All  ";
      var everydays_news = " Every 4-5 days  "; 
      var everydays_news   = " Every 12-15 days  ";
      var dontsendalert_news = "Don\'t send alert between";
      var morealeroptions_news = "More alert options";
      var youcategoriesyourinterests_news = "You can also choose any of the following categories to get alerts based on your interests.";
      var categories_news = "Categories";
      var news_news = " News ";
      var sports_news = " Sports ";
      var entertainment_news = " Entertainment ";
      var tech_news = " Tech ";
      var save_news = " Save ";
      var bookmark_news = "Bookmark";
      var articlehas_news = " This Article has ";
      var postcomment_news = "Post a comment";
      var small_news = "Small";
      var normal_news = "Normal";
      var large_news = "Large";
      var nobookmarknewsavailable_news = "No bookmark news available";
      var pleaseentercomment_news = "Please enter your comment";
      var postcommenthere_new = "Post your comment here";
      var pleaseenterstarttime_news = "Please Enter Start time.";
      var pleaseenterendtime_news = "Please Enter End time.";
      var endtimealwaysgreater_news = "End time always greater than Start time.";
      var pleaseselectcheckbox_news = "Please select the checkbox.";
      var ccongratulation_news = "Congratulation";
      var settingsaddedsuccessfully_news = "Settings added successfully";
      var nonewsfoundcategory_news = "No news found in this category.";
      var pleaseenteryourkeyword_news = "Please enter your keyword.";
                /* ---- news complete ---- */
      
      var home_food = "Home";
      var my_shop_food = "My Shop Food";
      var cart_food="Cart";
      var my_account_food="My Account";
      var My_Orders_food = "My Orders";
      var pickup_food = "PickUp Address";
      var categories_food = "Categories Food";
      var submit_food = "Submit";
      var forgot_password_food = "Forgot Password";
      var email_id_food = "Email Id";
      var password_food = "Password";
      var do_not_have_an_account_food = "Do not have an account?";
      var search_food = "Search";
      var sign_up_now_food = "Sign Up Now";
      var name_food = "Name";
      var phone_food = "Phone";
      var confirm_password_food = "Confirm Password";
      var sign_up_food = "Sign Up";
      var already_have_an_account_food = "Already have an account?";
      var sign_in_food = "Sign In";
      var contact_information_food = "Contact Information";
      var my_address_food = "My Address";
      var default_billing_address_food = "Default Billing Address";
      var default_shipping_address_food = "Default Shipping Address";
      var order_history_food = "Order History";
      var order_id_food = "Order Id";
      var billing_address_food = "Billing Address";
      var shipping_address_food = "Shipping Address";
      var order_detail_food = "Order Detail";
      var product_name_food = "Product Name";
      var price_food = "Price";
      var qty_food = "Qty";
      var order_date_food = "Order Date";
      var subtotal_food = "Subtotal";
      var tax_food = "Tax";
      var coupon_food = "Coupon";
      var discount_food = "Discount";
      var shipping_food = "Shipping";
      var grand_total_food= "Grand Total";
      var payment_method_food = "Payment Method";
      var order_status_food = "Order Status";
      var personal_information_food = "Personal Information";
      var change_password_food = "Change Password";
      var current_password_food = "Current Password";
      var confirm_new_password_food = "Confirm New Password";
      var no_product_exists_food = "No Product Exists";
      var add_to_cart_food = "Add To Cart";
      var cart_list_food = "Cart List";
      var edit_food = "Edit";
      var done_food = "Done";
      var payment_details_food = "Payment Details";
      var apply_coupon_code_food = "Apply Coupon Code";
      var enter_your_coupon_code_if_you_have_one_food = "Enter coupon code";
      var apply_food = "Apply";
      var continue_shopping_food = "Continue Shopping";
      var checkout_food = "Checkout";
      var first_name_food = "First Name";
      var last_name_food = "Last Name";
      var address_food = "Address";
      var zip_postal_code_food = "Zip/Postal Code";
      var city_food = "City";
      var country_food = "Country";
      var state_province_food = "State/Province";
      var telephone_food = "Telephone";
      var fax_food = "Fax";
      var same_as_billing_address_food = "Same as Billing Address";
      var pay_now_food = "Pay Now";
      var cash_on_delivery_food = "Cash On Delivery";
      var please_click_on_place_order_button_to_place_the_order_food = "Please Click On Place Order Button To Place The Order";
      var credit_card_food = "Credit Card";
      var paypal_food = "Paypal";
      var you_will_be_redirected_to_paypal_site_food = "You will be redirected to paypal site";
      var order_by_phone_food = "Order by Phone";
      var you_can_order_by_calling_food = "You can order by calling";
      var place_order_food = "Place Order";
      var instock_food= "Instock";
      var out_of_stock_food = "Out Of Stock";
      var test_food = "Test food";

      var required_fields_food="Required Fields";
      var no_items_in_cart_food="You have no items in your shopping cart.";
      var add_products_in_cart_food="Please add products in your shopping cart.";
      var	login_food="Login";
      var new_password_food="New Password";
      var logout_food="Logout";
      var no_products_exists_food="No Products Exists";
      var already_have_an_account_food="Already have an account?";
      var instructions_foodorder="Instructions";


      var privacypolicy_food = "Privacy Policy";
      var homee_food = "Home";
      var loginsignup_food = "Login/Sign Up";
      var cartt_food = "Cart"
      var myorder_food = "My Order";
      var termscconditions_food = "Terms & Conditions";
      var lllogout_food = "Logout";
      var searchproducts_food = "Search Products";
      var featureddproducts_food = "Featured Products";
      var searchproductin_food = "Search Productin";
      var ssearch_food = "Search";
      var aalert_food = 'Alert!';
      var pleaseenterkeywordsearch_food = 'Please enter a keyword to search';
      var adddd_food = "add";
      var noproductfoundd_food = "No Product Found";
      var searchresultt_food = "Search Result for";
      var thereproductadded_food = "There is no product added.";
      var productsuccessfullyaddedcart_food = "Product successfully Added into your Cart.";
      var productquantityzero_food = "Product Quantity should be greater than Zero.";
      var sizeformeal_food = "Size for meal";
      var youhaveaddedmaximumquantity_food = "You have added maximum quantity.";
      var select_food = "Select";
      var  subbb_food = 'Sub ';
      var addzero_food = 'Add 0';
      var addddd_food = 'Add ';
      var pleaseenterquantityessthann_food = "Please enter quantity less than ";
      var pleaseselectt_food = 'Please select ';
      var errorrr_food = "Error";
      var okkk_food = "OK";
      var miordervalueis_food = 'Min. order value is ';
      var ssorry_food = "Sorry";
      var productsuccessfullydadednourart_food = "Product successfully Added In Your Cart.";
      var quantityshouldgreaterzero_food = "Quantity should be greater than zero";
      var deliverycharge_food = "Delivery Charge "; 
      var discountcodes_food = "Discount Codes";
      var shoppingcart_food = "Shopping cart";
      var clearcart_food = "Clear Cart";
      var tip_food = "Tip";
      var continueoordering_food ="Continue Ordering"
      var qquantity_food = "Quantity";
      var pprice_food = "Price";
      var ttotal_food = "Total";
      var ttax_food = "Tax";
      var ddiscount_food = "Discount";
      var ddeliverycharge_food = "Delivery Charge";
      var ggrandtotal_food = "Grand Total";
      var therenoitemcart_food = "There is no Item in the cart";
      var doneee_food = "Done";
      var couponpppage_food = "Coupon Page";
      var notavalidcccoupon_food = "Not a valid coupon "; 
      var eeenteryourcouponcode_food= "Enter your Coupon Code";
      var ppaymentddetails_food = "Payment Details";
      var ssubtotal_food= "Subtotal ";
      var ccoupon_food= "Coupon ";
      var llloginregistration_food = "Login / Registration";
      var mmyaccount_food = "My Account";
      var mysshop_food= "My Shop";
      var invalidloginidorpassword_food= "Invalid login id or password.";
      var fforgotyourpassword_food= "Forgot your password?";
      var orr_food = "OR";
      var ccconfirmpassword_food = "Confirm  Password";
      var wehavesentemailemailid_food = "We have sent an email to your email id";
      var rrresetpassword_food = "Reset Password";
      var aaaalreadyhaveanaccount_food= "Already have an account? ";
      var ppleaseenterfirstnname_food ='Please Enter First Name.';
      var ppleaseeentervvalidemailiid_food = 'Please Enter Valid Email Id.';
      var ppleaseenterpphonennumber_food = 'Please Enter Phone Number.';
      var pppleaseetervlidphonenumber_food = 'Please Enter Valid Phone Number.';
      var ppleaseenterpassword_food = 'Please Enter Password';
      var cconfirmpassworddonotmatch_food = 'Confirm Password do not match';
      var sssignuuccessful_food ='Signup Successful';
      var eeemaillreadyegistered_food= 'Email Id Already Registered';
      var uuhoh_food = 'Uh-oh, inValid email ID.';
      var ppasswordesewasuccessfullleasecheckemailfornewpassword_food = 'Password Reset was successfull,Please check your email for new password.';
      var yyouhavenotbeenregisteredwithusyet_food = 'You have not been registered with us yet.';
      var iiinvalidemailaddress_food = 'Invalid Email Address...';
      var dddashboard_food = "Dashboard";
      var mmydashboard_food = "My Dashboard";
      var helloharmenrdrupta_food = "Hello, Dharmenrdra Gupta";
      var ffromyoucounashboardbilityviewsnapshottion_food = "From your My Account Dashboard you have the ability to view a snapshot of your recent account activity and update your account information. Select a link below to view or edit information.";
      var aaaaddressook_food = "Address Book ";
      var iiinformationpdateuccessfully_food  = "Information Updated Successfully.";
      var ssssave_food = "Save";
      var nnnnname_food = "Name";
      var eeemaiddress_food = "Email Address";
      var enterourmailid_food = "Enter your Email ID";
      var ttelephonenno_food = "Telephone No";
      var billingformationpdatedccessfully_food = "Billing Information Updated Successfully.";
      var nnname_food ="Name"
      var sstreetssddress_food= "Street Address";
      var enteourity_food = "Enter Your City";
      var enterstatepprovince_food ="Enter State/Province";
      var eenteipostalode_food ="Enter Zip/Postal Code";
      var sshippinddresiffereillinddress_food =" Shipping Address Different From Billing Address";
      var sshippingformationdateduccessfully_food= "Shipping Information Updated Successfully.";
      var ffirstnme_food = "First Name";
      var zzipostalode_food= "Zip/Postal Code";
      var oooder_food = " Order ID";
      var deliverycccharge_food ="delivery Charge";
      var ccouponddiscount_food = "Coupon Discount";
      var ttotalamount_food ="Total Amount";
      var cccccomment_food = "Comment";
      var iiitemisnotavailable_food = "Item is not available";
      var dddelivery_food = "Delivery";
      var dddeliveryromocation_food = "Delivery From Location";
      var aaaaaaaaaddress_food = "Address";
      var pppickupime_food = "Pickup Time";
      var cooonfirm_food = "Confirm";
      var pppaymentorderfor_food ="Payment of Product order for ";
      var alerttText='Please select pickup time 45 minutes later from current time';
      var ppleaseaterpentime_food = 'Please select pickup time 45 minutes later from open time ';
      var pppickupime_food = 'Pick up Time';
      var ppppleaseenterapreferredpickuptime_food ='Please enter a preferred pick up time';
      var ppleaseenterareferredweenentime_food ='Please enter a preferred pick up time between store open time ';
      var andstoreclosettime_food = ' and store close time ';
      var ppleaseselectdeliverytimetime_food = 'Delivery can be scheduled for 45 minutes or later from now';
      var ppppleasecheckdelivimlease_food='Please check delivery time. Please note delivery cannot be scheduled before 45 minutes from placing the order';
      var emmmail_food = "Email";
      var ssstateprovince_food = "State/Province";
      var ccccountry_food = "Country";
      var ssshhhippingddress_food = "Shipping Address";
      var preferred_deliverytime_Text="Preferred Delivery Time:-";
      var pppppayow_food = "Pay Now";
      var ddddeliveryime_food = 'Delivery Time';
      var pppleaseentepreferreddelivery_food='Please enter a preferred delivery';
      var pppleasestoreopentimee_food = 'Please enter a preferred delivery time between ';
      var dddddeliveryiotavailableinyourlocation_food = 'Delivery is not available in your location';
      var ppppppleasenteountry_food = 'Please Enter Country';
      var bblankfield_food = 'Blank Field';
      var pppllleasenterterovince_food ='Please Enter State/Province';
      var pplleasenterourity_food ='Please Enter Your City';
      var pppleasntetreetress_food = 'Please Enter Street Address';
      var ppppleasnteridhonember_food = 'Please Enter Valid Phone number';
      var iiiiinvalihoneumber_food = 'Invalid Phone Number';
      var ppleaseenterfirsname_food ='Please Enter First Name';
      var ppleasnterountry_food = 'Please Enter Country';
      var ppleasenterlidailddress_food ='Please Enter Valid Email Address';
      var ppleasnterrstame_food = 'Please Enter First Name';
      var pppaycashatdoor_food = "Pay cash at the door";
      var ppaypalexpress_food = "Paypal Express";
      var ppawithareditcard_food = "Pay with a credit card";
      var oorderbyhone_food = "Order by Phone";
      var ccallnow_food = "Call Now";
      var pppleaseclickontheconfirmtopaythroughcreditcard_food ="Please Click on the confirm to pay through credit card";
      var ppleaseclickonconfirmbuttonlaceherder_food = "Please Click On confirm Button To Place The Order";
      var cccardype_food = "Card Type";
      var viisa_food ="visa";
      var mmastercard_food = "mastercard";
      var amexxx_food = "amex";
      var dddiscover_food = "discover";
      var caaardnumber_food = "Card Number";
      var exxxpirymonth_food = "Expiry Month";
      var eeexpiryear_food = "Expiry Year";
      var cccccardolder_food = "Card Holder";
      var ccardssecuritode_food = "Card Security Code";
      var caaaard_food = "Card";
      var paaaypal_food = "Paypal";
      var cood_food = "COD";
      var checkthebackoyourcreditcardforcvv_ffod = "check the back of your credit card for cvv";
      var cvvv_food = "CVV";
      var cardholdernaaame_food = "Card Holder Name";
      var yyoucanorderycalling_food = "You can order by calling ";
      var ppleaseclickontheconfirmaypal_food = "Please click on the confirm to pay through Paypal";
      var paaayusingashonelivery_food = "Pay using Cash-on-Delivery";
      var pllaaceorder_food = "PLACE ORDER";
      var ppleaseentervalidumber_food = "Please enter valid Number";
      var ppleaseentervalidxpairyonth_food = "Please enter valid Expairy Month";
      var ppleaseentervalidxpairyear_food ="Please enter valid Expairy year";
      var ppleaseentervalidardolderame_food="Please enter valid Card Holder Name ";
      var pppleaseentervalidode_food = "Please enter valid cvv Code ";
      var iiinvalidcardetails_food = 'Invalid card details';
      var innnvalidcard_food = "Invalid Card";
      var ppppleaseenterthevalidaddrespickup_food = 'Please enter the valid address for pickup';
      var ppleasentethtimeforpickup_food = 'Please enter the time for pickup';
      var cccancel_food = "Cancel";
      var rrretry_food = "Retry";
      var cccontinue_food = "Continue";
      var wwvereceivedourorder_food = "We\'ve received your order";
      var yourorderwuccessfu_food = 'Your Order was successful!';
      var wwearesorry_food = 'We are sorry!';
	  var toText_food = ' to ';
      /* ---- foodordering complete ---- */
      
      var signupenternamealert = "Name field cannot be left blank";
      var signuppasswords = "Password field cannot be left blank";
      var signupemailid = "Please Enter a valid Email";
      var signuppasswordshouldbesevenchar ="Password length should be minimum 7 characters.";
      var signuppassworddonotmatch ="Password does not match";
      var signuppasswordsendmailid = "Password has been sent on your E-mail Id";
      var signuppasswordunabletoreset = "Unable to reset your Password";
      var registeredsuccessfully ="Registered Successfully";
      var registeredsuccessfullycustomforecb1f89b5b67 ="Last step, check your email and follow the instructions sent to you";
      var unabletoregister ="Unable to Register !";
      var useralreadyregistered ="User Already Registered !";
      var emailandpasswordmustnotbeblank ="Email id and password must not be blank.";
      var invalidusernameorpassword ="Invalid username or password";
      var fromfacebookloginstatus=false;


      var ccconnect_code = "Connect ";
      var with_code = "With";
      var fffacebook_code = " Facebook";
      var dddelete_code = "delete"
      var bookkkmark_code = "bookmark";
      var ookk_code = 'OK';
      var ppdfownloadinginprogress_code = 'Pdf Downloading is in progress.'
      var nointerbnconnection_code ='NO INTERNET CONNECTION';
      var yyoumustbeconnectedinternet_code ='You must be connected to the Internet to use this feature. Check your Internet connection and try again.';
      var applicationaunchfailed_code = "Application Launch Failed. Please try again!";
      var youhaveupdatesavailableforhisapp_code = "You have updates available for this app";
      var uuupdate_code ="Update";
      var rremindmeater_code = "Remind me later";
      var aalert_code = 'Alert';
      var  ssorryhisapptemporarilydisabledpublisher_code = " Sorry, This app has been temporarily disabled by the publisher. ";
      var ccontacttheowner_code = "Contact the owner";
      var bbandwidthlimitonppunlocked_code = "Bandwidth limit on App has been exceeded. Please contact the App owner for getting the app unlocked. ";
      var cchathere_code = "Chat here";
      var wecannotaccesshidden_code = 'We can not access your app.It seems all pages in your app are hidden.';
      var sselectgender_code = "Select Gender";
      var mmale_code = "Male";
      var femalee_code = "Female";
      var aaattachfile_code = "Attach File";
      var nnnotvalidemail_code = "not valid email !";
      var ppleaseprovidepaypalemailid_code = 'Please provide paypal email id';
      var ppleaseprovidepaymentmount_code= 'Please provide payment amount.';
      var ppaymentfor_code = "Payment for ";
      var ppleaseprovidepubliceforiap_code = 'Please provide public key for IAP.';
      var ffieldcannotbeleftblank_code = ' field cannot be left blank';
      var uunabletoegister_code = 'Unable to Register !';
      var ccheckyournternetonnectioagain_code = 'Check your Internet connection and try again.';
      var vverificationcodesendsuccessfully_code = "Verification code send successfully.";
      var vverificationodesendingfailed_code ="Verification code sending failed.";
      var ppleasetryagain_code = "Please try again.";
      var verificationcodemustnotbeblank_code = "Verification code must not be blank.";
      var vverificationcodenotmatched_code = "Verification code not matched.";
      var eemailidmustnotbeblank_code = "Email id must not be blank.";
      var notvvvalid_code = "not valid";
      var ffacebookauthenticateagain_code = 'Facebook do not authenticate you. Try again.';
      var pppleasentervalidmail_code = '*Please Enter a valid Email';
      /* ---- code complete ---- */





function arabic() {
	home_mcom = "الصفحة الرئيسية";
	my_shop_mcom = "متجري";
	login_signup_mcom = "تسجيل الدخول / اشترك";
	cart_mcom = "Cart";
	my_account_mcom = "العربة";
	My_Orders_mcom = "طلباتي";
	featured_product_mcom = "المنتج المميز";
	categories_mcom = "الفئات";
	submit_mcom = "عرض";
	forgot_password_mcom = "هل نسيت كلمة المرور";
	email_id_mcom = "البريد الإلكتروني معرف";
	password_mcom = "كلمه السر";
	do_not_have_an_account_mcom = "لم يكن لديك حساب؟";
	search_mcom = "بحث";
	sign_up_now_mcom = "أفتح حساب الأن";
	name_mcom = "اسم";
	phone_mcom = "هاتف";
	confirm_password_mcom = "تأكيد كلمة المرور";
	sign_up_mcom = "سجل";
	already_have_an_account_mcom = "هل لديك حساب؟";
	sign_in_mcom = "تسجيل الدخول";
	contact_information_mcom = "معلومات الاتصال";
	my_address_mcom = "عنواني";
	default_billing_address_mcom = "عنوان الفواتير الافتراضي";
	default_shipping_address_mcom = "عنوان الشحن الافتراضي";
	order_history_mcom = "تاريخ الطلب";
	order_id_mcom = "رقم التعريف الخاص بالطلب";
	billing_address_mcom = "عنوان وصول الفواتير";
	shipping_address_mcom = "عنوان الشحن";
	order_detail_mcom = "ترتيب التفاصيل";
	product_name_mcom = "اسم المنتج";
	price_mcom = "السعر";
	qty_mcom = "الكمية";
	order_date_mcom = "تاريخ الطلب";
	subtotal_mcom = "حاصل الجمع";
	tax_mcom = "ضريبة";
	coupon_mcom = "كوبون";
	discount_mcom = "خصم";
	shipping_mcom = "الشحن";
	grand_total_mcom = "المبلغ الإجمالي";
	payment_method_mcom = "طريقة الدفع او السداد";
	order_status_mcom = "حالة الطلب";
	personal_information_mcom = "معلومات شخصية";
	change_password_mcom = "تغيير كلمة السر";
	current_password_mcom = "كلمة السر الحالية";
	confirm_new_password_mcom = "تأكيد كلمة المرور الجديدة";
	no_product_exists_mcom = "لا يوجد منتجات";
	add_to_cart_mcom = "أضف إلى السلة";
	cart_list_mcom = "قائمة عربة";
	edit_mcom = "تحرير";
	done_mcom = "فعله";
	payment_details_mcom = "تفاصيل الدفع";
	apply_coupon_code_mcom = "تطبيق رمز القسيمة";
	enter_your_coupon_code_if_you_have_one_mcom = "أدخل رمز القسيمة";
	apply_mcom = "تطبيق";
	continue_shopping_mcom = "متابعة التسوق";
	checkout_mcom = "الدفع";
	first_name_mcom = "الاسم الاول";
	last_name_mcom = "الكنية";
	address_mcom = "عنوان";
	zip_postal_code_mcom = "الرمز البريدي / الرمز البريدي";
	city_mcom = "مدينة";
	country_mcom = "بلد";
	state_province_mcom = "الدولة / مقاطعة";
	telephone_mcom = "هاتف";
	fax_mcom = "فاكس";
	same_as_billing_address_mcom = "نفس عنوان ارسال الفواتير";
	pay_now_mcom = "المضي قدما لدفع";
	cash_on_delivery_mcom = "الدفع عند التسليم";
	please_click_on_place_order_button_to_place_the_order_mcom = "يرجى الضغط على زر طلب مكان لوضع النظام";
	credit_card_mcom = "بطاقة ائتمان";
	paypal_mcom = "باي بال";
	you_will_be_redirected_to_paypal_site_mcom = "سيتم توجيهك إلى موقع باي بال";
	order_by_phone_mcom = "طلب عن طريق التلفون";
	you_can_order_by_calling_mcom = "يمكنك من أجل بالدعوة";
	place_order_mcom = "ترتيب مكان";
	instock_mcom = "INSTOCK";
	out_of_stock_mcom = "إنتهى من المخزن";
	test_mcom = "اختبار MCom";
	instructions_mcom = "تعليمات";
	search_product_mcom = "serach المنتج";
	login_mcom = "تسجيل الدخول";
	// *********start new var**********//
	logout_mcom = "خروج";
	notifications_mcom = "الإشعارات";
	offers_mcom = "عروض";
	wishlist_mcom = "قائمة الرغبات";
	settings_mcom = "إعدادات";
	tc_mcom = "الأحكام والشروط";
	privacy_policy_mcom = "سياسة الخصوصية";
	alert_mcom = 'تنبيه!';
	please_mcom = 'الرجاء إدخال كلمة للبحث';
	empty_mcom = "البحث فارغ";
	result_mcom = "نتيجة!";
	tryanother_mcom = "محاولة الكلمة آخر";
	searchresult_mcom = "نتيجة البحث عن";
	sortby_mcom = "ترتيب حسب";
	popularityg_mcom = "شعبية";
	pricehighlow_mcom = "ارتفاع سعر منخفض";
	pricelowhigh_mcom = "انخفاض سعر عالي";
	msgg_mcom = "وهناك إضافة أي منتج";
	selectg_mcom = "اختار";
	sorryg_mcom = "آسف";
	quantityoutofstock_mcom = "كمية من المخزون";
	pleaseselectg_mcom = "اختر من فضلك";
	errorg_mcom = "خطأ";
	okg_mcom = "حسنا";
	productsuccessfullyaddedinyourcartg_mcom = "المنتج أضيف بنجاح في سلة التسوق الخاصة بك.";
	quantityshouldbegreaterthanzerog_mcom = "وينبغي أن تكون كمية أكبر من الصفر";
	quantityshouldbegreaterthanzerog_mcom = "Quantity should be greater than zero";
	pproductsuccessfullyaddedinyourcartg_mcom = 'المنتج أضيف بنجاح في سلة التسوق الخاصة بك.';
	qquantity_mcom = "كمية";
	pprice_mcom = "السعر";
	ttotalpayableamount_mcom = ":المبلغ الكلي المستحق";
	coupong_mcom = "كوبون";
	subtotalg_mcom = "حاصل الجمع";
	discountg_mcom = "خصم ";
	deliverychargeg_mcom = " رسوم التوصيل";
	cartemptyg_mcom = "سلة مشترياتك ";
	eemptyg_mcom = "البحث فارغ!";
	additemnowg_mcom = "إضافة عناصر إلى الآن";
	gotohomeg_mcom = "اذهب الى المنزل";
	ccouponpageg_mcom = "قسيمة الصفحة";
	notavalidcoupong_mcom = "لا القسيمة صالحة ";
	entercouponcodeg_mcom = "أدخل رمز القسيمة";
	applygg_mcom = "تطبيق";
	ddeliverychargegg_mcom = "رسوم التوصيل ";
	homeeg_mcom = "الصفحة الرئيسية";
	myAccountg_mcom = "حسابي";
	termsconditionsgg_mcom = "البنود و الظروف";
	privacypolicygg_mcom = "سياسة الخصوصية";
	shippingaddressdifferentfrombillingdddressgg_mcom = " عنوان الشحن يختلف عن عنوان الفواتير";
	dddeliverychargegg_mcom = "رسوم التوصيل ";
	ccompletepurchasegg_mcom = "شراء كامل";
	iinvalidloginidorpasswordgg_mcom = "معرف تسجيل الدخول غير صالح أو كلمة المرور";
	nnamegg_mcom = "اسم ";
	pphonenumbergg_mcom = "رقم الهاتف";
	wwehavesentaemailtoyouremailidgg_mcom = "لقد قمنا بإرسال بريد إلكتروني إلى معرف البريد الإلكتروني الخاص بك";
	eenteryyouremailgg_mcom = "ادخل بريدك الإلكتروني";
	ppleaseenterusernamegg_mcom = "الرجاء إدخال اسم المستخدم";
	ppleaseemailidgg = "يرجى البريد الإلكتروني معرف";
	ppleaseentervalidemailidgg_mcom = "الرجاء إدخال بطاقة هوية صالحة البريد الإلكتروني";
	ppleaseenterphonenumbergg_mcom = "يرجى إدخال رقم الهاتف";
	ppleaseentervalidphonenumbergg_mcom = "الرجاء إدخال صالحة رقم الهاتف";
	ppleaseenterpasswordgg_mcom = "الرجاء إدخال كلمة المرور";
	cconfirmpassworddonotmatchgg_mcom = "تأكيد كلمة المرور لا تتطابق";
	eemailidalreadyregisteredgg_mcom = "البريد الإلكتروني رقم مسجل إذا";
	eerrorgg_mcom = "خطأ";
	OoKgg_mcom = "حسنا";
	uuhohgg_mcom = "اه اوه";
	iinvalidemailiidggg_mcom = "معرف البريد الإلكتروني غير صالح";
	yyouhavenotbeenregisteredwithusyetgg_mcom = "أنت لم تسجل معنا بعد";
	ppasswordresetwassuccessfullpleasecheckyouremailfornewpasswordgg_mcom = "كان إعادة تعيين كلمة المرور بنجاح، يرجى التحقق من بريدك الالكتروني للكلمة سر جديدة";
	eeerrorgg_mcom = "خطأ";
	ppleaseenteremailidggg_mcom = "الرجاء إدخال اسم المستخدم البريد";
	iiinvalidemailaddressggg_mcom = "عنوان البريد الإلكتروني غير صالح";
	ppppleaseenterpasswordgggg_mcom = "الرجاء إدخال كلمة المرور";
	uuusernotexistggg_mcom = "المستخدم غير متوفر";
	yyyouhaveenteredwrongpasswordggg_mcom = "لقد أدخلت كلمة مرور خاطئة";
	ooordersnotfoundgggg_mcom = "أوامر لم يتم العثور";
	wwriterreviewggg_mcom = "مراجعة الكتابة";
	cccancelggg_mcom = "إلغاء";
	rrreorderggg_mcom = "إعادة ترتيب";
	ppproductnnamegg_mcom = "اسم المنتج";
	qqquantitygggg_mcom = "كمية";
	ppppricegggg_mcom = "السعر";
	dddddeliverychargeggg_mcom = "رسوم التوصيل";
	tttipggg_mcom = "تلميح";
	ccccouponddiscountgggg_mcom = "قسيمة الخصم";
	tttotalpayableaamountggg_mcom = "المبلغ الكلي المستحق";
	cccommentgggg_mcom = "التعليق";
	rrrrreordergggg_mcom = "إعادة ترتيب";
	pppaymentofproductorderforgggg_mcom = "دفع نموذج طلب المنتج";
	ttthankggg_mcom = "شكر";
	yyyouggg_mcom = "أنت";
	ooorderidddggg_mcom = "رقم التعريف الخاص بالطلب";
	cccontinuemypoordersggg_mcom = "تواصل طلباتي";
	gggtohhomegggg_mcom = "اذهب الى المنزل";
	wwevereceivedouordergg_mcom = "لقد تلقينا طلبك";
	yyourorderwassuccessfulgg_mocom = "كان النظام الخاص بك بنجاح";
	wwearesorrygg_com = "نحن اسفون";
	wwwriteeviewgg_mcom = "التعليق";
	postreviewguidelinesggg_mcom = "المبادئ التوجيهية لكتابة استعراض المنتجات. جميع الحقول إلزامية. من فضلك لا تتضمن إشارات HTML لتجار التجزئة الأخرى، والتسعير، والمعلومات الشخصية، أي تدنيس والتعليقات التهابات أو حقوق الطبع والنشر، أو أي المحتوى المنسوخ.";
	pppposteviewggg_mocom = "مراجعة آخر";
	eviewitleggg_mcom = "مراجعة عنوان";
	ooommentgg_mcom = "التعليق";
	ppppostreviewgg_mcom = "مراجعة آخر";
	eeeerrorggg_mcom = "خطأ";
	ppleaseenterthereviewtitleggg_mcom = "يرجى إدخال عنوان مراجعة";
	pppleaseenterthereviewtextggg_mcom = "الرجاء إدخال نص التعليق";
	rrrequiredfieldsaremissingggg_mcom = "الحقول المطلوبة مفقودة";
	nnetworkerrorggg_mcom = "خطأ في الشبكة";
	ppleasecheckyourinternetconnectionggg_mcom = "الرجاء التحقق من اتصال الإنترنت الخاص بك";
	ooorderhasbeennottakenorcompletedgggg_mcom = "وقد لا يؤخذ الأمر أو الانتهاء";
	nnnotificationggg_mcom = "إعلام";
	eeeeemptygggg_mcom = "فارغة";
	ttthereisnonotificationlistgggggg_mocom = "ليس هناك قائمة إعلام";
	ggotohhomeggg_mcpm = "اذهب الى المنزل";
	iiiiteminyourordergggg_mcom = "البند في طلبك";
	hhhhasbeenshippedbysellerggggg_mcom = "تم شحنها من قبل البائع";

	iinformationupdatedssuccessfullygg_mcom = "معلومات التحديث بنجاح";
	nnnameggg_mcom = "اسم";
	eeemailaaddressggg_mcom = "عنوان البريد الإلكتروني";
	eeenteryouremailiddggg_mcom = "أدخل معرف البريد الإلكتروني الخاص بك";
	tttelephonenoggg_mcom = "الهاتف لا";
	uupdateccontactinformationgg_mcom = "تحديث معلومات الاتصال";
	bbbillinginformationupdatedsuccessfullyggg_mcom = "معلومات الفواتير التحديث بنجاح";
	sstreetaaddressgg_mcom = "عنوان الشارع";
	eenteryyourccitygg_mcom = "أدخل مدينتك";
	eeentersstatepprovincegg_mcom = "أدخل الدولة / مقاطعة";
	eeenterzzippostalcodegg_mcom = "أدخل الرمز البريدي / الرمز البريدي";
	zzipppostalcodegg_mcom = "الرمز البريدي / الرمز البريدي";
	sstreetaaddressggg_mcom = "عنوان الشارع";
	aaaddressdifferentfrombillingaaddressgg_mcom = "عنوان مختلف عن عنوان الفواتير";
	uupdatebillingiinformationgg_mcom = "تحديث معلومات الفواتير";
	sshippinginformationupdatedsuccessfullyggg_mcom = "معلومات الشحن التحديث بنجاح";
	uupdatesshippingiinformationgg_mcom = "تحديث معلومات الشحن";

	sselectfromwhereyouwanttouuuploadgg_mcom = "!اختر من حيث تريد تحميل";
	mmessagegg_mcom = "الرسالة";
	cameragg_mcomn = "الة تصوير";
	ggallerygg_mcom = "صالة عرض";
	sssuccessfullyuuploadedgg_mcom = '!تم التحميل بنجاح';
	uuploadeerrorgg_mcom = 'خطأ في الرفع';
	eerrorggg_mcom = 'خطأ';
	ppleastryagaingg_mcom = "حاول مرة اخرى";
	nnetworkrrorgg_mcom = 'خطأ في الشبكة';
	nnoreviewavalaiblegg_mcom = "لم يتم تقديم تعليقات المتاحة";
	cccreatecountgg_mcom = "إصنع حساب";
	missingrequiredfieldspleasereloginntragaingg_mcom = "مفقودة الحقول المطلوبة يرجى إعادة تسجيل الدخول والمحاولة مرة أخرى";

	pproductsgg_mcom = "المنتجات ";
	tthereisnishlisproductgg_mcom = "لا يوجد منتج قائمة الامنيات";
	tthereisnofferedproductgg_mcom = "لا يوجد منتج المقدمة";
	tthereisnofeatureproductgg_mcom = "لا يوجد منتج متميز";
	/* ----------------Ecom complete--------------------------------- */

	iinvalidddategg_ment = 'تاريخ غير صالح';
	Appointmentdateisnotalidgg_ment = 'تاريخ التعيين غير صالح';
	eerrorgg_ment = 'خطأ';
	pleaseselectadatebeforetimegg_ment = 'يرجى تحديد تاريخ قبل الوقت';
	appointmentcanttimeslot_ment = 'تعيين لا يمكن أن يقع بين هذا الوقت، يرجى اختيار فتحة مرة أخرى.';
	appointmentcurrenttime_memt = 'تعيين لا يمكن أن يحدد في الوقت الحالي، الرجاء اختيار فتحة مرة أخرى';
	appointmentpasttime_ment = 'تعيين لا يمكن أن يحدد في الوقت الماضي، الرجاء اختيار فتحة وقت في المستقبل';
	dateblank_ment = '*حقل تاريخ لا يمكن أن تترك فارغة';
	alert_ment = 'إنذار';
	remark_ment = '*حقل الملاحظات لا يمكن أن تترك فارغة';
	pleaseprovideavalidphonenumber_ment = 'الرجاء تقديم رقم هاتف صالح';
	enteravalidmailaaaddress_ment = 'أدخل عنوان بريد إلكتروني صالح';
	nameblank_ment = '*حقل اسم لا يمكن أن تترك فارغة';
	timeblank_ment = '*حقل وقت لا يمكن أن تترك فارغة';

	/* ----------------Appointment complete--------------------------------- */

	couldnotreadfilegg_audio = ":لا يمكن قراءة ملف ";

	/* ----------------Audio complete--------------------------------- */

	alert_blog = 'إنذار';
	datanotfound_blog = 'البيانات لم يتم العثور';
	datafound_blog = 'البيانات لم يتم العثور. \n يرجى المحاولة بعد بعض الوقت';

	/* ----------------Blog complete--------------------------------- */

	namefiled_chat = ' حقل اسم لا يمكن أن تترك فارغة';
	alert_chat = 'إنذار';
	ok_chat = 'حسنا';
	send_chat = "إرسال";
	uploadpic_chat = "تحميل صورة";
	screen_chat = "الاسم الذي سيظهر";
	next_chat = "التالى";
	update_chat = "تحديث";
	selectfromwhereyouwanttoupload_chat = 'اختر من حيث تريد تحميل';
	message_chat = 'الرسالة';
	unableto_chat = 'غير قادر على تحديد صورة';

	/* ----------------Chat complete--------------------------------- */

	error_contact = "خطأ في اتصال الشبكة";

	/* ----------------Contact complete--------------------------------- */

	couponcode_coupon = 'رمز القسيمة';
	termcondition_coupon = 'البنود و الظروف';
	/* ----------------Coupon complete--------------------------------- */
	warning_deeplink = 'تحذير';
	deeplinkingurlnoadded = 'عميق ربط رابط يقم بإضافة';
	/* ----------------Deeplink complete--------------------------------- */

	 error_website = 'خطأ';
	 pleaseentercorrectweburl_website = 'يرجى إدخال عنوان الموقع على شبكة الإنترنت الصحيح';
	/* ----------------Website complete--------------------------------- */
	 
	  youhavebeenblocked_wallpost = 'لقد تم إخفاء';
	  message_wallpost = 'الرسالة';
	  ok_wallpost = 'حسنا';
	  namefieldcannotbeleftblank_wallpost = 'حقل اسم لا يمكن أن تترك فارغة';
	  uploadpic_wallpost = "تحميل صورة";
	  screenname_wallpost = "الاسم الذي سيظهر";
	  next_wallpost = "التالى";
	  enduserlicenseagreement_wallpost = "اتفاقية ترخيص المستخدم النهائي";
	  thisenduserlicenseagreement_wallpost = "هذه اتفاقية ترخيص المستخدم النهائي (الاتفاق) هو بينك وبين "; 
	  andgovernsuseof_wallpost = " ويحكم استخدام هذا التطبيق المتاحة من خلال متجر تطبيقات أبل. عن طريق تثبيت ";
	  apyouagree_wallpost = " التطبيق، فإنك توافق على الالتزام بهذا الاتفاق وفهم أنه لا يوجد التسامح مع المحتوى غير المرغوب فيه. إذا كنت لا توافق مع شروط وأحكام هذه الاتفاقية، التي لا يحق لاستخدام  ";  
	   appnordertoensure_wallpost = " التطبيق <br><br> من أجل ضمان  "; 
	   providesthebestexperiencepossible_wallpost = " يوفر أفضل تجربة ممكنة للجميع، ونحن فرض بقوة سياسة عدم التسامح مع المحتوى غير المرغوب فيه. إذا كنت ترى محتوى غير لائق، يرجى استخدام التقرير كما وجدت ميزة هجومية تحت كل وظيفة <br><br> 1. حفلات <br>هذا الاتفاق بينك وبين ";  
	   onlandnopplenc_wallpost = " فقط، وليس أبل، وشركة (أبل) ورغم ما سبق، فإنك تقر بأن شركة أبل والشركات التابعة لها والمستفيدين طرف ثالث من هذا الاتفاق وأبل لديها الحق في فرض هذا الاتفاق ضدك"; 
	  notappleis_wallpost = ", لا أبل، هو وحده المسؤول عن  ";  
	   aappandits = "التطبيق ومحتواه.<br><br> 2. خصوصية <br> "; 
	   maycollectanduse_wallpost = " قد جمع واستخدام المعلومات حول استخدامك لل  "; 
	   appincludingcertaintypesof_wallpost = " التطبيق، بما في ذلك أنواع معينة من المعلومات من و عن جهازك.  ";  
	   mayusethisinformationaslongas_wallpost = " قد تستخدم هذه المعلومات، طالما أنها في شكل لا تعرف عليك شخصيا، لقياس استخدام وأداء  ";  
	   applimited = " التطبيق. <br><br> 3. ترخيص محدود<br> ";
	   grantsyoualimitednon = " تمنحك غير حصري وغير قابل للتحويل، ترخيصا محدودا للإلغاء لاستخدام "; 
	   appyourpersonal_wallpost = " التطبيق لشخصية أغراضك، غير التجارية. يجوز لك فقط استخدام "; 
	   apponappledevices_wallpost = " التطبيق على أجهزة أبل التي تمتلكها أو تحكم وفقا لما يسمح به المتجر شروط الخدمة. <br><br> 4. قيود العمر <br>باستخدام  ";  
	   apprepresenwarrant_wallpost = " التطبيق، فإنك تقر وتضمن (أ) كنت 17 سنة من العمر أو أكثر وأنت توافق على الالتزام بهذا الاتفاق؛ (ب) إذا كنت تحت سن 17 سنة من العمر، كنت قد حصلت على موافقة التحقق منها من أحد الوالدين أو الوصي القانوني. و (ج) استخدامك لل  ";  
	   apviolateapplicable_wallpost = " التطبيق لا تنتهك أي قانون أو اللوائح المعمول بها. وصولك إلى  ";  
	   appmaterminated_wallpost = " يجوز إنهاء التطبيق دون سابق إنذار إذا  ";  
	   believessole_wallpost = " ويعتقد، وفقا لتقديرها، أن كنت تحت سن 17 عاما، وليس الحصول على موافقة التحقق منها من أحد الوالدين أو الوصي القانوني. إذا كنت أحد الوالدين أو الوصي القانوني والتي تقدمها موافقتك على استخدام طفلك الصورة ل  ";  
	   youagreebound_wallpost = " التطبيق، فإنك توافق على الالتزام بهذا الاتفاق فيما يتعلق باستخدام طفلك الصورة ل  ";  
	   objectionablecontentpolicy_wallpost = " التطبيق. <br><br> 5. سياسة المحتوى المرفوض <br> ولا يجوز ان يقدم محتوى ل  ";  
	  whowillmoderateall_wallpost = ", الذي ستخفف من كل محتوى وتقرر في نهاية المطاف ما إذا كان أو لم يكن لمرحلة ما بعد عرضه على مدى يتضمن مثل هذا المحتوى، وبالتزامن مع، أو جنبا إلى جنب مع أي، المحتوى المرفوض. ويشمل المحتوى للاعتراض، ولكن ليس على سبيل الحصر: (ط) مواد جنسية صريحة. (ب) فاحشة أو قذف أو تشهير أو قذف، العنف و / أو محتوى غير قانوني أو الألفاظ النابية. (ج) المحتوى الذي ينتهك حقوق أي طرف ثالث، بما في ذلك حقوق النشر والعلامات التجارية، والخصوصية، والدعاية أو أي حق شخصي أو الملكية، أو التي هي خادعة أو احتيالية. (د) المحتوى الذي يشجع على استخدام أو بيع المواد غير المشروعة أو تنظيمها، منتجات التبغ، الذخيرة و / أو الأسلحة النارية. و (ت) القمار، بما في ذلك سبيل المثال لا الحصر، أي كازينو على شبكة الإنترنت، والكتب الرياضية، البنغو أو البوكر <br><br> 6. ضمان <br> "; 
	   disclaimsallwarranties_walpost = " ينكر كل الضمانات حول  ";  
	   fullestextentpermitted_wallpost = " التطبيق إلى أقصى حد يسمح به القانون. إلى حد وجود الضمان بموجب القانون الذي لا يمكن التنازل,  ";  
	  notappleshall_wallpost = ", لا أبل، ويجب أن تكون وحدها المسؤولة عن هذا الضمان. <br><br> 7. الصيانة والدعم <br> "; 
	   doesprovideminimalmaintenance_wallpost = " لا توفر الحد الأدنى من الصيانة أو الدعم لذلك، ولكن ليس لدرجة أن أي صيانة أو دعم مطلوب بموجب القانون المعمول به,  ";  
	  appleshallobligatedfurnish_wallpost = ", لا أبل، وجب أن تقدم أي من هذه الصيانة أو الدعم. <br><br> 8. مطالبات المنتج <br> "; 
	  responsibladdressing_walpost = ", لا أبل، هو المسؤول عن معالجة أي مطالبات من قبلك المتعلقة  " ; 
	  includinglimited_wallpost = " التطبيق أو استخدام تكنولوجيا المعلومات، بما في ذلك، ولكن ليس على سبيل الحصر: (ط) أي ادعاء المسؤولية عن المنتجات. (ب) أي ادعاء بأن  ";  
	   failsapplicable_wallpost = " فشل التطبيق لتتوافق مع أي مطلب قانوني أو تنظيمي قابل للتطبيق؛ و (ج) أي مطالبة تنشأ تحت حماية المستهلك أو تشريعات مماثلة. ليس في هذه الاتفاقية ما يمكن اعتباره القبول قد تكون لديك مثل هذه المطالبات <br><br> 9. الطرف الثالث دعاوى الملكية الفكرية <br> "; 
	   shallobligatedindemnifydefend_wallpost = " ليست ملزمة على تعويض ويدافع عنك فيما يتعلق بأي مطالبة طرف ثالث الناشئة عن أو المتعلقة  ";  
	   theextent_wallpost = " التطبيق. إلى حد  ";  
	   isprovideindemnification_wallpost = " مطلوب لتوفير تعويض بموجب القانون المعمول به,  ";  
	  solelyinvestigation_wallpost = ", لا أبل، ويجب أن تكون وحدها المسؤولة عن التحقيق والدفاع والتسوية والتفريغ في أي ادعاء بأن  ";  
	  useinfringe_wallpost = " التطبيق أو استخدامك لها ينتهك أي طرف ثالث حق من حقوق الملكية الفكرية.";
	  aaccept_walpost = "قبول";
	  ddecline_wallpost = "رفض";
	   namefieldcannot_wallpost = ' حقل اسم لا يمكن أن تترك فارغة';
	   alert_wallpost = 'إنذار';
	   selectimagetoupload_wallpost = ' اختر صورة لتحميل';
	   selecupload_wallpost = 'اختر من حيث تريد تحميل';
	   loadmore_wallpost = 'تحميل المزيد من المشاركة'; 
	   updatestatus_walpost = 'تحديث الحالة';
	   addphotovideo_wallpost = 'إضافة صورة/فيديو';
	   saysomething_wallpost = 'قل شيئا عن هذا الفيديو';
	   saysomethingimage_wallpost = 'قل شيئا عن هذه الصورة';
	   post_wallpost = 'بريد';
	   uploadimage_wallpoast = 'تحميل الصور';
	   uploadvideo_wallpost = 'تحميل فيديو';
	   showmore_wallpost = 'عرض المزيد';
	   postedvideo_walpost = 'نشر شريط فيديو جديدا';
	   llike_wallpost = ' مثل';
	   rreportabuse_wallpost = ' التبليغ عن إساءة استخدام';
	   comment_walpost = ' التعليق';
	   viewall_wallpost = 'مشاهدة الكل';
	   postedphoto_wallpost = ' نشر صور جديدة';
	   postedstatus_wallpost = ' نشرت وضعا جديدا';
	   loadmorepost_wallpost = 'تحميل المزيد من المشاركة';
	   messagegg_walpost='الرجاء إدخال تعليق!';
	   peoplelikegg_wallpost = 'الناس الذين يحبون هذا';
	   messagefff_wallpost = 'يرجى إضافة نص إلى تحميل!';
	   messagesome_wallpost = 'بعض خطأ حاول مرة أخرى!';
	   warning_wallpost = 'تحذير';
		/* ----------------WallPost complete--------------------------------- */
	   
	    error_video = 'خطأ';
	    datanotfound_video = 'البيانات لم يتم العثور';
	    ops_video = 'عفوا';
	    nodatafound_video = 'لاتوجد بيانات';
	    showmore_video = "عرض أكثر";
	    serverresponse_video = 'استجابة الملقم';
	    datanotserver_video = 'البيانات لم يتم العثور على الخادم';
	    serverdata_video = 'الخادم لا يرجع البيانات';
	    ok_video = 'حسنا';
	    videos_video = "فيديوهات";
	   /* ----------------Video complete--------------------------------- */
	   
	    defaultbillingaddress_ecomFooddir = 'عنوان الفواتير الافتراضي';
	    defaultshippingaddress_ecomFooddir = 'عنوان الشحن الافتراضي';
	    pleaseenterfirstname_ecomFooddir = 'الرجاء إدخال الاسم الأول';
	    pleaseentertelephoneno_ecomFooddir = 'يرجى إدخال رقم الهاتف';
	    pleaseentervalidtelephoneo_ecomFooddir = 'يرجى إدخال رقم الهاتف';
	    pleaseenteremailaddress_ecomFooddir = 'الرجاء إدخال عنوان البريد الإلكتروني';
	    pleaseentername_ecomFooddir = 'الرجاء إدخال اسم';
	    error_ecomFooddir = 'خطأ';
	    ok_ecomFooddir = 'حسنا';
	    pleaseentervalidphonenumber_ecomFooddir = 'الرجاء إدخال صالحة رقم الهاتف';
	    peaseenterreetaddress_ecomFooddir = 'يرجى إدخال عنوان الشارع';
	    pleaseenteryourcity_ecomFooddir = 'الرجاء إدخال مدينتك';
	    pleaserovince_ecomFooddir = 'الرجاء إدخال الدولة / مقاطعة';
	    pleaseostalcode_ecomFooddir = 'الرجاء إدخال الرمز البريدي / الرمز البريدي';
	    pleaseentercountry_ecomFooddir = 'الرجاء إدخال البلد';
	   /* ----------------EcomFoodDir complete--------------------------------- */
	   
	    enterthekeywordtosearch_education = "أدخل كلمة للبحث";
	    search_education = "بحث";
	    suggestions_educatiuon = " اقتراحات: ";
	    pleaseconnecttointernet_education = "يرجى الاتصال بالإنترنتt";
	    pleasarch_education = "الرجاء تحديد خيار للبحث.";
	    nomatch_education = "لا يوجد تطابق";
	    pleasegain_education = "حاول مرة اخرى";
	    selecategory_education = "اختر تصنيف";
	    or_education = "أو";
	   /* ----------------Education complete--------------------------------- */

	     pleasecheckinternetconnection_ereader = 'يرجى التحقق من الاتصال بالإنترنت.';
	     message_ereader = 'الرسالة';
	     ok_erader = 'حسنا';
	     downloadingerror_ereader = "تحميل الخطأ";
	     delete_ereader = "حذف";
	     selecookselete_ereader = 'حدد كتب حذف';
	     done_ereader = 'فعله';
	     booklist_ereader = "قائمة الكتب!";
	    /* ----------------Ereader complete--------------------------------- */
	     
	      oops_event = "عفوا ! غير قادر على فتح";
	      weburlnotavailable_event = "لا Weburl متاحة";
	      serverresponse_event = 'لا الويب رابط متاحة';
	      nodatafound_event = 'لاتوجد بيانات,\nيرجى المحاولة بعد بعض الوقت';
	      eventee_event = 'حدث';
	      noupcomingeventfound_event = 'لا توجد أحداث قادمة العثور على';
	      nopasteventfound_event = 'لا حدث في الماضي العثور على';
	      showmore_event = "عرض أكثر"; 
	      upcomingevents_event = "الأحداث القادمة";
	      pastevents_event = "الأحداث الماضية";
	      map_event = "رسم خريطة";
	      share_event = "شارك";
	     /* ----------------Event complete--------------------------------- */
	      
	      
	       ErrorEmailField="الرجاء إدخال بريد إلكتروني صحيح";
	       ErrorPhoneField="الرجاء إدخال رقم هاتف صحيح";
	       pleaseentervalidemail_builder = "الرجاء إدخال بريد إلكتروني صحيح";
	       pleaseentervalidphonenumber_builder = "الرجاء إدخال رقم هاتف صحيح";
	       checkschedule_builder = "تحقق الجدول الزمني";
	       test_builder = "اختبار"; 
	       schedule_builder = 'جدول';
	       sun_builder = 'شمس';
	       mon_builderr = 'الإثنين';
	       tue_builder = 'الثلاثاء';
	       wed_builder = 'تزوج';
	       thu_builder = 'الخميس';
	       fri_builder = 'الجمعة';
	       sat_builder = 'السبت';
	       closed_builder = ' مغلق ';
	       selectgender_builder = 'حدد نوع الجنس';
	       male_builder = 'ذكر';
	       female_buildrer = 'أنثى';
	       attachfile_builder = 'إرفاق ملف';
	       usd_builder = 'دولار أمريكي';
	       gbp_builder = 'GBP';
	       eur_builder = 'يورو';
	       aud_builder = 'AUD';
	       cad_builder = 'CAD';
	       chf_builder = 'CHF';
	       czk_builder = 'CZK';
	       dkk_builder = 'DKK';
	       hkd_builder = 'HKD';
	       huf_builder = 'HUF';
	       jpy_builder = 'ين يابانى';
	       nok_builder = 'NOK';
	       nzd_builder = 'NZD';
	       pln_builder = 'PLN';
	       sek_builder = 'SEK';
	       sgd_builder = 'SGD';
	       country_builder ='بلد ';
	       selectcountry_builder ='اختر البلد';
	       paymenor_builder = "دفع ل ";
	       notvalid_builder = 'غير صالح !';
	       notvalidemail_builder = 'لا بريد إلكتروني صالح !';
	       alert_builder = 'إنذار';
	       ok_builder = 'حسنا';
	       attachmensizeexceed_builder = 'حجم المرفق يتجاوز من 8MB';
		     /* ----------------Formbuilder complete--------------------------------- */

	        photos_gallery = "الصور";
	        serverresponse_gallery = 'استجابة الملقم';
	        unableloadphotos_gallery = 'غير قادر على تحميل صور !';
	        error_gallery = 'خطأ!';
	        albumempty_gallery = 'ألبوم فارغة';
	        followedby_gallery = "تليها";
	        follows_gallery = 'يتبع';
	        showmore_gallery = 'عرض أكثر';
	        photostream_gallery = "تيار الصورة";
	        sets_gallery = "مجموعات";
	        alert_gallery = 'إنذار';
	        nosetfound_gallery = 'لا مقاعد العثور!';
	        photooo_gallery = "صورة فوتوغرافية";
	        viewallets = "عرض جميع مجموعات";
	       /* ----------------Gallery complete--------------------------------- */
	        
	         follow_plus = "إتبع";
		       /* ----------------gogleplus complete--------------------------------- */
	         
	         
	          servernotdata_insta = 'الخادم لا يرجع البيانات';
	          datanotserver_insta ='البيانات لم يتم العثور على الخادم !';
	          photo_insta = "صورة فوتوغرافية";
	          follow_insta = "إتبع";
	          following_insta = "التالي";
	          showmore_insta = "عرض أكثر";
	          comments_insta = "تعليقات";
	          likes_insta = "الإعجابات";
	          likethis_insta = "مثله";
	         /* ----------------instagram complete--------------------------------- */
	          
	          
	           oops_loyalty = 'عفوا';
	           serverresponding_loyalty = 'الخادم لا يستجيب\n الرجاء معاودة المحاولة في وقت لاحق';
	           alert_loyalty = 'إنذار!!';
	           cardalreadyredeemed_loyalty = 'افتدى البطاقة بالفعل';
	           error_loyalty = 'خطأ';
	           pleaseuseyourfreebiestamp_loyalty = 'الرجاء استخدام الطوابع الهدية الترويجية الخاصة بك';
	           typingecuritycode_loyalty = "تحقق عن طريق كتابة قانون الأمن";
	           validatescanningcode_loyalty = "تحقق عن طريق مسح رمز الاستجابة السريعة";
	           congrats_loyalty = "مبروك";
	           networkproblem_loyalty = 'مشكلة شبكة';
	           internetnotavailable_loyalty = 'الإنترنت غير متوفر';
	           invalidcode_loyalty = 'رمز غير صالح';
	           pleaseentervalidcode_loyalty = 'الرجاء إدخال رمز صالح';
	          /* ----------------loyalty complete--------------------------------- */
	           
	            loyaltycardMobHeaderLabel = "عضوية نموذج طلب الصورة";
	            loyaltycardMobNameLabel = "اسم";
	            loyaltycardMobEmailLabel = "البريد الإلكتروني ";
	            loyaltycardMobPhoneLabel = "رقم الهاتف";

	            serverresponse_card = 'استجابة الملقم';
	            yourcardtemporarydisapproved_card = 'بطاقتك هي مرفوضة المؤقت';
	            unableloaddata_card = 'غير قادر على تحميل البيانات';
	            joinloyaltyprogram_card = "تاريخ برنامج الولاء لدينا"; 
	            datanotfound_card = 'البيانات لم يتم العثور';
	            alert_card = 'إنذار';
	            pleasephonenumber_card = 'الرجاء إدخال رقم الهاتف صالح';
	            issuedate_card = "تاريخ الاصدار";
	            id_card = ":هوية شخصية ";
	            validtill_card = "صالحة حتى";
	            point_card = "نقاط";
	            balance_card = "توازن";
	            scancode_card = "مسح رمز الاستجابة السريعة";
	            add_card = "إضافة";
	            redeem_card = "خلص";
	            ok_card = 'حسنا';
	            mandatoryfieldsblank_card = 'لا ينبغي أن يكون الحقول الإلزامية فارغة';
	            entervalid_card = 'أدخل البريد الإلكتروني ساري المفعول رقم';
	            availablepoints_card = ":النقاط المتاحة ";
	            pleasehandcashieraddpoints_card = "يرجى تسليم الجهاز إلى أمين الصندوق لإضافة نقاط";
	            validatetypingsecuritycode_card = "تحقق عن طريق كتابة قانون الأمن";
	            validatescanningqrcode_card = "تحقق عن طريق مسح رمز الاستجابة السريعة";
	            cancel_card = "إلغاء";
	            enterpoints_card = "أدخل نقاط";
	            entersecuritycode_card = "أدخل رمز الأمان";
	            pleasehanddeviceredeempoints_card = "يرجى تسليم الجهاز إلى أمين الصندوق لاستبدال النقاط";
	            warning_card = 'تحذير';
	            pleaseentervalidunlockcode_card = 'الرجاء إدخال رمز فتح ساري المفعول';
	            insufficientpoints_card = 'نقطة غير كافية';
	            pleaseenterredeemvaluegreater_card = 'الرجاء إدخال استبدال قيمة أكبر من 0';
	            pleaseenteraddvaluegreater_card = 'الرجاء إدخال إضافة قيمة أكبر من 0';
	            pleasetryagain_card = 'حاول مرة اخرى';
	            pleaseenterpoints_card = 'الرجاء إدخال نقاط';
	            nofunctionalityimplemented_card = 'لا وظائف تنفيذها';
	           /* ----------------loyaltycard complete--------------------------------- */
	            
	             geolocationnotsupportedbrowser_map = "غير معتمد تحديد الموقع الجغرافي عن طريق هذا المتصفح";
		           /* ----------------map complete--------------------------------- */


	             /******************** START GEETA CODE **************************************/

	         	/*---------------- START TEXTPAGE JS ------------------------------- */
	         	        // in this js no changes.
	         	/*---------------- END TEXTPAGE JS ------------------------------- */


	         /*---------------- START TESTIMONIAL JS ------------------------------- */
	         	       // in this js no changes.
	         	/*---------------- END TESTIMONIAL JS ------------------------------- */

	         	/*---------------- START SURVEY JS ------------------------------- */
	             	       // in this js no changes.
	             	/*---------------- END SURVEY JS ------------------------------- */

	             	/*---------------- START SOCIAL JS ------------------------------- */
	                     	       // in this js no changes.
	                  /*---------------- END SOCIAL JS ------------------------------- */
	                  /*---------------- START SCHEDULING JS ------------------------------- */
	                              	       // in this js no changes.
	                  /*---------------- END SCHEDULING JS ------------------------------- */



	         	/*---------------- START TOOLS JS ------------------------------- */
	          mortage_cal_heading_tools = "حاسبة الرهن العقاري";
	          mortage_cal_home_price_tools = "المنزل الأسعار";
	          mortage_cal_down_payment_tools = "الدفعة الأولى";
	          mortage_cal_down_payment_less_home_price_tools = "الدفعة المقدمة يجب أن تكون أقل من أسعار المنازل";
	          mortage_cal_loan_amt_tools = "مبلغ القرض";
	          mortage_cal_interest_rate_tools = "سعر الفائدة";
	          mortage_cal_loan_term_tools = "قرض لأجل";
	          mortage_cal_annual_prop_tax_tools = "الضرائب العقارية السنوية";
	          mortage_cal_insurance_tools = "تأمين";
	          mortage_cal_monthly_amt_tools = "المبلغ الشهري";
	          mortage_cal_amt_tools = "كمية";
	          mortage_cal_calculate_tools = "احسب";
	          mortage_cal_estimate_monthly_cal_tools = "ولا يشمل هذا المبلغ يقدر أقساط التأمين والرهن العقاري الشهرية. القرض الخاص بك يمكن أن تخضع للتأمين الرهن العقاري الشهرية. يرجى الاتصال المقرض الخاص بك لتوضيح ما اذا القرض الخاص بك وسوف يكون التأمين على الرهن العقاري الشهرية.";
	          alert_blank_field_tools = "فارغ الميدان";
	          alert_enter_price_amt_tools = "الرجاء إدخال سعر المبلغ";
	          alert_enter_down_pay_amt_tools = "الرجاء أدخل مبلغ الدفع لأسفل";
	          weather_address_title_tools = "انقر لرؤية تقرير الطقس";
	          inner_html_msg_location_not_found_tools = "ا يمكن العثور على الموقع";
	          inner_html_msg_error_occured_tools = "حدث خطأ";
	          alert_for_alert_title_tools = "إنذار";
	          alert_internet_conn_not_avail_tools = "اتصال بالإنترنت غير متاح";
	          alert_unable_to_retrive_current_location_tools = "غير قادر على استرداد موقعك الحالي. يرجى بدوره على إعدادات-> في الخصوصية> الموقع خدمات التطبيقات.";
	          in_serach_click_weather_geocode_weatherloaction_tools = "الطقس الموقع";
	          in_serach_click_weather_geocode_weatherlist_tools = "weatherList";

	         	/*---------------- END TOOLS JS ------------------------------- */

	         	/*---------------- START TWITTER JS ------------------------------- */
	         	 alert_server_response_twitter = "استجابة الملقم";
	              alert_data_not_found_on_server_twitter = "البيانات لم يتم العثور على الخادم!"
	              create_twit_screen_follow_twitter = "إتبع";
	              create_twit_screen_tweets_twitter = "تغريدات";
	              create_twit_screen_followers_twitter = "المتابعون";
	             /*---------------- END TWITTER JS ------------------------------- */

	             /*---------------- START SOCIALAPP JS ------------------------------- */
	                         	      social_menu_slide_main_menu_soicalapp = "القائمة الرئيسية";
	                                                              social_login_fb_twitter_msg_socialapp = "لم يكن قادرا على تسجيل الدخول حاول مرة أخرى!";
	                                                              social_login_fb_alert_socialapp = "إنذار";
	                                                              social_login_fb_alert_ok_socialapp = "حسنا";
	                                                              get_social_login_dont_have_account_yet_socialapp = "لا تملك حسابا حتى الآن";
	                                                              get_social_login_signup_now_socialapp = "أفتح حساب الأن";
	                                                              get_social_login_email_id_socialapp = "البريد الإلكتروني معرف";
	                                                              get_social_login_password_socialapp = "كلمه السر";
	                                                              get_social_login_forgot_pass_socialapp = "نسيت رقمك السري ؟";
	                                                              get_social_login_placeholder_emailid_socialapp = "البريد الإلكتروني معرف";
	                                                              get_social_login_placeholder_password_socialapp = "كلمه السر";
	                                                              email_already_exist_socialapp = "البريد الإلكتروني معرف موجودة بالفعل!";
	                                                              enter_valid_email_id_socialapp = "الرجاء إدخال رقم بريد إلكتروني صالح!";
	                                                              please_enter_pass_socialapp = "الرجاء إدخال كلمة السر!";
	                                                              please_enter_email_socialapp = "يرجى إدخال البريد الإلكتروني!";
	                                                              blocked_user_contact_admin_socialapp = "تم حظر هذا المستخدم. يرجى الاتصال على مدير";
	                                                              alert_warning_socialapp = "تحذير";
	                                                              invalid_nameandpass_socialapp = "اسم المستخدم أو كلمة المرور غير صالحة";
	                                                              invalid_credential_socialapp = "الاعتمادات غير صالح";
	                                                              user_blocked_socialapp = "لقد تم حظر!";
	                                                              alert_message_socialapp = "الرسالة";
	                                                              div_forgotten_pass_socialapp = "كلمة سر منسية";
	                                                              div_email_id_socialapp = "البريد الإلكتروني:";
	                                                              div_image_code_socialapp = "كود الصورة";
	                                                              div_placeholdere_email_socialapp = "يرجى إدخال البريد الإلكتروني الخاص بك";
	                                                              div_placeholdere_image_code_socialapp = "الرجاء إدخال أدناه صورة رمز";
	                                                              enter_captcha_image_socialapp = "الرجاء إدخال أدناه صورة رمز!";
	                                                              incorrect_captcha_code_socialapp = "رمز غير صحيح دخلت!";
	                                                              new_pass_sent_onyour_mail_socialapp = "تم إرسال كلمة المرور الجديدة إلى عنوان البريد الإلكتروني";
	                                                              alert_msg_for_success_socialapp = "نجاح";
	                                                              email_not_match_our_record_socialapp = "البريد الإلكتروني غير المتطابقة مع سجلنا";
	                                                              msg_fail_socialapp ="فشل";
	                                                              msg_email_not_match_our_record_enter_register_mail_socialapp = "البريد الإلكتروني غير متطابق مع رقم قياسي لدينا! يرجى إدخال البريد الإلكتروني المسجل.";
	                                                              signuppagesocial_html_signup_forapp_socialapp = "التسجيل للحصول على التطبيقات";
	                                                              signuppagesocial_html_username_socialapp = "اسم المستخدم*";
	                                                              signuppagesocial_html_placeholder_username_socialapp = "اسم المستخدم";
	                                                              signuppagesocial_html_emailid_socialapp = "معرف البريد الإلكتروني *";
	                                                              signuppagesocial_html_placeholder_emaiid_socialapp = "البريد الإلكتروني معرف";
	                                                              signuppagesocial_html_pass_socialapp = "كلمه السر*";
	                                                              signuppagesocial_html_placeholder_pass_socialapp = "كلمه السر";
	                                                              signuppagesocial_html_conpass_socialapp = "تأكيد كلمة المرور*";
	                                                              signuppagesocial_html_placeholder_conpass_socialapp = "تأكيد كلمة المرور";
	                                                              signuppagesocial_html_usr_licence_agreement_socialapp = "اتفاقية ترخيص المستخدم النهائي";
	                                                              signuppagesocial_html_justify_licence_one_socialapp = "هذه اتفاقية ترخيص المستخدم النهائي (الاتفاق) هو بينك وبين";
	                                                              signuppagesocial_html_justify_licence_two_socialapp = "ويحكم استخدام هذا التطبيق المتاحة من خلال متجر تطبيقات أبل. عن طريق تثبيت";
	                                                              signuppagesocial_html_justify_licence_third_socialapp = "التطبيق، فإنك توافق على الالتزام بهذا الاتفاق وفهم أنه لا يوجد التسامح مع المحتوى غير المرغوب فيه. إذا كنت لا توافق مع شروط وأحكام هذه الاتفاقية، التي لا يحق لاستخدام";
	                                                              signuppagesocial_html_justify_licence_fourth_socialapp = "من أجل ضمان";
	                                                              signuppagesocial_html_justify_licence_third_socialapp = "يوفر أفضل تجربة ممكنة للجميع، ونحن فرض بقوة سياسة عدم التسامح مع المحتوى غير المرغوب فيه. إذا كنت ترى محتوى غير لائق، يرجى استخدام بلغ عن ميزة هجومية وجدت تحت كل وظيفة.";
	                                                              signuppagesocial_html_justify_licence_fourth_br_socialapp = "1. الأطراف";
	                                                              signuppagesocial_html_justify_licence_fourth_br_one_socialapp = "هذا الاتفاق بينك وبين";
	                                                              signuppagesocial_html_justify_licence_fifth_socialapp = "فقط، وليس أبل، وشركة (أبل). ورغم ما سبق، فإنك تقر بأن شركة أبل والشركات التابعة لها والمستفيدين طرف ثالث من هذا الاتفاق وأبل لديها الحق في فرض هذا الاتفاق ضدك.";
	                                                              signuppagesocial_html_justify_licence_six_socialapp = "وليس أبل، هو وحده المسؤول عن";
	                                                              signuppagesocial_html_justify_licence_seven_socialapp = "التطبيق ومحتواه.";
	                                                              signuppagesocial_html_justify_licence_seven_br_socialapp = "2. الخصوصية";
	                                                              signuppagesocial_html_justify_licence_eight_socialapp = "قد جمع واستخدام المعلومات حول استخدامك لل";
	                                                              signuppagesocial_html_justify_licence_nine_socialapp = "التطبيق، بما في ذلك أنواع معينة من المعلومات من و عن جهازك.";
	                                                              signuppagesocial_html_justify_licence_ten_socialapp = "قد تستخدم هذه المعلومات، طالما أنها في شكل لا تعرف عليك شخصيا، لقياس استخدام وأداء";
	                                                              signuppagesocial_html_justify_licence_app_socialapp = "التطبيق.";
	                                                              signuppagesocial_html_justify_licence_ten_br_socialapp = "3. ترخيص محدود";
	                                                              signuppagesocial_html_justify_licence_eleven_socialapp = "تمنحك غير حصري وغير قابل للتحويل، ترخيصا محدودا للإلغاء لاستخدام";
	                                                              signuppagesocial_html_justify_licence_tweleve_socialapp = "التطبيق لشخصية أغراضك، غير التجارية. يجوز لك فقط استخدام";
	                                                              signuppagesocial_html_justify_licence_thirteen_socialapp = "التطبيق على أجهزة أبل التي تمتلكها أو تحكم وفقا لما يسمح به المتجر شروط الخدمة.";
	                                                              signuppagesocial_html_justify_licence_thirteen_br_socialapp = "4. قيود العمر";
	                                                              signuppagesocial_html_justify_licence_byusing_socialapp = "باستخدام";
	                                                              signuppagesocial_html_justify_licence_fourteen_socialapp = "التطبيق، فإنك تقر وتضمن (أ) كنت 17 سنة من العمر أو أكثر وأنت توافق على الالتزام بهذا الاتفاق؛ (ب) إذا كنت تحت سن 17 سنة من العمر، كنت قد حصلت على موافقة التحقق منها من أحد الوالدين أو الوصي القانوني. و (ج) استخدامك لل";
	                                                              signuppagesocial_html_justify_licence_fifteen_socialapp = "التطبيق لا تنتهك أي قانون أو اللوائح المعمول بها. وصولك إلى";
	                                                              signuppagesocial_html_justify_licence_sixteen_socialapp = "يجوز إنهاء التطبيق دون تنبيه إذا";
	                                                              signuppagesocial_html_justify_licence_seventeen_socialapp = "ويعتقد، وفقا لتقديرها، أن كنت تحت سن 17 عاما، وليس الحصول على موافقة التحقق منها من أحد الوالدين أو الوصي القانوني. إذا كنت أحد الوالدين أو الوصي القانوني والتي تقدمها موافقتك على استخدام طفلك الصورة ل";
	                                                              signuppagesocial_html_justify_licence_eighteen_socialapp = "التطبيق، فإنك توافق على الالتزام بهذا الاتفاق فيما يتعلق باستخدام طفلك الصورة ل";
	                                                              signuppagesocial_html_justify_licence_eighteen_br_socialapp = "5. سياسة المحتوى المرفوض";
	                                                              signuppagesocial_html_justify_licence_nineteen_socialapp = "ولا يجوز ان يقدم محتوى ل";
	                                                              signuppagesocial_html_justify_licence_twentyone_socialapp = "الذي ستخفف من كل محتوى وتقرر في نهاية المطاف ما إذا كان أو لم يكن لمرحلة ما بعد عرضه على مدى يتضمن مثل هذا المحتوى، وبالتزامن مع، أو جنبا إلى جنب مع أي، المحتوى المرفوض. ويشمل المحتوى للاعتراض، ولكن ليس على سبيل الحصر: (ط) مواد جنسية صريحة. (ب) فاحشة أو قذف أو تشهير أو قذف، العنف و / أو محتوى غير قانوني أو الألفاظ النابية. (ج) المحتوى الذي ينتهك حقوق أي طرف ثالث، بما في ذلك حقوق النشر والعلامات التجارية، والخصوصية، والدعاية أو أي حق شخصي أو الملكية، أو التي هي خادعة أو احتيالية. (د) المحتوى الذي يشجع على استخدام أو بيع المواد غير المشروعة أو تنظيمها، منتجات التبغ، الذخيرة و / أو الأسلحة النارية. و (ت) القمار، بما في ذلك سبيل المثال لا الحصر، أي كازينو على شبكة الإنترنت، والكتب الرياضية، بنغو أو لعبة البوكر.";
	                                                              signuppagesocial_html_justify_licence_twentyone_br_socialapp = "6. الضمان";
	                                                              signuppagesocial_html_justify_licence_twentytwo_socialapp = "ينكر كل الضمانات حول";
	                                                              signuppagesocial_html_justify_licence_twentythird_socialapp = "التطبيق إلى أقصى حد يسمح به القانون. إلى حد وجود الضمان بموجب القانون الذي لا يمكن التنازل،";
	                                                              signuppagesocial_html_justify_licence_twentyfour_socialapp = "وليس أبل، ويجب أن تكون وحدها المسؤولة عن هذا الضمان.";
	                                                              signuppagesocial_html_justify_licence_twentyfive_br_socialapp = "7. الصيانة والدعم";
	                                                              signuppagesocial_html_justify_licence_twentysix_socialapp = "لا توفر الحد الأدنى من الصيانة أو الدعم لذلك، ولكن ليس لدرجة أن أي صيانة أو دعم هو مطلوب بموجب القانون المعمول به،";
	                                                              signuppagesocial_html_justify_licence_twentyseven_socialapp = "وليس أبل، وجب أن تقدم أي من هذه الصيانة أو الدعم.";
	                                                              signuppagesocial_html_justify_licence_twentyseven_br_socialapp = "8. المطالبات المنتج";
	                                                              signuppagesocial_html_justify_licence_twentyeight_socialapp = "وليس أبل، هي المسؤولة عن معالجة أي مطالبات من قبلك المتعلقة";
	                                                              signuppagesocial_html_justify_licence_twentyenine_socialapp = "التطبيق أو استخدام تكنولوجيا المعلومات، بما في ذلك، ولكن ليس على سبيل الحصر: (ط) أي ادعاء المسؤولية عن المنتجات. (ب) أي ادعاء بأن";
	                                                              signuppagesocial_html_justify_licence_thirty_socialapp = "فشل التطبيق لتتوافق مع أي مطلب قانوني أو تنظيمي قابل للتطبيق؛ و (ج) أي مطالبة تنشأ تحت حماية المستهلك أو تشريعات مماثلة. ليس في هذه الاتفاقية ما يمكن اعتباره القبول قد تكون لديك مثل هذه المطالبات.";
	                                                              signuppagesocial_html_justify_licence_thirty_br_socialapp = "9. الطرف الثالث دعاوى الملكية الفكرية";
	                                                              signuppagesocial_html_justify_licence_thirtyone_socialapp = "ليست ملزمة على تعويض ويدافع عنك فيما يتعلق بأي مطالبة طرف ثالث الناشئة عن أو المتعلقة";
	                                                              signuppagesocial_html_justify_licence_thirtytwo_socialapp = "التطبيق. إلى حد";
	                                                              signuppagesocial_html_justify_licence_thirtythree_socialapp = "مطلوب لتوفير تعويض بموجب القانون المعمول به،";
	                                                              signuppagesocial_html_justify_licence_thirtyfour_socialapp = "وليس أبل، ويجب أن تكون وحدها المسؤولة عن التحقيق والدفاع والتسوية والتفريغ في أي ادعاء بأن";
	                                                              signuppagesocial_html_justify_licence_thirtyfive_socialapp = "التطبيق أو استخدامك لها ينتهك أي طرف ثالث حق من حقوق الملكية الفكرية.";
	                                                              signuppagesocial_html_justify_licence_accept_socialapp = "قبول";
	                                                              signuppagesocial_html_justify_licence_decline_socialapp = "رفض";
	                                                              alert_invalid_emailid_socialapp = "عنوان البريد الإلكتروني غير صالح!";
	                                                              alert_enter_username_socialapp = "الرجاء إدخال اسم المستخدم!";
	                                                              alert_conpass_not_match_socialapp = "تأكيد كلمة المرور غير متطابق!";
	                                                              alert_pass_toshort_socialapp = "كلمة المرور قصيرة جدا!";
	                                                              signup2pagesocial_fill_urinfo_socialapp = "ملء المعلومات الخاصة بك";
	                                                              signup2pagesocial_aboutme_socialapp = "عني";
	                                                              signup2pagesocial_geneder_socialapp = "جنس";
	                                                              signup2pagesocial_geneder_male_socialapp = "ذكر";
	                                                              signup2pagesocial_geneder_female_socialapp = "أنثى";
	                                                              signup2pagesocial_birthday_socialapp = "تاريخ الميلاد";
	                                                              alert_about_me_socialapp = "الرجاء إدخال معلومات عني!";
	                                                              alert_select_geneder_socialapp = "يرجى تحديد نوع الجنس!";
	                                                              alert_select_birthdate_socialapp = "الرجاء تحديد تاريخ ميلاد!";
	                                                              alert_select_location_socialapp = "الرجاء إدخال الدولة!";
	                                                              alert_enter_phone_socialapp = "الرجاء إدخال الهاتف!";
	                                                              alert_enter_address_socialapp = "يرجى إدخال عنوان!";
	                                                              alert_enter_country_socialapp = "يرجى اختيار الدولة!";
	                                                              alert_enter_state_socialapp = "الرجاء تحديد الدولة!";
	                                                              alert_enter_city_socialapp = "الرجاء تحديد المدينة!";
	                                                              alert_enter_zip_socialapp = "الرجاء تحديد الرمز البريدي!";
	                                                              latestsocial_show_more_socialapp = "عرض المزيد";
	                                                              social_view_all_socialapp = "مشاهدة الكل";
	                                                              captionnnWallPost_image_social_saysomething_socialapp = "قل شيئا عن هذه الصورة ...";
	                                                              captionnnWallPost_image_social_saysomething_video_socialapp = "قل شيئا عن هذا الفيديو ...";
	                                                              social_post_socialapp = "الصفحات:";
	                                                              placeholder_search_socialapp = "بحث...";
	                                                              without_palceholder_search_socialapp = "بحث";
	                                                              nolike_found_socialapp = "لا توجد ملفات";
	                                                              followers_socialapp = "المتابعون:";
	                                                              subscriber_socialapp = "مشتركين:";
	                                                              member_since_socialapp = "عضو منذ:";
	                                                              following_socialapp = "التالي";
	                                                              decription_socialapp = "وصف:";
	                                                              post_socialapp = "المشاركات:";
	                                                              subscribe_without_colon_socialapp = "مشتركين";
	                                                              follower_without_colon_socialapp = "المتابعون";
	                                                              follow_witjout_s_socialapp = "إتبع";
	                                                              subscribed_socialapp = "المشترك";
	                                                              subscribe_without_s_socialapp = "الاشتراك";
	                                                              edit_profile_socialapp = "تعديل الملف الشخصي";
	                                                              add_comment_socialapp = "اضف تعليق";
	                                                              alert_not_allowed_comment_socialapp = "لا يسمح لك للتعليق على هذا المقال!";
	                                                              comment_socialapp = "التعليق";
	                                                              unlike_socialapp = "مختلف";
	                                                              like_socialapp = "مثل";
	                                                              alert_enter_comment_socialapp = "الرجاء إدخال تعليق!";
	                                                              no_comments_there_socialapp = "لا توجد تعليقات على هذه الوظيفة";
	                                                              no_likes_there_socialapp = "لا يحب على هذه الوظيفة";
	                                                              by_socialapp = "بواسطة";
	                                                              mystream_socialapp = "Mystream";
	                                                              all_socialapp = "جميع";
	                                                              post_without_colon = "المشاركات";
	                                                              comments_socialapp = "تعليقات";
	                                                              follows_socialapp = "يتبع";
	                                                              likes_socialapp = "الإعجابات";
	                                                              subscribe_socialapp = "اشتراكات";
	                                                              none_socialapp = "لا شيء";
	                                                              top_hundred_user_socialapp = "أفضل 100 مستخدم";
	                                                              alert_msg_for_successfully_updated_socialapp = "تم التحديث بنجاح!";
	                                                              alert_msg_usrname_cant_blank_socialapp = "اسم المستخدم لا يمكن أن تكون فارغة!";
	                                                              alert_msg_email_cant_blank_socialapp = "البريد الإلكتروني لا يمكن أن يكون فارغا!";
	                                                              inner_msg_emailid_already_exist_socialapp = "البريد الإلكتروني معرف موجودة بالفعل!";
	                                                              inner_msg_not_valid_email_address_socialapp = "البريد الإلكتروني غير صالح!";
	                                                              alert_msg_enter_current_password_socialapp = "يرجى إدخال كلمة المرور الحالية!";
	                                                              alert_msg_enter_new_pass_socialapp = "يرجى إدخال كلمة المرور الجديدة!";
	                                                              alert_msg_enter_confirm_password_socialapp = "الرجاء إدخال تأكيد كلمة السر!";
	                                                              alert_msg_password_doesnt_match_socialapp = "كلمة المرور غير مطابقة!";
	                                                              alert_msg_selectfrom_where_want_socialapp = "اختر من حيث تريد تحميل!";
	                                                              alert_gallery_camera_socialapp = "كاميرا، معرض";
	                                                              alert_gallery_camera_cancel_socialapp = "كاميرا، معرض، الغاء";
	                                                              alert_msg_addtext_toupload_image_socialapp = "يرجى إضافة نص إلى تحميل صورة!";
	                                                              alert_msg_addtext_toupload_video_socialapp = "يرجى إضافة نص لتحميل الفيديو!";
	                                                              alert_msg_addtext_toupload_socialapp = "يرجى إضافة نص إلى تحميل!";
	                                                              alert_msg_successfully_uploaded_socialapp = "تم التحميل بنجاح!";
	                                                              alert_msg_some_error_occured_socialapp = "بعض خطأ حاول مرة أخرى!";
	                                                              vedio_upload_socialapp = "تحميل الفيديو";
	                                                              gender_male_socialapp = "ذكر";
	                                                              gender_female_socialapp = "أنثى";
	                                                              subscriber_without_s_socialapp = "مكتتب";
	                                                              follower_without_s_socialapp = "المتابعون";
	                                                              filter_by_location_socialapp = "تصفية حسب الموقع";
	                                                              follow_all_socialapp ="اتبع جميع";
	                                                              login_socialapp = "تسجيل الدخول";
	                                                              signuppagesocial_html_continue_socialapp = "استمر";
	                     /*---------------- END SOCIALAPP JS ------------------------------- */

	           /*-------------------- START RSS JS ------------------------------------ */
	            server_response_rss = "استجابة الملقم";
	             data_not_found_onserver_rss = "البيانات لم يتم العثور على الخادم!";
	             /*-------------------- END RSS JS ------------------------------------ */

	             /*-------------------- START FOR REVIEW JS --------------------------- */
	              alert_msg_for_alert_review = "إنذار";
	               alert_thanks_for_review_admin_approve_review = "شكرا لتقديم رأيك. سيتم نشره إلى التطبيق بعد أن تم الموافقة عليها من قبل المشرف التطبيق.";
	               alert_msg_oops_review = "عفوا";
	               alert_server_not_responding_try_later_review = "الخادم لا يستجيب \ ن الرجاء المحاولة مرة أخرى في وقت لاحق";
	               alert_comments_fields_cant_blank_review = "* تعليقات الحقل لا يمكن أن تترك فارغة";
	               enter_valid_email_address_review = "أدخل عنوان بريد إلكتروني صالح";
	               name_filed_cant_blank_review = "* حقل اسم لا يمكن أن تترك فارغة";
	               please_select_rating_review = "* الرجاء تحديد تصنيفات";
	               rate_and_review = "معدل استعراض &"
	               name_reviews = "استعراض";
	            /*-------------------- END FOR REVIEW JS --------------------------- */

	            /*-------------------- START FOR REMINDER JS --------------------------- */
	            set_reminder = "تعيين تذكير لديك";
	             adddataid_placeholder_title_reminder = "العنوان (مثل الاسم)";
	             adddataid_placeholder_phoneno_reminder = "رقم الهاتف";
	             adddataid_placeholder_message_reminder = "الرسالة...";
	             alert_reminder = "تنبيه!";
	             alert_required_field_cant_empty_reminder = "حقل مطلوب لا يمكن أن يكون فارغا";
	             reminder_deleted = "تم حذف التذكير";

	             selecttypeid_select_id_reminder = "حدد نوع:";
	             selecttypeid_daily_reminder = "يومي";
	             selecttypeid_month_reminder = "شهر";
	             monthly_reminder = "شهريا";
	             selecttypeid_yearly_reminder = "سنوي";

	             dayid_monday_reminder = "الإثنين";
	             dayid_tuesday_reminder = "الثلاثاء";
	             dayid_wednesday_reminder = "الأربعاء";
	             dayid_thursday_reminder = "الخميس";
	             dayid_friday_reminder = "الجمعة";
	             dayid_saturday_reminder = "يوم السبت";
	             dayid_sunday_reminder = "الأحد";
	             dayid_everyday_reminder = "كل يوم";

	             yearid_months_january_reminder = "كانون الثاني";
	             yearid_months_feb_reminder = "فبراير";
	             yearid_months_march_reminder = "مارس";
	             yearid_months_april_reminder = "أبريل";
	             yearid_months_may_reminder = "قد";
	             yearid_months_june_reminder = "يونيو";
	             yearid_months_july_reminder = "يوليو";
	             yearid_months_august_reminder = "أغسطس";
	             yearid_months_sep_reminder = "سبتمبر";
	             yearid_months_oct_reminder ="شهر اكتوبر";
	             yearid_months_nov_reminder = "تشرين الثاني"
	             yearid_months_dec_reminder = "ديسمبر";

	             after_datetime_reminder = "بعد تاريخ / وقت!";
	             date_placeholder_reminder = "تاريخ";
	             reminder_time = "تذكير الوقت!";
	             time_placeholder_reminder = "مرة";
	             repate_reminder = "كرر!";
	             reminder_id_reminder = "تذكير:";
	            /*-------------------- END FOR REMINDER JS --------------------------- */

	             /*-------------------- END FOR QUOTE JS --------------------------- */
	                   alert_request_quote = "طلبك";
	                   alert_feedback_send_successfully_quote = "ردود الفعل إرسالها بنجاح";
	                    alert_failed_send_try_later_quote = "فشل في إرسال، يرجى المحاولة مرة أخرى في وقت لاحق";
	                    blank_filed_quote = "فارغ الميدان";
	                    enter_comment_quote = "الرجاء إدخال تعليق.";
	                    enter_valid_phoneno_quote = "يرجى إدخال رقم هاتف صالح.";
	                    enter_phoneno_quote = "يرجى إدخال رقم الهاتف.";
	                    invalid_emailid_quote = "معرف البريد الإلكتروني غير صالح";
	                    enter_valid_mailid_quote = "أدخل البريد الإلكتروني الشخصية سارية المفعول";
	                    enter_usrname_quote = "الرجاء إدخال اسم";
	             /*-------------------- END FOR QUOTE JS --------------------------- */

	         /*-------------------- END FOR QUIZ JS --------------------------- */
	             prefix_exam_quiz = "امتحان";
	              alert_quiz_data_not_found_quiz = "بيانات مسابقة غير موجود!";
	              alert_quiz = "إنذار";
	              alert_ok_quiz = "حسنا";
	              i_scored_quiz = "أنا وسجل";
	              take_this_quiz = "٪. أخذ هذا الاختبار واختبار براعة الفكرية الخاصة بك عن طريق تثبيت هذا التطبيق.";
	              alert_try_again_later_quiz = "حاول مرة اخرى..";
	              network_conn_error_quiz = "خطأ في اتصال الشبكة";
	           /*-------------------- END FOR QUIZ JS --------------------------- */

	           /*-------------------- END FOR NOTES JS --------------------------- */
	             add_new_notes = "اضف جديد";
	              placeholder_enter_text_here_notes = "أدخل النص هنا";
	              done_notes = "فعله";
	              alert_notes = "إنذار";
	              alert_ok_notes = "حسنا";
	              alert_enter_msg_notes = "يرجى كتابة رسالة.";
	              delete_notes = "حذف";
	              share_notes = "شارك";
	              edit_notes = "تحرير";
	              notify_success_delete_notes = "حذف بنجاح";
	             /*-------------------- END FOR NOTES JS --------------------------- */

	         /*-------------------- start FOR newsstand JS --------------------------- */
	         restore__your_purchases_newsstand = "استعادة عمليات الشراء";
	          if_u_ve_reinstalled_newsstand = "إذا كنت قد قمت بإعادة تثبيت";
	          on_ur_device_recover_purchase_newsstand = "على جهازك أو استعادة نسخة احتياطية على جهاز جديد يمكنك استرداد مشترياتك.";
	          restore_newsstand = "استعادة";
	          my_dashboard_newsstand = "بلدي لوحة";
	          home_newsstand = "الصفحة الرئيسية";
	          login_signup_newsstand = "دخول / اشترك";
	          my_account_newsstand = "حسابي";
	          restore_purchase_newsstand = "استعادة المشتريات";
	          main_menu_newsstand = "القائمة الرئيسية";
	          logout_newsstand = "خروج";
	          view_all_newsstand = "مشاهدة الكل";
	          my_collection_newsstand = "مجموعتي";
	          preview_newsstand = "معاينة";
	          subscribe_now_newsstand = "إشترك الآن";
	          buy_this_for_newsstand = "شراء هذا ل";
	          buy_now_newsstand = "اشتري الآن";
	          add_to_collection = "اضف للمجموعة";
	          view_newsstand = "رأي";
	          usd_newsstand = "دولار أمريكي";
	          slash_month_newsstand = "/شهر";
	          slash_year_newsstand = "/عام";
	          buy_album_newsstand = "اشتري الألبوم";
	          buy_edition_newsstand = "شراء الطبعة";
	          news_newsstand = "أخبار";
	          inner_html_choose_ur_subscription_newsstand ="اختر نوع الاشتراك:";

	          notify_enter_validno_newsstand = "الرجاء إدخال عدد صحيح";
	          alert_error_newsstand = "خطأ";
	          alert_ok_newsstand = "حسنا";
	          alert_enter_valid_exp_month_newsstand = "الرجاء إدخال صحيح انتهاء شهر";
	          alert_enter_valid_exp_year_newsstand = "الرجاء إدخال صحيح انتهاء العام";
	          alert_enter_valid_card_holder_name_newsstand = "الرجاء إدخال صحيح اسم حامل البطاقة";
	          alert_enter_valid_cvv_no_newsstand = "رجى إدخال كود CVV صحيح";
	          alert_payment_unsuccessful_newsstand = "كان الدفع غير ناجحة، \ يرجى التحقق من تفاصيل بطاقتك \ ن أو \ ن إعادة المحاولة بعد قليل";
	          alert_newsstand = "إنذار";
	          alert_message_newsstand ="الرسالة";
	          alert_ur_order_success_newsstand = "كان النظام الخاص بك بنجاح!";
	          alert_we_are_sorry_newsstand = "نحن اسفون!";
	          alert_file_not_found_newsstand = "لم يتم العثور على الملف.";
	          alert_check_internet_conn_newsstand = "يرجى التحقق من الاتصال بالإنترنت.";
	          alert_there_no_preview_avail_newsstand = "لا يوجد تتوفر معاينة.";
	          alert_check_net_conn_try_again_newsstand = "يرجى التحقق من اتصال الإنترنت الخاص بك وحاول مرة أخرى.";
	          alert_download_unsuccessfull = "تحميل غير ناجحة!";
	          alert_no_purchase_yet_newsstand = "لا توجد مشتريات بعد";
	          alert_server_error_try_some_time_newsstand = "خطأ الخادم، \ الرجاء إعادة المحاولة بعد قليل";
	          alert_emailid_pass_cant_blank_newsstand = "معرف البريد الإلكتروني وكلمة المرور يجب ألا تكون فارغة.";
	          alert_usrname_or_pass_invalid_newsstand = "اسم المستخدم أو كلمة المرور غير صالحة";
	          alert_emailid_cant_blank_newsstand = "يجب ألا يكون معرف البريد الإلكتروني فارغة.";
	          alert_pass_sent_ur_emailid_newsstand = "تم إرسال كلمة المرور على رقم البريد الإلكتروني الخاص بك.";
	          alert_unable_reset_pass_newsstand = "غير قادر على إعادة تعيين كلمة المرور الخاصة بك.";
	          alert_enter_phone_no_newsstand = "يرجى إدخال رقم الهاتف!";
	          alert_pass_conpass_doesnt_match_newsstand = "كلمة المرور وكلمة المرور لا تتطابقان";
	          alert_pass_cant_blank_newsstand = "* حقل كلمة المرور لا يمكن أن تترك فارغة";
	          alert_enter_valid_emailid_newsstand = "* الرجاء إدخال بريد إلكتروني صالح";
	          alert_name_field_cant_blank_newsstand = "* حقل اسم لا يمكن أن تترك فارغة";
	          alert_register_success_newsstand = "سجلت بنجاح";
	          alert_unable_register_newsstand = "غير قادر على تسجيل!";
	          alert_usr_already_registered_newsstand = "العضو مسجل بالفعل!";

	          payment_type_newsstand = "اكتب:";
	          payment_number_newsstand = "عدد:";
	          payment_expireMonth_newsstand = "expireMonth:";
	          payment_expireYear_newsstand = "انتهاء السنة";
	          payment_cvv2_newsstand = "cvv2:";
	          payment_firstName_newsstand = "الاسم الاول:";
	          payment_lastName_newsstand = "الكنية:";

	          html_log_in_newsstand = "تسجيل الدخول";
	          html_emailid_newsstand = "معرف البريد الإلكتروني";
	          html_password_newsstand = "كلمه السر";
	          html_login_newsstand = "تسجيل الدخول";
	          html_forgot_pass_newsstand = "نسيت رقمك السري؟";
	          html_dont_ve_account_newsstand = "لم يكن لديك حساب؟";
	          html_signup_now = "أفتح حساب الأن";
	         /*-------------------- END FOR newsstand JS --------------------------- */

	          /*-------------------- START FOR SERVICES JS --------------------------- */
			   theusernamepasswordenteredincorrect_services = "اسم المستخدم او كلمة المرور التي ادخلتها خاطئه";

	          placeholder_city_state_country_services = "المدينة، الدولة، الدولة";
	           placeholder_soundrssData_services = "بيانات مسابير";
	           placeholder_rssradioData_services = "بيانات الراديو آر إس إس";
	           placeholder_customlistData_services = "بيانات قائمة مخصصة";
	           placeholder_customTrackNameData_services = "customTrackNameData";
	           placeholder_customTrackDescriptionData_services = "عرف المسار الوصف البيانات";

	           old_add_class_services = "البالغ من رأي";
	           search_category_services = "بحث فئة";
	           form_internal_search_services = "لا";
	           distance_unit_mi_services = "MI";
	           distance_unit_m_services = "م";
	           distance_unit_k_services = "ك";
	           call_disp_none_services = "none";
	           rating_disp_block_services = "منع";
	           address_name_not_avail_services = "اسم عنوان غير متوفر";

	           alert_internet_conn_not_avail_services = "اتصال إنترنت غير متوفر.";
	           alert_services = "إنذار";
	           add_more_services = "أضف المزيد";
	           alert_thanks_services = "شكر!";
	           alert_success_submitted_services = "قدمت بنجاح";
	           successfully_updated_services = "تم التحميل بنجاح!";
	           alert_oops_services = "عفوا";

	           custom_track_cant_blank = "لا يمكن أن تكون مخصصة اسم المسار فارغ.";
	           custom_track_desc_cant_blank = "وصف مسار مخصص لا يمكن أن يكون فارغا.";

	           alert_server_not_found_try_later_services = "لخادم لا يستجيب \ ن الرجاء المحاولة مرة أخرى في وقت لاحق";
	           alert_enter_valid_email_address_services = "أدخل عنوان بريد إلكتروني صالح";
	           alert_name_field_cant_blank = "* حقل اسم لا يمكن أن تترك فارغة";
	           alert_please_switchon_location_services = "يرجى تشغيل خدمات الموقع لهذا التطبيق، لاستخدام هذه الميزة";
	           alert_select_from_where_want_services = "اختر من حيث تريد تحميل!";
	           alert_message_services = "الرسالة";
	           alert_gallery_camera_cancel_services = "كاميرا، معرض، الغاء";
	           alert_listing_submit_success_review_services = "يقدم قائمة بنجاح وهو قيد المراجعة من قبل المشرف.";
	           alert_success_services = "نجاح!!";
	           alert_error_submitting_listing_services = "خطأ في تقديم قائمة.";
	           alert_error_services = "خطأ";
	           alert_want_logout_services = "تريد تسجيل الخروج؟";
	           logout_services = "خروج";
	           cancel_yes_services = "إلغاء، نعم";
	           alert_ok_services = "حسنا";
	           alert_sign_alert_services = "تنبيه!";
	           user_register_successfully_services = "مسجل بنجاح";
	           user_already_register_services = "مسجل بالفعل";

	           enter_name_services = "الرجاء إدخال اسم.";
	           enter_emailid_services = "الرجاء أدخل البريد الإلكتروني معرف.";
	           enter_valid_email_services = "يرجى إدخال عنوان بريد إلكتروني صالح";
	           enter_phone_no_services = "يرجى إدخال رقم الهاتف.";
	           enter_valid_phoneno_services = "الرجاء إدخال صالح رقم الهاتف.";
	           enter_password_services = "يرجى إدخال كلمة المرور.";
	           password_mismatch_services = "عدم تطابق كلمه المرور";
	           invalid_email_address_services = "عنوان البريد الإلكتروني غير صالح ...";
	           password_reset_success_check_email_services = "كان إعادة تعيين كلمة المرور بنجاح، \ يرجى التحقق من البريد الإلكتروني الخاص بك لكلمة مرور جديدة.";
	           you_not_register_with_yet_services = "أنت لم تسجل معنا بعد.";
	           enter_valid_address_services = "يرجى إدخال عنوان صالح";
	           enter_budget_services = "الرجاء إدخال الميزانية";
	           enter_requirement_services = "الرجاء إدخال متطلبات";
	           request_not_submit_try_again_services = "طلب لم تقدم. الرجاء معاودة المحاولة في وقت لاحق";
	           select_ratting_services = "الرجاء اختر تقييمك";
	           ratting_missing_services = "تصنيف عداد المفقودين!";
	           no_categories_avail_services = "لا يوجد فئات";
	           isfrom_drictory_services = "هو من دليل";

	           filter_type_services = "مسافه";
	           filter_type_ratting_services = "ratting";
	           Filter_search_distance_services = "مسافه";
	           internet_connective_error_services = "خطأ اتصال الإنترنت";
	           no_saved_bookmarks_services = "لا المحفوظة إرسال";
	           search_delhi_services = "دلهي";
	           output_weatherlist_services = "weatherList";

	           inner_html_location_couldnot_found_services = "لا يمكن العثور على الموقع";
	           inner_html_error_has_occured_services = "حدث خطأ";

	          /*-------------------- END FOR SERVICES JS --------------------------- */

	           /******************** END GEETA CODE **************************************/
	           
	                invalidloginidorpassword_news = "معرف تسجيل الدخول غير صالح أو كلمة المرور";
	                email_news = "البريد الإلكتروني";
	                password_news = "كلمه السر";
	                login_news = "تسجيل الدخول";
	                forgotpassword_news = "هل نسيت كلمة المرور";
	                signup_news = "سجل";	
	                name_news = "*اسم";
	                emaill_news = "*البريد الإلكتروني";
	                phonenumber_news = "رقم الهاتف";
	                confirmpassword_news = "تأكيد كلمة المرور";
	                alreadyhaveanaccount_news  = "هل لديك حساب؟";
	                signin_news = "تسجيل الدخول";
	                Wehavesentemailemailid_news = "لقد قمنا بإرسال بريد إلكتروني إلى معرف البريد الإلكتروني الخاص بك";
	                enteryouremail_news = "ادخل بريدك الإلكتروني";
	                resetpassword_news = "اعادة تعيين كلمة السر";
	                signupnow_news = "أفتح حساب الأن";
	                donothaveanaccount_news  = "لم يكن لديك حساب؟";
	                error_news = "خطأ";
	                pleaseenterfirstname_news = "الرجاء إدخال الاسم الأول";
	                pleaseentervalidemailid_news = "الرجاء إدخال بطاقة هوية صالحة البريد الإلكتروني";
	                pleaseenterphonenumber_news = "يرجى إدخال رقم الهاتف";
	                pleaseentervalidphonenumber_news = "الرجاء إدخال صالحة رقم الهاتف";
	                pleaseenterpassword_news = "الرجاء إدخال كلمة المرور"; 
	                confirmpasswordnotmatch_news = "تأكيد كلمة المرور لا تتطابق";
	                congratulations_news = "تهانينا"; 
	                youaresuccessfullyregistered_news = "أنت مسجل بنجاح";
	                someonealreadyusername_news = "شخص ما لديه بالفعل أن اسم المستخدم";
	                alert_news = 'إنذار';
	                passwordresetsuccessfullpassword_news = 'كان إعادة تعيين كلمة المرور بنجاح,\nيرجى التحقق من بريدك الالكتروني للكلمة سر جديدة';
	                youhavenotbeenregistered_news = 'أنت لم تسجل معنا بعد';
	                invalidemailddress_news = 'عنوان البريد الإلكتروني غير صالح';
	                ok_news = "حسنا";
	                sorry_news = "آسف";
	                pleaseentercorrectpassword_news = "يرجى إدخال كلمة المرور الصحيحة";
	                younotregistered_news = "أنت غير مسجل";
	                nohomepagenewsavailable_news = "لا موقع الأخبار المتاحة";
	                nonewsavailable_news = "لا يوجد أخبار";
	                searchnews_news = "بحث الأخبار";
	                settings_news = "إعدادات";
	                choosewhichpushalertsreceive_news = "اختيار أي دفع التنبيهات التي ترغب في الحصول عليها. يمكن دائما هذه التفضيلات أن تتغير في وقت لاحق";
	                alertsneeded_news = "التنبيهات اللازمة";
	                none_news = " لا شيء ";
	                all_news = " جميع  ";
	                everydays_news = " كل 4-5 أيام  "; 
	                everydays_news   = " كل 12-15 يوما  ";
	                dontsendalert_news = "لا ترسل تنبيه بين";
	                morealeroptions_news = "خيارات أكثر يقظة";
	                youcategoriesyourinterests_news = "يمكنك أيضا اختيار أي من الفئات التالية للحصول على تنبيهات على أساس المصالح الخاصة بك";
	                categories_news = "الفئات";
	                news_news = " أخبار ";
	                sports_news = " رياضات ";
	                entertainment_news = " تسلية ";
	                tech_news = " التكنولوجيا ";
	                save_news = " حفظ ";
	                bookmark_news = "المرجعية";
	                articlehas_news = " هذه المادة لها ";
	                postcomment_news = "مرحلة ما بعد تعليق";
	                small_news = "صغير";
	                normal_news = "عادي";
	                large_news = "كبير";
	                nobookmarknewsavailable_news = "لا مرجعية الأخبار المتاحة";
	                pleaseentercomment_news = "الرجاء إدخال تعليقك";
	                postcommenthere_new = "أضف تعليقك هنا";
	                pleaseenterstarttime_news = "الرجاء إدخال وقت البدء";
	                pleaseenterendtime_news = "الرجاء أدخل وقت الانتهاء";
	                endtimealwaysgreater_news = "نهاية الوقت دائما أكبر من وقت البدء";
	                pleaseselectcheckbox_news = "الرجاء تحديد خانة الاختيار";
	                ccongratulation_news = "تهنئة";
	                settingsaddedsuccessfully_news = "إعدادات أضافت بنجاح";
	                nonewsfoundcategory_news = "لم يتم العثور في هذه الفئة الأخبار";
	                pleaseenteryourkeyword_news = "الرجاء إدخال الكلمات الرئيسية";
	                         /* ---- news complete ---- */
	                
	                 home_food = "الصفحة الرئيسية";
	                 my_shop_food = "متجري الغذاء";
	                 cart_food="العربة";
	                 my_account_food="حسابي";
	                 My_Orders_food = "طلباتي";
	                 pickup_food = "وانيت عنوان";
	                 categories_food = "فئات الأغذية";
	                 submit_food = "عرض";
	                 forgot_password_food = "هل نسيت كلمة المرور";
	                 email_id_food = "البريد الإلكتروني معرف";
	                 password_food = "كلمه السر";
	                 do_not_have_an_account_food = "لم يكن لديك حساب؟";
	                 search_food = "بحث";
	                 sign_up_now_food = "أفتح حساب الأن";
	                 name_food = "اسم";
	                 phone_food = "هاتف";
	                 confirm_password_food = "تأكيد كلمة المرور";
	                 sign_up_food = "سجل";
	                 already_have_an_account_food = "هل لديك حساب؟";
	                 sign_in_food = "تسجيل الدخول";
	                 contact_information_food = "معلومات الاتصال";
	                 my_address_food = "عنواني";
	                 default_billing_address_food = "عنوان الفواتير الافتراضي";
	                 default_shipping_address_food = "عنوان الشحن الافتراضي";
	                 order_history_food = "تاريخ الطلب";
	                 order_id_food = "رقم التعريف الخاص بالطلب";
	                 billing_address_food = "عنوان وصول الفواتير";
	                 shipping_address_food = "عنوان الشحن";
	                 order_detail_food = "ترتيب التفاصيل";
	                 product_name_food = "اسم المنتج";
	                 price_food = "السعر";
	                 qty_food = "الكمية";
	                 order_date_food = "تاريخ الطلب";
	                 subtotal_food = "حاصل الجمع";
	                 tax_food = "ضريبة";
	                 coupon_food = "كوبون";
	                 discount_food = "خصم";
	                 shipping_food = "الشحن";
	                 grand_total_food= "المبلغ الإجمالي";
	                 payment_method_food = "طريقة الدفع او السداد";
	                 order_status_food = "حالة الطلب";
	                 personal_information_food = "معلومات شخصية";
	                 change_password_food = "تغيير كلمة السر";
	                 current_password_food = "كلمة السر الحالية";
	                 confirm_new_password_food = "تأكيد كلمة المرور الجديدة";
	                 no_product_exists_food = "لا يوجد منتجات";
	                 add_to_cart_food = "أضف إلى السلة";
	                 cart_list_food = "قائمة عربة";
	                 edit_food = "تحرير";
	                 done_food = "فعله";
	                 payment_details_food = "تفاصيل الدفع";
	                 apply_coupon_code_food = "تطبيق رمز القسيمة";
	                 enter_your_coupon_code_if_you_have_one_food = "أدخل رمز القسيمة";
	                 apply_food = "تطبيق";
	                 continue_shopping_food = "متابعة التسوق";
	                 checkout_food = "الدفع";
	                 first_name_food = "الاسم الاول";
	                 last_name_food = "الكنية";
	                 address_food = "عنوان";
	                 zip_postal_code_food = "الرمز البريدي / الرمز البريدي";
	                 city_food = "مدينة";
	                 country_food = "بلد";
	                 state_province_food = "الدولة / مقاطعة";
	                 telephone_food = "هاتف";
	                 fax_food = "فاكس";
	                 same_as_billing_address_food = "نفس عنوان ارسال الفواتير";
	                 pay_now_food = "ادفع الآن";
	                 cash_on_delivery_food = "الدفع عند التسليم";
	                 please_click_on_place_order_button_to_place_the_order_food = "يرجى الضغط على زر طلب مكان لوضع النظام";
	                 credit_card_food = "بطاقة ائتمان";
	                 paypal_food = "باي بال";
	                 you_will_be_redirected_to_paypal_site_food = "سيتم توجيهك إلى موقع باي بال";
	                 order_by_phone_food = "طلب عن طريق التلفون";
	                 you_can_order_by_calling_food = "يمكنك من أجل بالدعوة";
	                 place_order_food = "ترتيب مكان";
	                 instock_food= "في المخزن";
	                 out_of_stock_food = "إنتهى من المخزن";
	                 test_food = "اختبار المواد الغذائية";

	                 required_fields_food="الحقول المطلوبة";
	                 no_items_in_cart_food="لا يوجد لديك عناصر في سلة التسوق الخاصة بك";
	                 add_products_in_cart_food="الرجاء إضافة منتجات في سلة التسوق الخاصة بك";
	                	login_food="تسجيل الدخول";
	                 new_password_food="كلمة السر الجديدة";
	                 logout_food="خروج";
	                 no_products_exists_food="لا يوجد منتجات";
	                 already_have_an_account_food="هل لديك حساب؟";
	                 instructions_foodorder="تعليمات";


	                 privacypolicy_food = "سياسة الخصوصية";
	                 homee_food = "الصفحة الرئيسية";
	                 loginsignup_food = "دخول / تسجيل ما يصل";
	                 cartt_food = "العربة";
	                 myorder_food = "طلبي";
	                 termscconditions_food = "البنود و الظروف";
	                 lllogout_food = "خروج";
	                 searchproducts_food = "البحث عن المنتجات";
	                 featureddproducts_food = "منتجات مميزة";
	                 searchproductin_food = "البحث الإنتاج";
	                 ssearch_food = "بحث";
	                 aalert_food = 'إنذار';
	                 pleaseenterkeywordsearch_food = 'الرجاء إدخال كلمة للبحث';
	                 adddd_food = "إضافة";
	                 noproductfoundd_food = "لا المنتج موجود";
	                 searchresultt_food = "نتيجة البحث عن";
	                 thereproductadded_food = "وهناك إضافة أي منتج";
	                 productsuccessfullyaddedcart_food = "واضاف المنتج بنجاح إلى سلة التسوق الخاصة بك";
	                 productquantityzero_food = "يجب أن يكون المنتج الكمية أكبر من صفر";
	                 sizeformeal_food = "حجم لتناول وجبة";
	                 youhaveaddedmaximumquantity_food = "لقد قمت بإضافة الكمية القصوى";
	                 select_food = "اختار";
	                  subbb_food = 'الفرعية ';
	                 addzero_food = 'إضافة 0';
	                 addddd_food = 'إضافة ';
	                 pleaseenterquantityessthann_food = "الرجاء إدخال كمية أقل من";
	                 pleaseselectt_food = 'اختر من فضلك ';
	                 errorrr_food = "خطأ";
	                 okkk_food = "حسنا";
	                 miordervalueis_food = 'دقيقة. قيمة النظام هو';
	                 ssorry_food = "آسف";
	                 productsuccessfullydadednourart_food = "المنتج أضيف بنجاح في سلة التسوق الخاصة بك";
	                 quantityshouldgreaterzero_food = "وينبغي أن تكون كمية أكبر من الصفر";
	                 deliverycharge_food = "رسوم التوصيل "; 
	                 discountcodes_food = "رموز الخصم";
	                 shoppingcart_food = "عربة التسوق";
	                 clearcart_food = "العربة واضحة";
	                 tip_food = "تلميح";
	                 continueoordering_food ="مواصلة طلب"
	                 qquantity_food = "كمية";
	                 pprice_food = "السعر";
	                 ttotal_food = "مجموع";
	                 ttax_food = "ضريبة";
	                 ddiscount_food = "خصم";
	                 ddeliverycharge_food = "رسوم التوصيل";
	                 ggrandtotal_food = "المبلغ الإجمالي";
	                 therenoitemcart_food = "لا يوجد أي عنصر في عربة";
	                 doneee_food = "فعله";
	                 couponpppage_food = "قسيمة الصفحة";
	                 notavalidcccoupon_food = "لا القسيمة صالحة "; 
	                 eeenteryourcouponcode_food= "أدخل رمز القسيمة الخاصة بك";
	                 ppaymentddetails_food = "تفاصيل الدفع";
	                 ssubtotal_food= "حاصل الجمع ";
	                 ccoupon_food= "كوبون ";
	                 llloginregistration_food = "تسجيل الدخول / تسجيل";
	                 mmyaccount_food = "حسابي";
	                 mysshop_food= "متجري";
	                 invalidloginidorpassword_food= "معرف تسجيل الدخول غير صالح أو كلمة المرور";
	                 fforgotyourpassword_food= "نسيت رقمك السري؟";
	                 orr_food = "أو";
	                 ccconfirmpassword_food = "تأكيد كلمة المرور";
	                 wehavesentemailemailid_food = "لقد قمنا بإرسال بريد إلكتروني إلى معرف البريد الإلكتروني الخاص بك";
	                 rrresetpassword_food = "اعادة تعيين كلمة السر";
	                 aaaalreadyhaveanaccount_food= "هل لديك حساب؟ ";
	                 ppleaseenterfirstnname_food ='الرجاء إدخال الاسم الأول';
	                 ppleaseeentervvalidemailiid_food = 'الرجاء إدخال بطاقة هوية صالحة البريد الإلكتروني';
	                 ppleaseenterpphonennumber_food = 'يرجى إدخال رقم الهاتف';
	                 pppleaseetervlidphonenumber_food = 'الرجاء إدخال صالحة رقم الهاتف';
	                 ppleaseenterpassword_food = 'الرجاء إدخال كلمة المرور';
	                 cconfirmpassworddonotmatch_food = 'تأكيد كلمة المرور لا تتطابق';
	                 sssignuuccessful_food ='اشترك ناجحة';
	                 eeemaillreadyegistered_food= 'البريد الإلكتروني رقم مسجل إذا';
	                 uuhoh_food = 'اه أوه، صالح معرف البريد الإلكتروني';
	                 ppasswordesewasuccessfullleasecheckemailfornewpassword_food = 'كان إعادة تعيين كلمة المرور بنجاح، يرجى التحقق من بريدك الالكتروني للكلمة سر جديدة';
	                 yyouhavenotbeenregisteredwithusyet_food = 'أنت لم تسجل معنا بعد';
	                 iiinvalidemailaddress_food = 'عنوان البريد الإلكتروني غير صالح';
	                 dddashboard_food = "لوحة القيادة";
	                 mmydashboard_food = "بلدي لوحة";
	                 helloharmenrdrupta_food = "مرحبا، دارمندرا غوبتا";
	                 ffromyoucounashboardbilityviewsnapshottion_food = "من الخاص حسابي لوحة لديك القدرة على عرض لقطة من النشاط حسابك في الفترة الأخيرة وتحديث معلومات حسابك. حدد الرابط أدناه لعرض أو تعديل المعلومات";
	                 aaaaddressook_food = "دفتر العناوين ";
	                 iiinformationpdateuccessfully_food  = "معلومات عنوان التحديث بنجاح";
	                 ssssave_food = "حفظ";
	                 nnnnname_food = "اسم";
	                 eeemaiddress_food = "عنوان البريد الإلكتروني";
	                 enterourmailid_food = "أدخل معرف البريد الإلكتروني الخاص بك";
	                 ttelephonenno_food = "الهاتف لا";
	                 billingformationpdatedccessfully_food = "معلومات الفواتير التحديث بنجاح";
	                 nnname_food ="اسم";
	                 sstreetssddress_food= "عنوان الشارع";
	                 enteourity_food = "أدخل مدينتك";
	                 enterstatepprovince_food ="أدخل الدولة / مقاطعة";
	                 eenteipostalode_food ="أدخل الرمز البريدي / الرمز البريدي";
	                 sshippinddresiffereillinddress_food =" عنوان الشحن يختلف عن عنوان الفواتير";
	                 sshippingformationdateduccessfully_food= "معلومات الشحن التحديث بنجاح";
	                 ffirstnme_food = "الاسم الاول";
	                 zzipostalode_food= "الرمز البريدي / الرمز البريدي";
	                 oooder_food = " رقم التعريف الخاص بالطلب";
	                 deliverycccharge_food ="رسوم التوصيل";
	                 ccouponddiscount_food = "قسيمة الخصم";
	                 ttotalamount_food ="المبلغ الإجمالي";
	                 cccccomment_food = "التعليق";
	                 iiitemisnotavailable_food = "العنصر غير متوفر";
	                 dddelivery_food = "خدمه توصيل";
	                 dddeliveryromocation_food = "تسليم من الموقع";
	                 aaaaaaaaaddress_food = "عنوان";
	                 pppickupime_food = "وانيت الوقت";
	                 cooonfirm_food = "أكد";
	                 pppaymentorderfor_food ="دفع نموذج طلب المنتج ";
	                 alerttText='يرجى تحديد وقت الالتقاط بعد 45 دقيقة من الوقت الحالي';
	                 ppleaseaterpentime_food = 'يرجى تحديد وقت الالتقاط بعد 45 دقيقة من وقت مفتوح ';
	                 pppickupime_food = 'التقاط الوقت';
	                 ppppleaseenterapreferredpickuptime_food ='الرجاء إدخال المفضل التقاط الوقت';
	                 ppleaseenterareferredweenentime_food ='الرجاء إدخال التقاط الوقت المفضل بين متجر الوقت مفتوح ';
	                 andstoreclosettime_food = ' وتخزينها وقت قريب ';
	                 ppleaseselectdeliverytimetime_food = 'يرجى تحديد وقت التسليم بعد 45 دقيقة من الوقت الحالي';
	                 ppppleasecheckdelivimlease_food='يرجى التحقق من وقت التسليم. لا يمكن جدولة يرجى ملاحظة التسليم قبل 45 دقيقة من وضع النظام';
	                 emmmail_food = "البريد الإلكتروني";
	                 ssstateprovince_food = "الدولة / مقاطعة";
	                 ccccountry_food = "بلد";
	                 ssshhhippingddress_food = "عنوان الشحن";
	                 preferred_deliverytime_Text="-:فضل وقت التسليم";
	                 pppppayow_food = "ادفع الآن";
	                 ddddeliveryime_food = 'موعد التسليم';
	                 pppleaseentepreferreddelivery_food='الرجاء إدخال تسليم فضل';
	                 pppleasestoreopentimee_food = 'الرجاء إدخال وقت التسليم يفضل بين متجر الوقت مفتوح';
	                 dddddeliveryiotavailableinyourlocation_food = 'التسليم ليست متوفرة في موقعك';
	                 ppppppleasenteountry_food = 'الرجاء إدخال البلد';
	                 bblankfield_food = 'فارغ الميدان';
	                 pppllleasenterterovince_food ='الرجاء إدخال الدولة / مقاطعة';
	                 pplleasenterourity_food ='الرجاء إدخال مدينتك';
	                 pppleasntetreetress_food = 'يرجى إدخال عنوان الشارع';
	                 ppppleasnteridhonember_food = 'الرجاء إدخال صالحة رقم الهاتف';
	                 iiiiinvalihoneumber_food = 'رقم الهاتف غير صحيح';
	                 ppleaseenterfirsname_food ='الرجاء إدخال الاسم الأول';
	                 ppleasnterountry_food = 'الرجاء إدخال البلد';
	                 ppleasenterlidailddress_food ='يرجى إدخال عنوان بريد إلكتروني صالح';
	               ppleasnterrstame_food = 'الرجاء إدخال الاسم الأول';
	                 pppaycashatdoor_food = "الدفع نقدا عند الباب";
	                 ppaypalexpress_food = "باي بال اكسبرس";
	                 ppawithareditcard_food = "الدفع بواسطة بطاقة الائتمان";
	                 oorderbyhone_food = "طلب عن طريق التلفون";
	                 ccallnow_food = "اتصل الان";
	                 pppleaseclickontheconfirmtopaythroughcreditcard_food ="الرجاء الضغط على تأكيد أن تدفع عن طريق بطاقة الائتمان";
	                 ppleaseclickonconfirmbuttonlaceherder_food = "يرجى الضغط على زر تأكيد لوضع النظام";
	                 cccardype_food = "نوع البطاقة";
	                 viisa_food ="تأشيرة";
	                 mmastercard_food = "ماستر كارد";
	                 amexxx_food = "أمريكان إكسبريس";
	                 dddiscover_food = "اكتشف";
	                 caaardnumber_food = "رقم البطاقة";
	                 exxxpirymonth_food = "شهر انتهاء الصلاحية";
	                 eeexpiryear_food = "انتهاء السنة";
	                 cccccardolder_food = "حامل البطاقة";
	                 ccardssecuritode_food = "قانون الضمان بطاقة";
	                 caaaard_food = "بطاقة";
	                 paaaypal_food = "باي بال";
	                 cood_food = "سمك القد";
	                 checkthebackoyourcreditcardforcvv_ffod = "تحقق الجزء الخلفي من بطاقة الائتمان الخاصة بك لCVV";
	                 cvvv_food = "CVV";
	                 cardholdernaaame_food = "إسم صاحب البطاقة";
	                 yyoucanorderycalling_food = "يمكنك من أجل بالدعوة ";
	                 ppleaseclickontheconfirmaypal_food = "الرجاء النقر على تأكيد أن تدفع عن طريق باي بال";
	                 paaayusingashonelivery_food = "الدفع باستخدام النقدية على التسليم";
	                 pllaaceorder_food = "مكان من اجل";
	                 ppleaseentervalidumber_food = "الرجاء إدخال عدد صحيح";
	                 ppleaseentervalidxpairyonth_food = "الرجاء إدخال صحيح انتهاء شهر";
	                 ppleaseentervalidxpairyear_food ="الرجاء إدخال صحيح انتهاء العام";
	                 ppleaseentervalidardolderame_food="الرجاء إدخال صحيح اسم حامل البطاقة ";
	                 pppleaseentervalidode_food = "يرجى إدخال كود CVV صحيح ";
	                 iiinvalidcardetails_food = 'تفاصيل بطاقة غير صالحة';
	                 innnvalidcard_food = "بطاقة غير صالحة";
	                 ppppleaseenterthevalidaddrespickup_food = 'يرجى إدخال عنوان صحيح لبيك اب';
	                 ppleasentethtimeforpickup_food = 'يرجى إدخال الوقت لسيارة بيك آب';
	                 cccancel_food = "إلغاء";
	                 rrretry_food = "إعادة المحاولة";
	                 cccontinue_food = "استمر";
	                 wwvereceivedourorder_food = "لقد تلقينا طلبك";
	                 yourorderwuccessfu_food = 'كان النظام الخاص بك بنجاح';
	                 wwearesorry_food = 'نحن اسفون';
					 toText_food = 'إلى';
	                /* ---- foodordering complete ---- */
	             
	                  signupenternamealert = "حقل اسم لا يمكن أن تترك فارغة";
	                  signuppasswords = "حقل كلمة المرور لا يمكن أن تترك فارغة";
	                  signupemailid = "الرجاء إدخال بريد إلكتروني صالح";
	                  signuppasswordshouldbesevenchar ="يجب أن يكون طول كلمة المرور الحد الأدنى 7 أحرف";
	                  signuppassworddonotmatch ="كلمة السر غير متطابقة";
	                  signuppasswordsendmailid = "تم ارسال كلمة المرور على البريد الإلكتروني الخاص بك رقم";
	                  signuppasswordunabletoreset = "غير قادر على إعادة تعيين كلمة المرور الخاصة بك";
	                  registeredsuccessfully ="سجلت بنجاح";
	                  registeredsuccessfullycustomforecb1f89b5b67 ="الخطوة الأخيرة، تحقق من بريدك الالكتروني واتباع التعليمات المرسلة لك";
	                  unabletoregister ="غير قادر على تسجيل";
	                  useralreadyregistered ="مسجل إذا";
	                  emailandpasswordmustnotbeblank ="معرف البريد الإلكتروني وكلمة المرور يجب ألا تكون فارغة";
	                  invalidusernameorpassword ="اسم المستخدم أو كلمة المرور غير صالحة";
	                  fromfacebookloginstatus=false;


	                  ccconnect_code = "ربط ";
	                  with_code = "مع";
	                  fffacebook_code = " فيس بوك";
	                  dddelete_code = "حذف";
	                  bookkkmark_code = "المرجعية";
	                  ookk_code = 'حسنا';
	                  ppdfownloadinginprogress_code = 'قوات الدفاع الشعبي تحميل قيد التقدم'
	                  nointerbnconnection_code ='NO INTERNET CONNECTION';
	                  yyoumustbeconnectedinternet_code ='يجب أن تكون متصلا بالإنترنت لاستخدام هذه الميزة. تحقق من اتصال الإنترنت الخاص بك وحاول مرة أخرى';
	                  applicationaunchfailed_code = "إطلاق تطبيق فشل. حاول مرة اخرى";
	                  youhaveupdatesavailableforhisapp_code = "لديك التحديثات المتوفرة لهذا التطبيق";
	                  uuupdate_code ="تحديث";
	                  rremindmeater_code = "ذكرني لاحقا";
	                  aalert_code = 'إنذار';
	                  ssorryhisapptemporarilydisabledpublisher_code = " عذرا، لقد تم تعطيل هذا التطبيق مؤقتا من قبل الناشر ";
	                  ccontacttheowner_code = "الاتصال بالمالك";
	                  bbandwidthlimitonppunlocked_code = "تم تجاوز حد عرض النطاق الترددي على التطبيقات. يرجى الاتصال بالمالك التطبيقات للحصول على التطبيق مقفلة";
	                  cchathere_code = "الدردشة هنا";
	                  wecannotaccesshidden_code = 'ونحن لا يمكن الوصول يبدو app.It كل ما تبذلونه من الصفحات في التطبيق مخفية';
	                  sselectgender_code = "حدد نوع الجنس";
	                  mmale_code = "ذكر";
	                  femalee_code = "أنثى";
	                  aaattachfile_code = "إرفاق ملف";
	                  nnnotvalidemail_code = "لا بريد إلكتروني صالح";
	                  ppleaseprovidepaypalemailid_code = 'يرجى تقديم باي بال معرف البريد الإلكتروني';
	                  ppleaseprovidepaymentmount_code= 'يرجى تقديم دفع المبلغ';
	                  ppaymentfor_code = "دفع ل ";
	                  ppleaseprovidepubliceforiap_code = 'يرجى توفير المفتاح العمومي للIAP';
	                  ffieldcannotbeleftblank_code = ' المجال لا يمكن أن تترك فارغة';
	                  uunabletoegister_code = 'غير قادر على تسجيل';
	                  ccheckyournternetonnectioagain_code = 'تحقق من اتصال الإنترنت الخاص بك وحاول مرة أخرى';
	                  vverificationcodesendsuccessfully_code = "إرسال رمز التحقق بنجاح";
	                  vverificationodesendingfailed_code ="رمز التحقق فشل إرسال";
	                  ppleasetryagain_code = "حاول مرة اخرى";
	                  verificationcodemustnotbeblank_code = "لا يجب أن يكون رمز التحقق فارغ";
	                  vverificationcodenotmatched_code = "رمز التحقق لم يواكب";
	                  eemailidmustnotbeblank_code = "لا يجب أن يكون البريد الإلكتروني معرف فارغ";
	                  notvvvalid_code = "غير صالح";
	                  ffacebookauthenticateagain_code = 'الفيسبوك لا مصادقتك. حاول ثانية';
	                  pppleasentervalidmail_code = '*الرجاء إدخال بريد إلكتروني صالح';
	                 /* ---- code complete ---- */



}